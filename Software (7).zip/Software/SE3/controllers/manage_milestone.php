<?php
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/ContractModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$milestone_id = $_POST['milestone_id'] ?? null;
$action       = $_POST['action'] ?? null; // 'fund', 'submit', 'release'

if (!$milestone_id || !$action) {
    echo json_encode(['success' => false, 'error' => 'Missing data']);
    exit();
}

$contractModel = new ContractModel();
$newStatus = '';
if ($action === 'fund') $newStatus = 'funded';
elseif ($action === 'submit') $newStatus = 'submitted';
elseif ($action === 'release') $newStatus = 'completed';

// التحقق من الصلاحيات
$db = Database::getInstance();
$stmt = $db->prepare("
    SELECT c.client_id, c.freelancer_id 
    FROM milestones m 
    JOIN contracts c ON m.contract_id = c.contract_id 
    WHERE m.milestone_id = ?
");
$stmt->execute([$milestone_id]);
$contract = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$contract) {
    echo json_encode(['success' => false, 'error' => 'Milestone not found']);
    exit();
}

// الكلاينت فقط هو من يمول أو يحرر الدفع
if (($action === 'fund' || $action === 'release') && $contract['client_id'] != $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'error' => 'Only client can fund or release']);
    exit();
}

// الفريلانسر فقط هو من يسلم العمل
if ($action === 'submit' && $contract['freelancer_id'] != $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'error' => 'Only freelancer can submit work']);
    exit();
}

$result = $contractModel->updateMilestoneStatus($milestone_id, $newStatus);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>
