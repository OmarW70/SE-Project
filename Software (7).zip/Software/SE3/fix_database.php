<?php
// تأكد من تحميل ملف قاعدة البيانات أولاً لأن ملف الإعدادات يستخدمه
require_once 'models/Database.php';
require_once 'config/config.php';

try {
    $db = Database::getInstance();
    echo "<body style='font-family:sans-serif; line-height:1.6; padding:20px; background:#f4f4f9;'>";
    echo "<h2>🛠️ Database Comprehensive Repair Tool (v3)</h2>";

    function runQuery($db, $label, $sql) {
        try {
            $db->exec($sql);
            echo "<div style='color:green; margin-bottom:10px;'>✅ $label: Success.</div>";
        } catch (Exception $e) {
            echo "<div style='color:red; margin-bottom:10px;'>❌ $label: Failed - " . $e->getMessage() . "</div>";
        }
    }

    // 1. Fix contracts table column name
    echo "<h3>1. Checking 'contracts' table...</h3>";
    try {
        $checkC = $db->query("SHOW COLUMNS FROM contracts LIKE 'amount'");
        if ($checkC->rowCount() > 0) {
            runQuery($db, "Renaming 'amount' to 'total_price' in contracts", 
                     "ALTER TABLE contracts CHANGE COLUMN amount total_price DECIMAL(10,2) NOT NULL");
        } else {
            echo "<div style='color:blue;'>ℹ️ Contracts table column is already correct (total_price) or 'amount' not found.</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color:red;'>⚠️ Contracts table error: " . $e->getMessage() . "</div>";
    }

    // 2. Fix proposals table column name
    echo "<h3>2. Checking 'proposals' table...</h3>";
    try {
        $checkP = $db->query("SHOW COLUMNS FROM proposals LIKE 'bid'");
        if ($checkP->rowCount() > 0) {
            runQuery($db, "Renaming 'bid' to 'bid_amount' in proposals", 
                     "ALTER TABLE proposals CHANGE COLUMN bid bid_amount DECIMAL(10,2) NOT NULL");
        } else {
            echo "<div style='color:blue;'>ℹ️ Proposals table column is already correct (bid_amount) or 'bid' not found.</div>";
        }
    } catch (Exception $e) {
        echo "<div style='color:red;'>⚠️ Proposals table error: " . $e->getMessage() . "</div>";
    }

    // 3. Create missing tables if any
    echo "<h3>3. Ensuring tables exist...</h3>";
    runQuery($db, "Creating 'milestones' table", "
        CREATE TABLE IF NOT EXISTS milestones (
            milestone_id INT PRIMARY KEY AUTO_INCREMENT,
            contract_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            status ENUM('pending', 'funded', 'submitted', 'completed') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (contract_id) REFERENCES contracts(contract_id) ON DELETE CASCADE
        )
    ");

    echo "<br><hr>";
    echo "<h2 style='color:blue'>🎉 All checks finished!</h2>";
    echo "<p>Try submitting a proposal now.</p>";
    echo "<a href='views/jobs.php' style='display:inline-block; padding:10px 20px; background:#007bff; color:white; text-decoration:none; border-radius:5px;'>Go to Browse Jobs</a>";

} catch (Exception $e) {
    echo "<div style='padding:20px; background:#ffebee; color:#c62828; border:1px solid #ef9a9a;'>";
    echo "<h3>🚨 Global Error:</h3>" . $e->getMessage();
    echo "</div>";
}
?>
