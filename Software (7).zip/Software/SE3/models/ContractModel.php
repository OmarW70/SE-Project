<?php
class ContractModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // إنشاء عقد جديد
    public function createContract($job_id, $client_id, $freelancer_id, $proposal_id, $amount) {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO contracts (job_id, client_id, freelancer_id, proposal_id, total_price, status) 
                 VALUES (?, ?, ?, ?, ?, 'active')"
            );
            $stmt->execute([$job_id, $client_id, $freelancer_id, $proposal_id, $amount]);
            $contract_id = $this->db->lastInsertId();

            // إنشاء Milestone افتراضي لكامل المبلغ
            $stmt = $this->db->prepare(
                "INSERT INTO milestones (contract_id, title, amount, status) 
                 VALUES (?, 'Initial Project Milestone', ?, 'pending')"
            );
            $stmt->execute([$contract_id, $amount]);

            return $contract_id;
        } catch (PDOException $e) {
            error_log("DB Error in createContract: " . $e->getMessage());
            return false;
        }
    }

    // جلب الـ Milestones لعقد معين
    public function getMilestones($contract_id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM milestones WHERE contract_id = ? ORDER BY created_at ASC");
            $stmt->execute([$contract_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("DB Error in getMilestones: " . $e->getMessage());
            return [];
        }
    }

    // تحديث حالة الـ Milestone (Fund / Release)
    public function updateMilestoneStatus($milestone_id, $status) {
        try {
            $stmt = $this->db->prepare("UPDATE milestones SET status = ? WHERE milestone_id = ?");
            return $stmt->execute([$status, $milestone_id]);
        } catch (PDOException $e) {
            error_log("DB Error in updateMilestoneStatus: " . $e->getMessage());
            return false;
        }
    }

    // جلب كل العقود النشطة في الداتا بيز (للعرض العام أو الاختبار)
    public function getAllActiveContracts() {
        try {
            // استعلام مباشر وقوي لجلب كل العقود النشطة
            $sql = "SELECT c.*, 
                           j.title as job_title, 
                           u1.first_name as f_fname, u1.last_name as f_lname, 
                           u2.first_name as c_fname, u2.last_name as c_lname
                    FROM contracts c
                    LEFT JOIN jobs j ON c.job_id = j.job_id
                    LEFT JOIN users u1 ON c.freelancer_id = u1.user_id
                    LEFT JOIN users u2 ON c.client_id = u2.user_id
                    WHERE LOWER(c.status) = 'active'
                    ORDER BY c.contract_id DESC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            error_log("Found " . count($results) . " active contracts in DB.");
            return $results;
        } catch (PDOException $e) {
            error_log("DB Error in getAllActiveContracts: " . $e->getMessage());
            return [];
        }
    }

    // جلب العقود النشطة للمستخدم (سواء كان كلاينت أو فريلانسر)
    public function getActiveContracts($user_id, $role) {
        $column = ($role === 'Client') ? 'client_id' : 'freelancer_id';
        $other_user_join = ($role === 'Client') ? 'freelancer_id' : 'client_id';
        
        try {
            $sql = "SELECT c.*, j.title as job_title, u.first_name, u.last_name 
                    FROM contracts c
                    LEFT JOIN jobs j ON c.job_id = j.job_id
                    LEFT JOIN users u ON c.$other_user_join = u.user_id
                    WHERE c.$column = ? AND c.status = 'active'
                    ORDER BY c.created_at DESC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("DB Error in getActiveContracts: " . $e->getMessage());
            return [];
        }
    }
}
?>
