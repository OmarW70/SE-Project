<?php
class ProposalModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // تقديم عرض جديد
    public function createProposal($job_id, $freelancer_id, $bid_amount, $delivery_time, $cover_letter) {
        $stmt = $this->db->prepare(
            "INSERT INTO proposals (job_id, freelancer_id, bid_amount, delivery_time, cover_letter) 
             VALUES (?, ?, ?, ?, ?)"
        );
        return $stmt->execute([$job_id, $freelancer_id, $bid_amount, $delivery_time, $cover_letter]);
    }

    // جلب العروض لوظيفة معينة (للكلاينت)
    public function getProposalsByJob($job_id) {
        try {
            $stmt = $this->db->prepare(
                "SELECT p.*, u.first_name, u.last_name 
                 FROM proposals p
                 JOIN users u ON p.freelancer_id = u.user_id
                 WHERE p.job_id = ?
                 ORDER BY p.created_at DESC"
            );
            $stmt->execute([$job_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getProposalsByJob(): " . $e->getMessage());
            return [];
        }
    }

    // جلب أحدث العروض لكلاينت معين (لكل وظائفه)
    public function getRecentProposalsByClient($client_id) {
        try {
            $stmt = $this->db->prepare(
                "SELECT p.*, j.title as job_title, u.first_name, u.last_name 
                 FROM proposals p
                 JOIN jobs j ON p.job_id = j.job_id
                 JOIN users u ON p.freelancer_id = u.user_id
                 WHERE j.client_id = ? AND p.status = 'pending'
                 ORDER BY p.created_at DESC
                 LIMIT 10"
            );
            $stmt->execute([$client_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getRecentProposalsByClient(): " . $e->getMessage());
            return [];
        }
    }

    // تحديث حالة العرض (مثلاً عند القبول)
    public function updateStatus($proposal_id, $status) {
        try {
            $stmt = $this->db->prepare("UPDATE proposals SET status = ? WHERE proposal_id = ?");
            return $stmt->execute([$status, $proposal_id]);
        } catch(PDOException $e) {
            error_log("DB Error in updateStatus(): " . $e->getMessage());
            return false;
        }
    }

    public function getProposalById($proposal_id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM proposals WHERE proposal_id = ?");
            $stmt->execute([$proposal_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getProposalById(): " . $e->getMessage());
            return null;
        }
    }

    // جلب كل العروض المقدمة من فريلانسر معين
    public function getProposalsByFreelancer($freelancer_id) {
        try {
            $stmt = $this->db->prepare(
                "SELECT p.*, j.title as job_title 
                 FROM proposals p
                 JOIN jobs j ON p.job_id = j.job_id
                 WHERE p.freelancer_id = ?
                 ORDER BY p.created_at DESC"
            );
            $stmt->execute([$freelancer_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getProposalsByFreelancer(): " . $e->getMessage());
            return [];
        }
    }
}
?>
