<?php
// freelancer_dashboard.php — Freelancer Dashboard
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';
require_once '../models/ContractModel.php';
require_once '../models/ProposalModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?mode=login");
    exit();
}

$userModel = new UserModel();
$user      = $userModel->getUserById($_SESSION['user_id']);

if (!$user) {
    session_destroy();
    header("Location: index.php?mode=login");
    exit();
}

$contractModel = new ContractModel();
$proposalModel = new ProposalModel();

// جلب كل العقود النشطة من الداتا بيز كما طلب المستخدم
$activeContracts = $contractModel->getAllActiveContracts();
$myProposals = $proposalModel->getProposalsByFreelancer($_SESSION['user_id']);

$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name']  = $user['last_name'];
$_SESSION['email']      = $user['email'];

$firstName = htmlspecialchars($user['first_name']);
$lastName  = htmlspecialchars($user['last_name']);
$email     = htmlspecialchars($user['email']);
$fullName  = $firstName . ' ' . $lastName;
$initials  = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
$shortName = $firstName . '. ' . $lastName;
$edit_profile_success1   = $_GET['edit_profile_success1']   ?? '';
$edit_profile_error1 = $_GET['edit_profile_error1'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Freelancer Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/chat-sidebar.css">
</head>
<body>
<div class="wrapper">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo"><div class="brand">Free<span>Lynk</span></div></div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);"><?= $initials ?></div>
      <div class="sidebar-user-info">
        <div class="name"><?= $shortName ?></div>
        <div class="role">Freelancer</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Overview</div>
      <div class="nav-item active" data-page="freelancer_dashboard.php">
        <i class="fa-solid fa-gauge-high"></i> Dashboard
      </div>
      <div class="nav-section-label mt-3">Work</div>
      <div class="nav-item" onclick="window.location='jobs.php'">
        <i class="fa-solid fa-magnifying-glass"></i> Browse Jobs
      </div>
      <div class="nav-section-label mt-3">Disputes</div>
      <div class="nav-item" onclick="openDisputeFlow()">
        <i class="fa-solid fa-triangle-exclamation"></i> Open Dispute
      </div>
    </nav>
    <div class="sidebar-footer">
      <div class="nav-item" onclick="window.location='index.php'">
        <i class="fa-solid fa-right-from-bracket"></i> Sign Out
      </div>
    </div>
  </aside>

  
  <!-- ── Main ── -->
  <div class="main">
    <div class="topbar">

      <span class="page-title">Dashboard</span>
      <div class="topbar-actions">
         <button class="btn btn-sm btn-primary" onclick="openModal('editProfileModal')">
          <i class="fa-solid fa-pen"></i> Edit Profile
        </button>
        <div class="icon-btn" id="notifBtn">
          <i class="fa-solid fa-bell"></i>
          <span class="notif-dot"></span>
        </div>
        <a href="freelancer_profile.php">
        </a>
      </div>
    </div>

    <div class="modal-backdrop hidden" id="editProfileModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Profile</span>
      <button class="icon-btn" onclick="closeModal('editProfileModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
 <?php if ($edit_profile_success1 === 'updated'): ?>
                <div style="background:rgba(0,229,192,.1);border:1px solid rgba(0,229,192,.3);border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13px;color:var(--success);">
                  <i class="fa-solid fa-circle-check"></i> &nbsp; Data updated successfully!
                </div>
                <?php elseif ($edit_profile_error1 === 'email_taken'): ?>
                <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13px;color:var(--danger);">
                  <i class="fa-solid fa-circle-xmark"></i> &nbsp; Email already in use, please choose another.
                </div>
                <?php endif; ?>

                <form action="../controllers/update_profile.php" method="POST" class="modal-body">
                  <div class="form-group">
                    <label class="form-label">First Name</label>
                    <input type="text" name="first_name" class="form-control" value="<?= $firstName ?>" required>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="last_name" class="form-control" value="<?= $lastName ?>" required>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= $email ?>" required>
                  </div>
                  <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-save"></i> Save Changes
                  </button>
                </form>
  </div>

</div>

    <div class="page-content">

      <!-- ══ ROW 1 — Active Contracts + Milestones ══ -->
      <div class="grid-2 mb-6">

        <!-- Active Contracts -->
        <div class="card fade-in-1">
          <div class="card-header">
            <span class="card-title">
              <i class="fa-solid fa-file-contract text-accent"></i> &nbsp;Active Contracts
            </span>
            <span class="badge badge-info" id="contractCountBadge">2 active</span>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Client</th>
                  <th>Project</th>
                  <th>Progress</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($activeContracts)): ?>
                <tr>
                  <td colspan="5" style="text-align:center;padding:20px;color:var(--muted);">No active contracts found.</td>
                </tr>
                <?php else: ?>
                  <?php foreach ($activeContracts as $contract): 
                    $c_fname = $contract['c_fname'] ?? 'Unknown';
                    $c_lname = $contract['c_lname'] ?? 'Client';
                    $clientName = htmlspecialchars($c_fname . ' ' . $c_lname);
                    $initials = strtoupper(substr($c_fname, 0, 1) . substr($c_lname, 0, 1));
                  ?>
                  <tr class="contract-row" data-contract="<?= $contract['contract_id'] ?>" 
                      onclick="selectContract(<?= $contract['contract_id'] ?>)" style="cursor:pointer;">
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar" style="width:30px;height:30px;font-size:11px;"><?= $initials ?></div>
                        <span><?= $clientName ?></span>
                      </div>
                    </td>
                    <td><?= htmlspecialchars($contract['job_title']) ?></td>
                    <td>
                      <div class="progress-wrap" style="min-width:80px;">
                        <div class="progress-bar">
                          <div class="progress-fill" style="width:0%"></div>
                        </div>
                      </div>
                    </td>
                    <td><span class="badge badge-info"><?= ucfirst($contract['status']) ?></span></td>
                    <td>
                      <button class="btn btn-sm btn-danger" title="Open Dispute"
                        onclick="event.stopPropagation();openDisputeFor(<?= $contract['contract_id'] ?>,'<?= addslashes($contract['job_title']) ?>','<?= addslashes($clientName) ?>')">
                        <i class="fa-solid fa-flag"></i>
                      </button>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Milestones Panel -->
        <div class="card fade-in-2">
          <div class="card-header">
            <span class="card-title" id="milestonesTitle">
              <i class="fa-solid fa-flag-checkered text-accent"></i>
              &nbsp;Milestones — React Job
            </span>
            <span class="badge badge-info">FR14</span>
          </div>
          <div class="card-body" id="milestonesBody">
            <!-- rendered by JS -->
          </div>
        </div>

      </div>

      <!-- ══ ROW 2 — Payout + Interview ══ -->
      <div class="grid-2 mb-6">

        <!-- Payout Panel -->
        <div class="card fade-in-1">
          <div class="card-header">
            <span class="card-title">
              <i class="fa-solid fa-circle-dollar-to-slot text-accent"></i>
              &nbsp;Earnings &amp; Payout
            </span>
            <span class="badge badge-info" id="payoutContractBadge">Contract #54</span>
          </div>
          <div class="card-body" id="payoutBody">
            <!-- rendered by JS -->
          </div>
        </div>

        <!-- Upcoming Interview -->
        <div class="card fade-in-2">
          <div class="card-header">
            <span class="card-title">
              <i class="fa-solid fa-calendar-days text-accent"></i>
              &nbsp;Upcoming Interview
            </span>
            <span class="badge badge-success">Confirmed</span>
          </div>
          <div class="card-body">
            <div style="background:linear-gradient(135deg,rgba(0,229,192,.08),rgba(108,99,255,.08));
                        border:1px solid var(--border);border-radius:12px;padding:20px;margin-bottom:16px;">
              <div style="display:flex;gap:16px;align-items:center;">
                <div style="background:rgba(0,229,192,.1);border:1px solid rgba(0,229,192,.2);
                            border-radius:10px;padding:12px 16px;text-align:center;">
                  <div class="text-accent font-bold" style="font-size:24px;">22</div>
                  <div class="text-muted text-sm">April</div>
                </div>
                <div>
                  <div class="font-bold">Technical Interview</div>
                  <div class="text-muted text-sm mt-1">
                    <i class="fa-solid fa-user"></i> Abdulrahman Nassar (Client)
                  </div>
                  <div class="text-muted text-sm mt-1">
                    <i class="fa-solid fa-clock"></i> 10:00 AM &nbsp;·&nbsp;
                    <i class="fa-solid fa-globe"></i> EET
                  </div>
                  <div class="text-muted text-sm mt-1">
                    <i class="fa-solid fa-video text-accent"></i> Zoom Meeting
                  </div>
                </div>
              </div>
            </div>
            <div style="background:rgba(0,229,192,.05);border:1px solid rgba(0,229,192,.15);
                        border-radius:8px;padding:12px;font-size:12px;color:var(--muted);
                        margin-bottom:16px;">
              <i class="fa-solid fa-circle-info text-accent"></i>
              &nbsp;Timezone auto-adjusted — Cairo EET (UTC+3) (FR34)
            </div>
            <div class="flex gap-2">
              <button class="btn btn-sm btn-primary" style="flex:1;justify-content:center;"
                onclick="copyText('https://zoom.us/j/123456789');showToast('Meeting link copied!')">
                <i class="fa-solid fa-link"></i> Join Link
              </button>
              <button class="btn btn-sm btn-secondary"
                onclick="showToast('Interview confirmed!')">
                <i class="fa-solid fa-check"></i> Confirm
              </button>
              <button class="btn btn-sm btn-secondary"
                onclick="showToast('Reschedule request sent')">
                <i class="fa-solid fa-calendar-xmark"></i>
              </button>
            </div>
          </div>
        </div>

      </div>

      <!-- ══ ROW 3 — My Proposals ══ -->
      <div class="card mb-6 fade-in-1" style="height: auto;">
        <div class="card-header">
          <span class="card-title">
            <i class="fa-solid fa-paper-plane text-accent"></i>
            &nbsp;My Proposals (FR9 — Version Tracking)
          </span>
          <span class="badge badge-info">4 active</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Job</th><th>My Bid</th><th>Submitted</th>
                <th>Versions</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($myProposals)): ?>
              <tr>
                <td colspan="6" style="text-align:center;padding:20px;color:var(--muted);">You haven't submitted any proposals yet.</td>
              </tr>
              <?php else: ?>
                <?php foreach($myProposals as $p): 
                  $statusBadge = ($p['status'] === 'accepted') ? 'badge-success' : (($p['status'] === 'rejected') ? 'badge-danger' : 'badge-warn');
                ?>
                <tr>
                  <td class="font-bold"><?= htmlspecialchars($p['job_title']) ?></td>
                  <td class="text-accent">$<?= number_format($p['bid_amount']) ?></td>
                  <td class="text-muted text-sm"><?= date('M d, Y', strtotime($p['created_at'])) ?></td>
                  <td><span class="badge badge-purple">v1</span></td>
                  <td><span class="badge <?= $statusBadge ?>"><?= ucfirst($p['status']) ?></span></td>
                  <td>
                    <?php if($p['status'] === 'pending'): ?>
                    <button class="btn btn-sm btn-secondary" onclick="showToast('Proposal editing not implemented yet.')">
                      <i class="fa-solid fa-pen"></i> Edit
                    </button>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div><!-- /page-content -->
  </div><!-- /main -->
</div><!-- /wrapper -->

<!-- ════════════════════════
     MODALS
     ════════════════════════ -->

<!-- Submit Work Modal -->
<div class="modal-backdrop hidden" id="submitWorkModal">
  <div class="modal" style="max-width:520px; max-height:95vh; overflow-y: auto;">
    <div class="modal-header">
      <span class="modal-title" id="submitWorkTitle">
        <i class="fa-solid fa-upload text-accent"></i> &nbsp;Submit Work
      </span>
      <button class="icon-btn" onclick="closeModal('submitWorkModal')">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <div class="modal-body">

      <!-- milestone info banner -->
      <div id="submitMilestoneBanner"
           style="background:rgba(0,229,192,.07);border:1px solid rgba(0,229,192,.2);
                  border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:13px;">
      </div>

      <!-- QA Checklist -->
      <div style="background:var(--bg3);border-radius:8px;padding:14px;margin-bottom:16px;">
        <div class="text-sm font-bold mb-3">
          <i class="fa-solid fa-clipboard-check text-accent"></i>
          &nbsp;QA Checklist — complete all before submitting (FR29)
        </div>
        <div style="display:flex;flex-direction:column;gap:8px;" id="qaList">
          <?php
          $checks = [
            'Code review passed',
            'Unit tests written',
            'Responsive on mobile',
            'Documentation updated',
            'Performance tested',
          ];
          foreach($checks as $ch): ?>
          <label style="display:flex;align-items:center;gap:9px;cursor:pointer;font-size:13px;">
            <input type="checkbox" style="accent-color:var(--accent);" onchange="checkQA()">
            <span><?= $ch ?></span>
          </label>
          <?php endforeach; ?>
        </div>
        <div id="qaWarning"
             style="margin-top:10px;font-size:12px;color:var(--warn);display:none;">
          <i class="fa-solid fa-triangle-exclamation"></i>
          &nbsp;Tick all items to unlock submission
        </div>
      </div>

      <!-- Progress Slider -->
      <div class="form-group">
        <label class="form-label">Progress Update</label>
        <div style="display:flex;align-items:center;gap:12px;">
          <input type="range" id="progressSlider" min="0" max="100" value="65"
                 style="-webkit-appearance:none;width:100%;height:4px;border-radius:2px;
                        background:var(--border);outline:none;accent-color:var(--accent);"
                 oninput="document.getElementById('progressVal').textContent=this.value+'%'">
          <span id="progressVal" class="text-accent font-bold"
                style="min-width:40px;text-align:right;">65%</span>
        </div>
      </div>

      <!-- File upload -->
      <div class="form-group">
        <label class="form-label">Upload Deliverable Files</label>
        <input type="file" class="form-control" multiple>
      </div>

      <!-- Notes -->
      <div class="form-group">
        <label class="form-label">Notes for Client</label>
        <textarea class="form-control" id="submitNotes" rows="3"
          placeholder="Describe what was completed in this submission…"></textarea>
      </div>

      <div style="background:rgba(0,229,192,.06);border:1px solid rgba(0,229,192,.15);
                  border-radius:8px;padding:10px 14px;font-size:12px;color:var(--muted);">
        <i class="fa-solid fa-circle-info text-accent"></i>
        &nbsp;Triggers Deliverable Workflow: Track Deadline + Project Phases (FR15)
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm"
        onclick="closeModal('submitWorkModal')">Cancel</button>
      <button class="btn btn-primary btn-sm" id="submitWorkBtn"
        onclick="confirmSubmitWork()">
        <i class="fa-solid fa-paper-plane"></i> Submit Work
      </button>
    </div>
  </div>
</div>

<!-- Dispute Modal -->
<div class="modal-backdrop hidden" id="disputeModal">
  <div class="modal" style="max-width:520px;">
    <div class="modal-header">
      <span class="modal-title">
        <i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Open Dispute
      </span>
      <button class="icon-btn" onclick="closeModal('disputeModal')">
        <i class="fa-solid fa-xmark"></i>
      </button>
    </div>
    <div class="modal-body">
      <div id="disputeBanner"
           style="display:none;background:rgba(239,68,68,.07);border:1px solid rgba(239,68,68,.2);
                  border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:13px;">
        <i class="fa-solid fa-file-contract text-danger"></i>
        &nbsp;<span id="disputeBannerText"></span>
      </div>
      <div class="form-group">
        <label class="form-label">Contract</label>
        <select class="form-control" id="disputeContractSelect">
          <option value="54">Contract #54 — React Job (A. Nassar)</option>
          <option value="55">Contract #55 — UI Design (Sara Hassan)</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Reason</label>
        <textarea class="form-control"
          placeholder="Describe the issue in detail…"></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Upload Evidence (FR25)</label>
        <input type="file" class="form-control" multiple>
      </div>
      <div style="background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.2);
                  border-radius:8px;padding:10px 14px;font-size:12px;color:var(--muted);">
        <i class="fa-solid fa-circle-info text-danger"></i>
        &nbsp;Restricted channel created (FR27). Neutral admin assigned (FR26).
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm"
        onclick="closeModal('disputeModal')">Cancel</button>
      <button class="btn btn-danger btn-sm"
        onclick="closeModal('disputeModal');showToast('Dispute filed. Admin assigned.','warn')">
        <i class="fa-solid fa-flag"></i> File Dispute
      </button>
    </div>
  </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/chat-sidebar.js"></script>
<script src="../assets/js/contractEvents.js"></script>
<script>
/* ════════════════════════════════════════════════════════════
   CONTRACT DATA
   ════════════════════════════════════════════════════════════ */
const contractsData = {
  <?php foreach($activeContracts as $c): 
    $c_fname = $c['c_fname'] ?? 'Unknown';
    $c_lname = $c['c_lname'] ?? 'Client';
    $milestones = $contractModel->getMilestones($c['contract_id']);
    
    $releasedTotal = 0;
    $escrowLocked = 0;
    foreach($milestones as $m) {
        if($m['status'] == 'completed') $releasedTotal += $m['amount'];
        if($m['status'] == 'funded') $escrowLocked += $m['amount'];
    }
  ?>
  <?= $c['contract_id'] ?>: {
    id: <?= $c['contract_id'] ?>, 
    title: '<?= addslashes($c['job_title'] ?? 'Project') ?>', 
    client: '<?= addslashes($c_fname . " " . $c_lname) ?>',
    clientInitials: '<?= strtoupper(substr($c_fname, 0, 1) . substr($c_lname, 0, 1)) ?>', 
    clientGrad: '135deg,#6c63ff,#00e5c0',
    totalValue: <?= $c['total_price'] ?>, 
    releasedTotal: <?= $releasedTotal ?>, 
    escrowLocked: <?= $escrowLocked ?>,
    platformFee: 0.10,   // 10% standard
    coolingDays: 5,
    milestones: [
      <?php foreach($milestones as $m): ?>
      { 
        id: <?= $m['milestone_id'] ?>, 
        title: '<?= addslashes($m['title']) ?>', 
        amount: <?= $m['amount'] ?>, 
        status: '<?= ($m['status'] == 'completed') ? 'done' : (($m['status'] == 'funded') ? 'active' : (($m['status'] == 'submitted') ? 'active' : 'active')) ?>', 
        progress: <?= ($m['status'] == 'completed') ? 100 : (($m['status'] == 'submitted') ? 100 : 0) ?>, 
        funded: <?= ($m['status'] == 'funded' || $m['status'] == 'submitted' || $m['status'] == 'completed') ? 'true' : 'false' ?>,
        submitted: <?= ($m['status'] == 'submitted' || $m['status'] == 'completed') ? 'true' : 'false' ?>,
        due: 'TBD', 
        submittedDate: null 
      },
      <?php endforeach; ?>
    ],
  },
  <?php endforeach; ?>
};

let activeContractId = <?= !empty($activeContracts) ? $activeContracts[0]['contract_id'] : 'null' ?>;
let submitTargetMilestoneId = null;

const ROW_ACTIVE = 'background:rgba(0,229,192,.07);outline:2px solid var(--accent);outline-offset:-2px;border-radius:6px;';

// Initial render
window.addEventListener('DOMContentLoaded', () => {
  if (activeContractId) {
    const firstRow = document.querySelector(`.contract-row[data-contract="${activeContractId}"]`);
    if (firstRow) {
      firstRow.style.cssText = ROW_ACTIVE;
      firstRow.classList.add('active-row');
    }
    renderMilestones(activeContractId);
    renderPayout(activeContractId);
  }
});

/* ════════════════════════════════════════════════════════════
   STAT CARDS
   ════════════════════════════════════════════════════════════ */
function updateStats() {
  const totalPending  = Object.values(contractsData)
    .reduce((s, c) => s + c.escrowLocked, 0);
  const activeCount   = Object.values(contractsData)
    .filter(c => c.milestones.some(m => m.status === 'active')).length;
  const c54           = contractsData[54];
  const earnAfterFee  = Math.round(c54.releasedTotal * (1 - c54.platformFee));

  flash('statEarnings',  '$' + earnAfterFee.toLocaleString());
  flash('statPending',   '$' + totalPending.toLocaleString());
  flash('statContracts', activeCount);

  const el = document.getElementById('statPendingChange');
  if (el) {
    el.textContent = totalPending > 0 ? 'In escrow' : 'Nothing locked';
    el.className   = totalPending > 0 ? 'change up'  : 'change down';
  }
}

function flash(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.transition = 'color .3s';
  el.style.color      = 'var(--accent)';
  el.textContent      = val;
  setTimeout(() => { el.style.color = ''; }, 600);
}

/* ════════════════════════════════════════════════════════════
   SELECT CONTRACT
   ════════════════════════════════════════════════════════════ */
function selectContract(id) {
  if (activeContractId === id) return;
  activeContractId = id;

  document.querySelectorAll('.contract-row').forEach(r => {
    r.style.cssText = '';
    r.classList.remove('active-row');
  });
  const row = document.querySelector(`.contract-row[data-contract="${id}"]`);
  if (row) { row.style.cssText = ROW_ACTIVE; row.classList.add('active-row'); }

  renderMilestones(id);
  renderPayout(id);
}

/* ════════════════════════════════════════════════════════════
   RENDER MILESTONES
   ════════════════════════════════════════════════════════════ */
function renderMilestones(id) {
  const c     = contractsData[id];
  const title = document.getElementById('milestonesTitle');
  const body  = document.getElementById('milestonesBody');

  title.innerHTML =
    `<i class="fa-solid fa-flag-checkered text-accent"></i>&nbsp; Milestones — ${c.title}`;

  fadeIn(body, '<div class="milestone-list">' +
    c.milestones.map(m => buildMilestoneHTML(id, m)).join('') +
  '</div>');
}

function buildMilestoneHTML(contractId, m) {
  const dotClass =
    m.status === 'done'   ? 'milestone-dot done'   :
    m.status === 'active' ? 'milestone-dot active'  : 'milestone-dot';
  const dotIcon  =
    m.status === 'done'   ? '<i class="fa-solid fa-check"></i>'                              :
    m.status === 'active' ? '<i class="fa-solid fa-spinner fa-spin" style="font-size:10px;"></i>' :
                            '<i class="fa-solid fa-lock" style="font-size:10px;"></i>';
  let meta = '';

  if (m.status === 'done') {
    meta = `<div class="milestone-meta">
              Completed · ${m.due}
              &nbsp;·&nbsp;
              <span style="color:var(--success);">$${m.amount.toLocaleString()} released</span>
            </div>`;

  } else if (m.status === 'active') {
    const c      = contractsData[contractId];
    const funded = c.escrowLocked >= m.amount;

    const escrowNote = funded
      ? `<div style="background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.2);
                     border-radius:8px;padding:7px 12px;font-size:12px;
                     color:var(--success);margin-bottom:10px;">
           <i class="fa-solid fa-lock"></i>&nbsp;
           $${m.amount.toLocaleString()} secured in escrow — you can work (FR20)
         </div>`
      : `<div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);
                     border-radius:8px;padding:7px 12px;font-size:12px;
                     color:var(--warn);margin-bottom:10px;">
           <i class="fa-solid fa-triangle-exclamation"></i>&nbsp;
           Waiting for client to fund this milestone (FR20)
         </div>`;

    const btn = funded
      ? `<button class="btn btn-sm btn-primary"
           onclick="openSubmitWork(${contractId},${m.id})">
           <i class="fa-solid fa-upload"></i> Submit Work
         </button>`
      : `<button class="btn btn-sm btn-secondary" disabled
           style="opacity:.45;cursor:not-allowed;" title="Fund required first">
           <i class="fa-solid fa-upload"></i> Submit Work
         </button>`;

    meta = `
      <div class="milestone-meta flex gap-3 mt-1">
        <span>Due: ${m.due}</span>
        <span class="${funded ? 'text-accent' : 'text-warn'}">
          $${m.amount.toLocaleString()} ${funded ? 'in escrow' : '— not funded'}
        </span>
      </div>
      <div class="progress-wrap mt-2">
        <div class="progress-label">
          <span>Progress</span>
          <span id="lbl_${contractId}_${m.id}">${m.progress}%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill"
               id="fill_${contractId}_${m.id}"
               style="width:${m.progress}%"
               data-width="${m.progress}%"></div>
        </div>
      </div>
      <div style="margin-top:12px;">${escrowNote}</div>
      <div class="flex gap-2">${btn}</div>`;

  } else {
    meta = `<div class="milestone-meta">
              Locked — complete previous phase first
              &nbsp;·&nbsp; $${m.amount.toLocaleString()}
            </div>`;
  }

  return `
    <div class="milestone-item">
      <div class="${dotClass}">${dotIcon}</div>
      <div class="milestone-content">
        <div class="milestone-title">${m.title}</div>
        ${meta}
      </div>
    </div>`;
}

/* ════════════════════════════════════════════════════════════
   RENDER PAYOUT
   ════════════════════════════════════════════════════════════ */
function renderPayout(id) {
  const c    = contractsData[id];
  const body = document.getElementById('payoutBody');
  const bdg  = document.getElementById('payoutContractBadge');
  if (!body) return;

  bdg.textContent = 'Contract #' + id;

  const fee         = c.platformFee;
  const netReleased = Math.round(c.releasedTotal * (1 - fee));
  const netPending  = Math.round(c.escrowLocked  * (1 - fee));
  const totalValue  = c.milestones.reduce((s, m) => s + m.amount, 0);
  const remaining   = totalValue - c.releasedTotal;
  const pct         = totalValue > 0
    ? Math.round((c.releasedTotal / totalValue) * 100) : 0;
  const isComplete  = c.milestones.every(m => m.status === 'done');

  /* history rows — done milestones */
  const histRows = c.milestones
    .filter(m => m.status === 'done')
    .map(m => `
      <div class="flex items-center gap-3"
           style="justify-content:space-between;background:var(--bg3);
                  border-radius:8px;padding:10px 14px;">
        <div>
          <div class="text-sm font-bold">
            ${c.title} — ${m.title.split('—')[0].trim()}
          </div>
          <div class="text-muted text-sm">
            Released · ${m.submittedDate || m.due}
          </div>
        </div>
        <div class="text-success font-bold">
          +$${Math.round(m.amount*(1-fee)).toLocaleString()}
        </div>
      </div>`)
    .join('');

  /* active milestone row */
  const activeMil = c.milestones.find(m => m.status === 'active');
  const activeRow = activeMil
    ? (c.escrowLocked > 0
        ? `<div class="flex items-center gap-3"
                style="justify-content:space-between;background:var(--bg3);
                       border-radius:8px;padding:10px 14px;">
             <div>
               <div class="text-sm font-bold">
                 ${c.title} — ${activeMil.title.split('—')[0].trim()}
               </div>
               <div class="text-muted text-sm">
                 <i class="fa-solid fa-clock text-warn"></i>
                 Awaiting approval · ${c.coolingDays}d cooling (FR24)
               </div>
             </div>
             <div class="text-warn font-bold">
               $${netPending.toLocaleString()} pending
             </div>
           </div>`
        : `<div class="flex items-center gap-3"
                style="justify-content:space-between;background:var(--bg3);
                       border-radius:8px;padding:10px 14px;opacity:.55;">
             <div>
               <div class="text-sm font-bold">
                 ${c.title} — ${activeMil.title.split('—')[0].trim()}
               </div>
               <div class="text-muted text-sm">
                 Waiting for client to fund
               </div>
             </div>
             <div class="text-muted font-bold">
               $${activeMil.amount.toLocaleString()} —
             </div>
           </div>`)
    : '';

  /* payout button label */
  const payoutLabel = netReleased > 0
    ? `Request Payout ($${netReleased.toLocaleString()})`
    : 'Request Payout';
  const payoutClick = netReleased > 0
    ? `showToast('Payout of $${netReleased.toLocaleString()} initiated! (FR24)')`
    : `showToast('No balance to payout yet.','warn')`;

  fadeIn(body, `
    <!-- Balance -->
    <div style="background:var(--bg3);border-radius:10px;padding:16px;
                margin-bottom:16px;text-align:center;">
      <div class="text-muted text-sm mb-1">
        Available Balance (after ${Math.round(fee*100)}% fee)
      </div>
      <div class="font-bold" style="font-size:32px;color:var(--accent);">
        $${netReleased.toLocaleString()}
      </div>
      <div class="text-muted text-sm mt-1">FR22 · FR23</div>
    </div>

    <!-- Transaction list -->
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:16px;">
      ${histRows || '<div class="text-muted text-sm" style="text-align:center;padding:8px;">No payments released yet</div>'}
      ${activeRow}
    </div>

    <!-- Release progress -->
    <div style="background:var(--bg3);border-radius:8px;padding:12px 14px;margin-bottom:14px;">
      <div style="display:flex;justify-content:space-between;font-size:11px;
                  color:var(--muted);margin-bottom:6px;">
        <span>Released</span><span>Remaining</span>
      </div>
      <div class="progress-bar" style="height:8px;border-radius:4px;">
        <div class="progress-fill"
             style="width:${pct}%;height:100%;
                    border-radius:4px;background:var(--success);"></div>
      </div>
      <div style="display:flex;justify-content:space-between;
                  font-size:11px;margin-top:5px;">
        <span style="color:var(--success);font-weight:700;">
          $${c.releasedTotal.toLocaleString()} / $${totalValue.toLocaleString()}
        </span>
        <span style="color:var(--muted);">
          $${remaining.toLocaleString()} remaining
        </span>
      </div>
    </div>

    <!-- Fee notice -->
    <div style="background:rgba(0,229,192,.06);border:1px solid rgba(0,229,192,.15);
                border-radius:8px;padding:10px 14px;font-size:12px;
                color:var(--muted);margin-bottom:14px;">
      <i class="fa-solid fa-circle-info text-accent"></i>
      &nbsp;Platform fee: <strong style="color:var(--text)">
        ${Math.round(fee*100)}%
      </strong>
      ${fee < 0.10 ? '— loyalty discount applied (FR22)' : '— standard rate'}
    </div>

    <!-- Payout button -->
    <button class="btn btn-primary w-full" style="justify-content:center;"
      onclick="${payoutClick}">
      <i class="fa-solid fa-money-bill-transfer"></i> ${payoutLabel}
    </button>
    ${isComplete
      ? `<div class="text-sm text-success"
              style="text-align:center;margin-top:10px;">
           <i class="fa-solid fa-circle-check"></i>
           Contract fully completed 🎉
         </div>`
      : ''}`
  );
}

/* ════════════════════════════════════════════════════════════
   OPEN SUBMIT WORK MODAL
   ════════════════════════════════════════════════════════════ */
function openSubmitWork(contractId, milestoneId) {
  const c = contractsData[contractId];
  const m = c.milestones.find(ms => ms.id === milestoneId);
  if (!m) return;

  submitTargetMilestoneId = milestoneId;

  document.getElementById('submitWorkTitle').innerHTML =
    `<i class="fa-solid fa-upload text-accent"></i> &nbsp;Submit Work — ${m.title}`;

  document.getElementById('submitMilestoneBanner').innerHTML =
    `<i class="fa-solid fa-file-contract text-accent"></i>
     &nbsp;<strong>Contract #${contractId}</strong> · ${c.title}
     &nbsp;·&nbsp; <strong>${m.title}</strong>
     &nbsp;·&nbsp; <span class="text-accent">$${m.amount.toLocaleString()} in escrow</span>`;

  /* set slider to current progress */
  const slider = document.getElementById('progressSlider');
  slider.value = m.progress;
  document.getElementById('progressVal').textContent = m.progress + '%';

  /* reset QA */
  document.querySelectorAll('#qaList input[type=checkbox]')
    .forEach(cb => { cb.checked = false; });
  document.getElementById('qaWarning').style.display = 'none';
  document.getElementById('submitNotes').value = '';

  openModal('submitWorkModal');
}

function submitWork(contractId, milestoneId) {
  const c = contractsData[contractId];
  const m = c.milestones.find(ms => ms.id === milestoneId);
  
  if (!m || !m.funded) {
    showToast('Wait for client to fund this milestone.', 'error');
    return;
  }

  if(!confirm("Submit work for this milestone? This will notify the client to release payment.")) return;

  fetch('../controllers/manage_milestone.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `milestone_id=${milestoneId}&action=submit`
  })
  .then(res => res.json())
  .then(data => {
    if(data.success) {
      showToast("Work submitted successfully! Waiting for client approval.");
      setTimeout(() => window.location.reload(), 1000);
    } else {
      showToast(data.error || "Error submitting work", "error");
    }
  });
}

/* ════════════════════════════════════════════════════════════
   CONFIRM SUBMIT WORK — updates progress + re-renders
   ════════════════════════════════════════════════════════════ */
function confirmSubmitWork() {
  /* QA gate */
  const boxes   = document.querySelectorAll('#qaList input[type=checkbox]');
  const allDone = [...boxes].every(b => b.checked);
  if (!allDone) {
    document.getElementById('qaWarning').style.display = '';
    showToast('Complete all QA checks first! (FR29)', 'warn');
    return;
  }

  const newProgress = parseInt(document.getElementById('progressSlider').value);
  const c = contractsData[activeContractId];
  const m = c.milestones.find(ms => ms.id === submitTargetMilestoneId);
  if (!m) return;

  /* update data */
  m.progress = newProgress;
  if (newProgress === 100) m.submittedDate = 'Just now';

  closeModal('submitWorkModal');

  /* ── notify client via cross-page event ── */
  if (typeof window.CE_emit === 'function') {
    window.CE_emit('submitted', activeContractId, submitTargetMilestoneId, m.amount, c.title);
  }

  /* re-render milestone panel */
  renderMilestones(activeContractId);

  /* update table row progress bar */
  const doneCount  = c.milestones.filter(ms => ms.status === 'done').length;
  const overallPct = Math.round(
    ((doneCount * 100) + newProgress) / c.milestones.length
  );
  const fill = document.getElementById(`row${activeContractId}Progress`);
  if (fill) { fill.style.width = overallPct + '%'; fill.dataset.width = overallPct + '%'; }

  updateStats();

  showToast(
    newProgress === 100
      ? 'Work submitted at 100%! Awaiting client approval. (FR15)'
      : `Progress updated to ${newProgress}%. Client notified.`
  );
}

/* ════════════════════════════════════════════════════════════
   QA CHECKLIST
   ════════════════════════════════════════════════════════════ */
function checkQA() {
  const boxes = document.querySelectorAll('#qaList input[type=checkbox]');
  const done  = [...boxes].filter(b => b.checked).length;
  if (done === boxes.length) {
    showToast('All QA checks passed! (FR29)');
    document.getElementById('qaWarning').style.display = 'none';
  }
}

/* ════════════════════════════════════════════════════════════
   DISPUTE HELPERS
   ════════════════════════════════════════════════════════════ */
function openDisputeFor(contractId, projectName, clientName) {
  const sel = document.getElementById('disputeContractSelect');
  if (sel) sel.value = contractId;

  const banner = document.getElementById('disputeBanner');
  const txt    = document.getElementById('disputeBannerText');
  if (banner && txt) {
    txt.innerHTML =
      `<strong>Contract #${contractId}</strong> — ${projectName}
       &nbsp;·&nbsp; Client: <strong>${clientName}</strong>`;
    banner.style.display = '';
  }
  openModal('disputeModal');
}

function openDisputeFlow() {
  const c = contractsData[activeContractId];
  openDisputeFor(activeContractId, c?.title || '—', c?.client || '—');
}

/* ════════════════════════════════════════════════════════════
   UTILITY
   ════════════════════════════════════════════════════════════ */
function fadeIn(el, html) {
  el.style.opacity   = '0';
  el.style.transform = 'translateY(8px)';
  el.style.transition = 'opacity .25s,transform .25s';
  el.innerHTML = html;
  requestAnimationFrame(() => {
    el.style.opacity   = '1';
    el.style.transform = 'translateY(0)';
  });
}

/* ════════════════════════════════════════════════════════════
   INIT
   ════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  const defaultRow = document.querySelector('.contract-row.active-row');
  if (defaultRow) defaultRow.style.cssText = ROW_ACTIVE;

  renderMilestones(54);
  renderPayout(54);
  updateStats();
  loadContracts();

let realContracts = []; // سيتم ملؤه من الـ database

function loadContracts() {
  console.log('Loading contracts...');
  fetch('../controllers/get_contracts.php')
    .then(res => {
      console.log('Response status:', res.status);
      return res.json();
    })
    .then(data => {
      console.log('Contracts data:', data);
      if (data.success) {
        if (data.contracts && data.contracts.length > 0) {
          realContracts = data.contracts;
          updateContractSelect();
          console.log('Contracts loaded:', realContracts.length);
        } else {
          console.warn('No contracts found:', data.debug);
          showToast('No active contracts found. Post a job and wait for freelancer to accept.', 'warn');
        }
      } else {
        console.error('Error:', data.message);
        showToast('Error loading contracts: ' + data.message, 'error');
      }
    })
    .catch(err => {
      console.error('Network error loading contracts:', err);
      showToast('Failed to load contracts', 'error');
    });
}

function updateContractSelect() {
  const select = document.getElementById('disputeContractSelect');
  if (!select) return;
  
  select.innerHTML = realContracts.map(c => 
    `<option value="${c.id}">Contract #${c.id} — ${c.title} (${c.other_party_name})</option>`
  ).join('');
}

function submitDispute() {
  const contractId = parseInt(document.getElementById('disputeContractSelect').value);
  const description = document.getElementById('disputeDescription').value.trim();
  const title = 'Dispute for Contract #' + contractId;

  if (!contractId || !description) {
    showToast('Please fill in all fields.', 'error');
    return;
  }

  const contract = realContracts.find(c => c.id === contractId);
  if (!contract) {
    showToast('Invalid contract.', 'error');
    return;
  }
  console.log('Sending dispute with:', {
    contract_id: contractId,
    title: title,
    description: description,
    other_party_id: contract.other_party_id
  });

  fetch('../controllers/create_dispute.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      contract_id: contractId,
      title: title,
      description: description,
      other_party_id: contract.other_party_id
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log('Dispute response:', data);
    if (data.success) {
      showToast('Dispute created successfully! Channel created.', 'success');
      closeModal('disputeModal');
      document.getElementById('disputeDescription').value = '';
    } else {
      showToast(data.message || 'Failed to create dispute.', 'error');
    }
  })
  .catch(err => {
    console.error('Error:', err);
    showToast('An error occurred: ' + err.message, 'error');
  });
}


  document.getElementById('notifBtn')?.addEventListener('click', () => {
    showToast('Deadline reminder: Phase 2 due Apr 25!', 'warn');
  });
  document.getElementById('burgerBtn')?.addEventListener('click', toggleSidebar);
});
</script>

<?php include 'chat_sidebar.php'; ?>

</body>
</html>