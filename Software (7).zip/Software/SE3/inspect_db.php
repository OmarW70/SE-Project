<?php
require_once 'config/config.php';
require_once 'models/Database.php';

try {
    $db = Database::getInstance();
    echo "<body style='font-family:sans-serif; padding:20px; background:#111; color:#eee;'>";
    echo "<h2>🕵️ Database Deep Inspector</h2>";

    function showTable($db, $tableName) {
        echo "<h3>Table: $tableName</h3>";
        try {
            $stmt = $db->query("SELECT * FROM $tableName");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($rows)) {
                echo "<p style='color:orange'>Table exists but is empty.</p>";
            } else {
                echo "<table border='1' style='border-collapse:collapse; width:100%; text-align:left;'>";
                echo "<tr style='background:#333;'>";
                foreach (array_keys($rows[0]) as $col) echo "<th style='padding:8px;'>$col</th>";
                echo "</tr>";
                foreach ($rows as $row) {
                    echo "<tr>";
                    foreach ($row as $val) echo "<td style='padding:8px;'>".htmlspecialchars($val)."</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        } catch (Exception $e) {
            echo "<p style='color:red'>Error reading table: " . $e->getMessage() . "</p>";
        }
        echo "<hr>";
    }

    showTable($db, 'contracts');
    showTable($db, 'jobs');
    showTable($db, 'proposals');
    showTable($db, 'users');

    echo "<h3>Current Session Info:</h3>";
    session_start();
    echo "<pre>";
    print_r($_SESSION);
    echo "</pre>";

    echo "</body>";
} catch (Exception $e) {
    echo "Global Error: " . $e->getMessage();
}
?>
