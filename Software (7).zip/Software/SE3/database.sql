-- إنشاء جدول الأدوار
CREATE TABLE IF NOT EXISTS roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إدراج الأدوار
INSERT INTO roles (role_name) VALUES ('Client'), ('Freelancer'), ('Admin');

-- إنشاء جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL DEFAULT 1,
    account_status ENUM('active', 'limited_access', 'banned') DEFAULT 'active',
    penalty_type ENUM('none', 'warning', 'limited_access', 'permanent_ban') DEFAULT 'none',
    penalty_reason VARCHAR(255),
    penalty_applied_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE SET DEFAULT
);

-- إنشاء index للـ email لتسريع البحث
CREATE INDEX idx_email ON users(email);

-- جدول النزاعات (Disputes)
CREATE TABLE IF NOT EXISTS disputes (
    dispute_id INT PRIMARY KEY AUTO_INCREMENT,
    contract_id VARCHAR(50),
    client_id INT NOT NULL,
    freelancer_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    status ENUM('open', 'resolved', 'closed') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (client_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول القنوات المقيدة (Restricted Channels)
CREATE TABLE IF NOT EXISTS restricted_channels (
    channel_id INT PRIMARY KEY AUTO_INCREMENT,
    dispute_id INT NOT NULL,
    channel_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dispute_id) REFERENCES disputes(dispute_id) ON DELETE CASCADE
);

-- جدول أعضاء القناة (Channel Members)
CREATE TABLE IF NOT EXISTS channel_members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    channel_id INT NOT NULL,
    user_id INT NOT NULL,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_channel_user (channel_id, user_id),
    FOREIGN KEY (channel_id) REFERENCES restricted_channels(channel_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول رسائل القناة (Channel Messages)
CREATE TABLE IF NOT EXISTS channel_messages (
    message_id INT PRIMARY KEY AUTO_INCREMENT,
    channel_id INT NOT NULL,
    user_id INT NOT NULL,
    message_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (channel_id) REFERENCES restricted_channels(channel_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول الغرامات (Penalties)
CREATE TABLE IF NOT EXISTS penalties (
    penalty_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    dispute_id INT NOT NULL,
    penalty_type ENUM('warning', 'limited_access', 'permanent_ban') NOT NULL,
    reason VARCHAR(500) NOT NULL,
    applied_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (dispute_id) REFERENCES disputes(dispute_id) ON DELETE CASCADE,
    FOREIGN KEY (applied_by) REFERENCES users(user_id) ON DELETE SET NULL
);

-- جدول الإشعارات (Notifications)
CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    type ENUM('dispute_opened', 'penalty_warning', 'penalty_limited', 'penalty_banned', 'message', 'admin_message') NOT NULL,
    message TEXT NOT NULL,
    related_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- إنشاء index للأداء
CREATE INDEX idx_dispute_status ON disputes(status);
CREATE INDEX idx_channel_active ON restricted_channels(is_active);
CREATE INDEX idx_notification_user ON notifications(user_id);

-- جدول الوظائف (Jobs)
CREATE TABLE IF NOT EXISTS jobs (
    job_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    budget DECIMAL(10, 2) NOT NULL,
    status ENUM('open', 'in_progress', 'completed', 'cancelled') DEFAULT 'open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول العروض (Proposals)
CREATE TABLE IF NOT EXISTS proposals (
    proposal_id INT PRIMARY KEY AUTO_INCREMENT,
    job_id INT NOT NULL,
    freelancer_id INT NOT NULL,
    bid_amount DECIMAL(10, 2) NOT NULL,
    delivery_time INT NOT NULL, -- بالأيام
    cover_letter TEXT NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول العقود (Contracts)
CREATE TABLE IF NOT EXISTS contracts (
    contract_id INT PRIMARY KEY AUTO_INCREMENT,
    job_id INT NOT NULL,
    client_id INT NOT NULL,
    freelancer_id INT NOT NULL,
    proposal_id INT NOT NULL,
    bid_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('active', 'completed', 'disputed', 'terminated') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(job_id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (freelancer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (proposal_id) REFERENCES proposals(proposal_id) ON DELETE CASCADE
);

-- جدول المراحل (Milestones)
CREATE TABLE IF NOT EXISTS milestones (
    milestone_id INT PRIMARY KEY AUTO_INCREMENT,
    contract_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'funded', 'submitted', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (contract_id) REFERENCES contracts(contract_id) ON DELETE CASCADE
);
