/**
 * FreeLynk — Facebook-Style Chat Sidebar
 * Include once per page, after main.js
 */
(function () {
  'use strict';

  /* ─── contacts ─── */
  const CONTACTS = [
    { id:1, name:'Ali Morsy',       initials:'AM', grad:'135deg,#22c55e,#00e5c0', online:true,  unread:3, preview:'Phase 2 files are uploaded…', time:'2m'  },
    { id:2, name:'Sara Hassan',     initials:'SH', grad:'135deg,#f59e0b,#ef4444', online:false, unread:2, preview:'Can you send the revised wireframes?', time:'1h' },
    { id:3, name:'Karim Omar',      initials:'KO', grad:'135deg,#6c63ff,#00e5c0', online:true,  unread:0, preview:'Sounds good, I can start Monday',   time:'Yesterday' },
    { id:4, name:'Nour Nabil',      initials:'NN', grad:'135deg,#00e5c0,#6c63ff', online:false, unread:0, preview:'Thank you for the opportunity!',    time:'2d' },
    { id:5, name:'Admin ⚖ Dispute', initials:'⚖', grad:'135deg,#ef4444,#f59e0b', online:true,  unread:1, preview:'[Restricted] Upload your evidence',  time:'3h' },
  ];

  /* ─── starter history per contact ─── */
  const HISTORY = {
    1:[
      {dir:'in',  txt:'Hi! Phase 2 files are uploaded — please review.',       time:'10:00'},
      {dir:'out', txt:'Got it! I\'ll review today and give feedback.',          time:'10:05'},
      {dir:'in',  txt:'Let me know if you need anything else 😊',              time:'10:07'},
    ],
    2:[
      {dir:'in',  txt:'Hey! Wireframes for the homepage are ready.',           time:'Yesterday 2:30 PM'},
      {dir:'out', txt:'Great! Include mobile responsive versions too please.',  time:'Yesterday 3:05 PM'},
      {dir:'in',  txt:'Can you send the revised wireframes?',                  time:'2h ago'},
    ],
    3:[{dir:'in',txt:'Sounds good, I can start Monday.',time:'Yesterday'}],
    4:[{dir:'in',txt:'Thank you for the opportunity!',  time:'2 days ago'}],
    5:[{dir:'in',txt:'[Restricted] Please upload your evidence by Apr 25.', time:'3h ago'}],
  };

  const openWindows = {}; // id → DOM el

  /* ════════════════════════════════════
     BUILD SIDEBAR
  ════════════════════════════════════ */
  function buildSidebar() {
    if (document.getElementById('fbChatSidebar')) return;

    const totalUnread = CONTACTS.reduce((s,c) => s + c.unread, 0);

    /* Sidebar */
    const sidebar = el('div', {id:'fbChatSidebar'});
    sidebar.innerHTML = `
      <div class="fbs-header">
        <h6><i class="fa-solid fa-comments"></i>&nbsp; Messages</h6>
        <button class="fbs-close" id="fbsCLoseBtn" title="Close"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="fbs-search">
        <input type="text" id="fbsSearch" placeholder="Search contacts…">
      </div>
      <div class="fbs-list" id="fbsList"></div>
    `;
    document.body.appendChild(sidebar);

    /* Toggle button */
    const btn = el('button', {id:'fbChatToggle', title:'Messages'});
    btn.innerHTML = `<i class="fa-solid fa-comments"></i>
      ${totalUnread > 0 ? `<span class="fbc-badge">${totalUnread}</span>` : ''}`;
    document.body.appendChild(btn);

    /* Windows container */
    const wins = el('div', {id:'fbChatWindows'});
    document.body.appendChild(wins);

    renderList(CONTACTS);

    btn.addEventListener('click', toggleSidebar);
    document.getElementById('fbsCLoseBtn').addEventListener('click', closeSidebar);
    document.getElementById('fbsSearch').addEventListener('input', e => {
      const q = e.target.value.toLowerCase();
      renderList(CONTACTS.filter(c => c.name.toLowerCase().includes(q)));
    });
  }

  /* ════════════════════════════════════
     RENDER CONTACT LIST
  ════════════════════════════════════ */
  function renderList(contacts) {
    const list = document.getElementById('fbsList');
    list.innerHTML = '';
    if (!contacts.length) {
      list.innerHTML = '<p style="text-align:center;color:var(--muted);font-size:.78rem;padding:1rem;">No contacts found</p>';
      return;
    }
    contacts.forEach(c => {
      const item = el('div', {class:'fbs-item', 'data-fbs-id': c.id});
      item.innerHTML = `
        <div class="fbs-av" style="background:linear-gradient(${c.grad});">
          ${c.initials}
          ${c.online ? '<span class="fbs-online"></span>' : ''}
        </div>
        <div class="fbs-info">
          <div class="fbs-name">${c.name}</div>
          <div class="fbs-preview">${c.preview}</div>
        </div>
        <div class="fbs-meta">
          <span class="fbs-time">${c.time}</span>
          ${c.unread > 0 ? `<span class="fbs-unread">${c.unread}</span>` : ''}
        </div>
      `;
      item.addEventListener('click', () => openChatWindow(c));
      list.appendChild(item);
    });
  }

  /* ════════════════════════════════════
     SIDEBAR OPEN / CLOSE
  ════════════════════════════════════ */
  function toggleSidebar() {
    document.getElementById('fbChatSidebar').classList.toggle('open');
  }
  function closeSidebar() {
    document.getElementById('fbChatSidebar').classList.remove('open');
  }

  /* ════════════════════════════════════
     OPEN FLOATING CHAT WINDOW
  ════════════════════════════════════ */
  function openChatWindow(contact) {
    /* Already open → un-collapse & focus */
    if (openWindows[contact.id]) {
      openWindows[contact.id].classList.remove('collapsed');
      openWindows[contact.id].querySelector('.fw-footer input').focus();
      return;
    }

    const history = HISTORY[contact.id] || [];
    const win = el('div', {class:'fb-win', 'data-fw-id': contact.id});
    const emojiList = ['😊','👍','🎉','💡','🚀','❤️','🙏','😂','🔥','👏','✅','🤝'];

    win.innerHTML = `
      <div class="fw-header">
        <div class="fw-av" style="background:linear-gradient(${contact.grad});">${contact.initials}</div>
        <span class="fw-title">${contact.name}</span>
        <div class="fw-actions">
          <button class="fw-min" title="Minimize"><i class="fa-solid fa-minus"></i></button>
          <button class="fw-cls" title="Close"><i class="fa-solid fa-xmark"></i></button>
        </div>
      </div>
      <div class="fw-body" id="fwBody-${contact.id}">
        ${history.map(m => bubble(m.txt, m.dir, m.time)).join('')}
        <div class="fw-typing" id="fwTyping-${contact.id}">
          <span class="dot"></span><span class="dot"></span><span class="dot"></span>
        </div>
      </div>
      <div class="fw-emoji" id="fwEmoji-${contact.id}">
        ${emojiList.map(e => `<span onclick="window._fbWinEmoji(${contact.id},'${e}')">${e}</span>`).join('')}
      </div>
      <div class="fw-footer">
        <button class="fw-emoji-btn" onclick="window._fbWinToggleEmoji(${contact.id})" title="Emoji">
          <i class="fa-regular fa-face-smile"></i>
        </button>
        <input type="text" id="fwInput-${contact.id}" placeholder="Aa"
          onkeydown="window._fbWinKey(event,${contact.id})"
        >
        <button class="fw-send-btn" onclick="window._fbWinSend(${contact.id})" title="Send">
          <i class="fa-solid fa-paper-plane"></i>
        </button>
      </div>
    `;

    document.getElementById('fbChatWindows').appendChild(win);
    openWindows[contact.id] = win;

    /* Remove unread badge in sidebar */
    const sideItem = document.querySelector(`.fbs-item[data-fbs-id="${contact.id}"] .fbs-unread`);
    if (sideItem) sideItem.remove();
    const c = CONTACTS.find(x => x.id === contact.id);
    if (c) c.unread = 0;

    /* Header click = minimize */
    win.querySelector('.fw-header').addEventListener('click', e => {
      if (e.target.closest('.fw-actions')) return;
      win.classList.toggle('collapsed');
    });
    win.querySelector('.fw-min').addEventListener('click', e => {
      e.stopPropagation();
      win.classList.toggle('collapsed');
    });
    win.querySelector('.fw-cls').addEventListener('click', e => {
      e.stopPropagation();
      win.remove();
      delete openWindows[contact.id];
    });

    scrollBody(contact.id);
    win.querySelector('.fw-footer input').focus();
  }

  /* ════════════════════════════════════
     GLOBAL HELPERS (inline handlers)
  ════════════════════════════════════ */
  window._fbWinSend = function (id) {
    const inp = document.getElementById(`fwInput-${id}`);
    const txt = inp.value.trim();
    if (!txt) return;
    const body = document.getElementById(`fwBody-${id}`);
    const typing = document.getElementById(`fwTyping-${id}`);
    const now = nowStr();
    const b = document.createElement('div');
    b.className = 'fw-bubble out';
    b.innerHTML = `${esc(txt)}<span class="fw-time">${now}</span>`;
    body.insertBefore(b, typing);
    inp.value = '';
    scrollBody(id);
    simulateReply(id);
  };

  window._fbWinKey = function (e, id) {
    if (e.key === 'Enter') { e.preventDefault(); window._fbWinSend(id); }
  };

  window._fbWinToggleEmoji = function (id) {
    document.getElementById(`fwEmoji-${id}`).classList.toggle('show');
  };

  window._fbWinEmoji = function (id, emoji) {
    const inp = document.getElementById(`fwInput-${id}`);
    inp.value += emoji;
    inp.focus();
    document.getElementById(`fwEmoji-${id}`).classList.remove('show');
  };

  /* ════════════════════════════════════
     SIMULATE REPLY
  ════════════════════════════════════ */
  function simulateReply(id) {
    const typing = document.getElementById(`fwTyping-${id}`);
    if (!typing) return;
    typing.style.display = 'flex';
    scrollBody(id);
    const replies = [
      'Got it, thanks!',
      'I\'ll look into that right away.',
      'Sure, will update you shortly.',
      'Thanks for the feedback — working on it!',
      'Sounds good 👍',
    ];
    setTimeout(() => {
      typing.style.display = 'none';
      const body = document.getElementById(`fwBody-${id}`);
      if (!body) return;
      const b = document.createElement('div');
      b.className = 'fw-bubble in';
      b.innerHTML = `${esc(replies[Math.floor(Math.random() * replies.length)])}<span class="fw-time">${nowStr()}</span>`;
      body.insertBefore(b, typing);
      scrollBody(id);
    }, 1600 + Math.random() * 800);
  }

  /* ════════════════════════════════════
     UTILITIES
  ════════════════════════════════════ */
  function bubble(txt, dir, time) {
    return `<div class="fw-bubble ${dir}">${esc(txt)}<span class="fw-time">${time}</span></div>`;
  }

  function scrollBody(id) {
    const b = document.getElementById(`fwBody-${id}`);
    if (b) b.scrollTop = b.scrollHeight;
  }

  function nowStr() {
    return new Date().toLocaleTimeString('en', {hour:'2-digit', minute:'2-digit'});
  }

  function esc(str) {
    return str
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function el(tag, attrs = {}) {
    const e = document.createElement(tag);
    Object.entries(attrs).forEach(([k,v]) => e.setAttribute(k, v));
    return e;
  }

  /* ════════════════════════════════════
     INIT
  ════════════════════════════════════ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildSidebar);
  } else {
    buildSidebar();
  }

})();
