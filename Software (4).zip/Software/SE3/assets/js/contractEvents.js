/**
 * FreeLynk — contractEvents.js
 * =====================================================
 * Cross-page event bus via localStorage + StorageEvent.
 * يربط الـ Fund (client) → Submit Work (freelancer) → Release Payment (client) → Notify (freelancer)
 *
 * Usage: include in BOTH client_dashboard.php AND freelancer_dashboard.php
 * BEFORE the inline <script> block in each page.
 *
 * Events stored in localStorage:
 *   freelynk_event  →  { type, contractId, milestoneId, amount, ts }
 *
 * Types:
 *   'funded'    — client funded a milestone   → freelancer يشوف Submit Work مفعّل
 *   'submitted' — freelancer submitted work    → client يشوف Release Payment
 *   'released'  — client released payment      → freelancer يشوف إشعار
 */

(function () {
  'use strict';

  /* ─── key used in localStorage ─── */
  const LS_KEY = 'freelynk_event';

  /* ─── detect which page we're on ─── */
  const IS_CLIENT     = document.title.includes('Client');
  const IS_FREELANCER = document.title.includes('Freelancer');

  /* ════════════════════════════════════════════
     PUBLIC API — used by inline scripts
  ════════════════════════════════════════════ */

  /**
   * Broadcast an event to the other tab/page.
   * @param {'funded'|'submitted'|'released'} type
   * @param {number} contractId
   * @param {number} milestoneId
   * @param {number} amount
   * @param {string} [extra]  optional label
   */
  window.CE_emit = function (type, contractId, milestoneId, amount, extra) {
    const payload = {
      type, contractId, milestoneId, amount,
      extra: extra || '',
      ts: Date.now(),
      from: IS_CLIENT ? 'client' : 'freelancer',
    };
    localStorage.setItem(LS_KEY, JSON.stringify(payload));
    /* same-tab: trigger handlers immediately */
    _dispatch(payload);
  };

  /**
   * Read the latest stored event (for on-load sync).
   */
  window.CE_latest = function () {
    try { return JSON.parse(localStorage.getItem(LS_KEY)); } catch { return null; }
  };

  /**
   * Clear stored event.
   */
  window.CE_clear = function () {
    localStorage.removeItem(LS_KEY);
  };

  /* ════════════════════════════════════════════
     CROSS-TAB LISTENER
  ════════════════════════════════════════════ */
  window.addEventListener('storage', function (e) {
    if (e.key !== LS_KEY || !e.newValue) return;
    try {
      const payload = JSON.parse(e.newValue);
      _dispatch(payload);
    } catch (_) {}
  });

  /* ════════════════════════════════════════════
     DISPATCH — route event to correct handler
  ════════════════════════════════════════════ */
  function _dispatch(payload) {
    if (!payload) return;

    /* ── CLIENT PAGE receives: submitted, released ── */
    if (IS_CLIENT) {
      if (payload.type === 'submitted' && payload.from === 'freelancer') {
        _clientOnSubmitted(payload);
      }
    }

    /* ── FREELANCER PAGE receives: funded, released ── */
    if (IS_FREELANCER) {
      if (payload.type === 'funded' && payload.from === 'client') {
        _freelancerOnFunded(payload);
      }
      if (payload.type === 'released' && payload.from === 'client') {
        _freelancerOnReleased(payload);
      }
    }
  }

  /* ════════════════════════════════════════════
     HANDLERS — CLIENT SIDE
  ════════════════════════════════════════════ */

  /**
   * Freelancer submitted work → notify client, unlock "Release Payment"
   */
  function _clientOnSubmitted(p) {
    const { contractId, milestoneId, amount, extra } = p;

    /* 1. update in-memory contractsData if available */
    if (window.contractsData && window.contractsData[contractId]) {
      const c = window.contractsData[contractId];
      const m = c.milestones.find(ms => ms.id === milestoneId);
      if (m && m.status === 'active') {
        m.submitted    = true;
        m.progress     = 100;
        m.submittedDate = 'Just now';
      }
    }

    /* 2. re-render panels */
    if (typeof window.renderMilestones === 'function') window.renderMilestones(contractId);
    if (typeof window.renderEscrow     === 'function') window.renderEscrow(contractId);

    /* 3. notification banner */
    _showNotifBanner(
      'submitted',
      `🚀 <strong>${extra || 'Freelancer'}</strong> submitted work on ` +
      `<strong>Contract #${contractId}</strong> — ` +
      `$${Number(amount).toLocaleString()} ready for your review!`,
      contractId,
      milestoneId,
      amount
    );

    /* 4. toast */
    if (typeof window.showToast === 'function') {
      window.showToast(
        `Freelancer submitted work! Review & release $${Number(amount).toLocaleString()}.`,
        'success'
      );
    }

    /* 5. pulse the bell */
    _pulseBell();
  }

  /* ════════════════════════════════════════════
     HANDLERS — FREELANCER SIDE
  ════════════════════════════════════════════ */

  /**
   * Client funded milestone → unlock Submit Work button
   */
  function _freelancerOnFunded(p) {
    const { contractId, milestoneId, amount } = p;

    if (window.contractsData && window.contractsData[contractId]) {
      const c = window.contractsData[contractId];
      c.escrowLocked = (c.escrowLocked || 0) + Number(amount);

      /* mark the matching milestone */
      const m = c.milestones.find(ms => ms.id === milestoneId);
      if (m) { m.funded = true; }
    }

    if (typeof window.renderMilestones === 'function') window.renderMilestones(contractId);
    if (typeof window.renderPayout     === 'function') window.renderPayout(contractId);
    if (typeof window.updateStats      === 'function') window.updateStats();

    _showNotifBanner(
      'funded',
      `💰 Client funded <strong>$${Number(amount).toLocaleString()}</strong> into escrow ` +
      `for <strong>Contract #${contractId}</strong> — you can now submit your work!`,
      contractId, milestoneId, amount
    );

    if (typeof window.showToast === 'function') {
      window.showToast(
        `$${Number(amount).toLocaleString()} funded into escrow! Submit your work now.`,
        'success'
      );
    }
    _pulseBell();
  }

  /**
   * Client released payment → freelancer sees earnings updated
   */
  function _freelancerOnReleased(p) {
    const { contractId, milestoneId, amount } = p;

    if (window.contractsData && window.contractsData[contractId]) {
      const c   = window.contractsData[contractId];
      const idx = c.milestones.findIndex(ms => ms.id === milestoneId);
      if (idx !== -1) {
        const m = c.milestones[idx];
        c.releasedTotal  = (c.releasedTotal  || 0) + Number(amount);
        c.escrowLocked   = Math.max(0, (c.escrowLocked || 0) - Number(amount));
        m.status         = 'done';
        m.submittedDate  = m.submittedDate || 'Just now';

        /* unlock next milestone */
        const next = c.milestones[idx + 1];
        if (next && next.status === 'locked') {
          next.status = 'active';
          next.progress = 0;
          next.funded   = false;
        }
      }
    }

    if (typeof window.renderMilestones === 'function') window.renderMilestones(contractId);
    if (typeof window.renderPayout     === 'function') window.renderPayout(contractId);
    if (typeof window.updateStats      === 'function') window.updateStats();

    _showNotifBanner(
      'released',
      `🎉 <strong>$${Number(amount).toLocaleString()}</strong> released to your account ` +
      `for <strong>Contract #${contractId}</strong>! ` +
      `(${Math.round(
        (window.contractsData?.[contractId]?.platformFee || 0.08) * 100
      )}% platform fee deducted)`,
      contractId, milestoneId, amount
    );

    if (typeof window.showToast === 'function') {
      window.showToast(
        `🎉 Payment of $${Number(amount).toLocaleString()} released! Check your earnings.`,
        'success'
      );
    }
    _pulseBell();
  }

  /* ════════════════════════════════════════════
     NOTIFICATION BANNER
  ════════════════════════════════════════════ */

  /**
   * Renders a top-of-page notification banner with an action button.
   * Auto-dismisses after 12s.
   */
  function _showNotifBanner(type, html, contractId, milestoneId, amount) {
    /* remove any existing banner */
    const existing = document.getElementById('ce-notif-banner');
    if (existing) existing.remove();

    /* colour per event type */
    const cfg = {
      funded:    { bg: 'rgba(0,229,192,.12)',  border: 'rgba(0,229,192,.35)',  icon: 'fa-vault',           btnLabel: 'Submit Work',       btnClass: 'btn-primary'  },
      submitted: { bg: 'rgba(108,99,255,.12)', border: 'rgba(108,99,255,.35)', icon: 'fa-upload',          btnLabel: 'Release Payment',   btnClass: 'btn-primary'  },
      released:  { bg: 'rgba(34,197,94,.12)',  border: 'rgba(34,197,94,.35)',  icon: 'fa-money-bill-wave', btnLabel: 'View Earnings',     btnClass: 'btn-secondary' },
    }[type] || {};

    /* action handler */
    let actionFn = '';
    if (type === 'submitted' && IS_CLIENT) {
      actionFn = `window.CE_releaseFromBanner(${contractId},${milestoneId},${amount})`;
    } else if (type === 'funded' && IS_FREELANCER) {
      actionFn = `window.openSubmitWork(${contractId},${milestoneId})`;
    } else if (type === 'released' && IS_FREELANCER) {
      actionFn = `window.selectContract(${contractId}); document.getElementById('payoutBody')?.scrollIntoView({behavior:'smooth'})`;
    }

    const banner = document.createElement('div');
    banner.id    = 'ce-notif-banner';
    banner.style.cssText = `
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 9999;
      background: ${cfg.bg};
      border-bottom: 2px solid ${cfg.border};
      padding: 14px 20px;
      display: flex;
      align-items: center;
      gap: 14px;
      font-family: 'DM Sans', sans-serif;
      font-size: 13px;
      color: var(--text, #e8eaf0);
      animation: ceBannerIn .35s cubic-bezier(.4,0,.2,1);
      backdrop-filter: blur(8px);
    `;

    banner.innerHTML = `
      <i class="fa-solid ${cfg.icon}" style="font-size:18px;color:var(--accent,#00e5c0);flex-shrink:0;"></i>
      <span style="flex:1;">${html}</span>
      ${actionFn ? `
        <button class="btn btn-sm ${cfg.btnClass}" onclick="${actionFn};document.getElementById('ce-notif-banner').remove()">
          <i class="fa-solid ${cfg.icon}"></i> ${cfg.btnLabel}
        </button>` : ''}
      <button onclick="this.closest('#ce-notif-banner').remove()"
              style="background:none;border:none;cursor:pointer;color:var(--muted,#6b7280);font-size:16px;padding:0 4px;flex-shrink:0;"
              title="Dismiss">
        <i class="fa-solid fa-xmark"></i>
      </button>
    `;

    /* inject keyframes once */
    if (!document.getElementById('ce-keyframes')) {
      const style = document.createElement('style');
      style.id = 'ce-keyframes';
      style.textContent = `
        @keyframes ceBannerIn {
          from { transform: translateY(-100%); opacity: 0; }
          to   { transform: translateY(0);     opacity: 1; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.prepend(banner);

    /* auto-dismiss */
    setTimeout(() => {
      if (banner.parentNode) {
        banner.style.transition = 'transform .3s, opacity .3s';
        banner.style.transform  = 'translateY(-100%)';
        banner.style.opacity    = '0';
        setTimeout(() => banner.remove(), 300);
      }
    }, 12000);
  }

  /* ════════════════════════════════════════════
     CLIENT — Release directly from banner
  ════════════════════════════════════════════ */
  window.CE_releaseFromBanner = function (contractId, milestoneId, amount) {
    /* confirm then call existing approveMilestone */
    const confirmed = confirm(
      `Release $${Number(amount).toLocaleString()} to the freelancer for Contract #${contractId}?\n\nFunds will be released from escrow.`
    );
    if (!confirmed) return;

    /* update data */
    if (window.contractsData && window.contractsData[contractId]) {
      const c   = window.contractsData[contractId];
      const idx = c.milestones.findIndex(ms => ms.id === milestoneId);
      if (idx !== -1) {
        const m      = c.milestones[idx];
        c.releasedTotal += Number(amount);
        c.escrowLocked   = Math.max(0, c.escrowLocked - Number(amount));
        m.status         = 'done';

        const next = c.milestones[idx + 1];
        if (next && next.status === 'locked') {
          next.status   = 'active';
          next.progress = 0;
          next.funded   = false;
        }
      }
    }

    /* emit released event → freelancer will see it */
    window.CE_emit('released', contractId, milestoneId, amount, 'Client');

    /* re-render */
    if (typeof window.renderMilestones === 'function') window.renderMilestones(contractId);
    if (typeof window.renderEscrow     === 'function') window.renderEscrow(contractId);
    if (typeof window.updateStatCards  === 'function') window.updateStatCards();

    if (typeof window.showToast === 'function') {
      window.showToast(
        `$${Number(amount).toLocaleString()} released to freelancer! (FR24)`,
        'success'
      );
    }
  };

  /* ════════════════════════════════════════════
     PULSE BELL
  ════════════════════════════════════════════ */
  function _pulseBell() {
    const bell = document.querySelector('.topbar-actions .icon-btn');
    if (!bell) return;
    bell.style.transition = 'transform .15s, color .15s';
    bell.style.transform  = 'scale(1.4)';
    bell.style.color      = 'var(--accent, #00e5c0)';
    setTimeout(() => {
      bell.style.transform = '';
      bell.style.color     = '';
    }, 400);

    /* add red dot */
    let dot = bell.querySelector('.notif-dot');
    if (!dot) { dot = document.createElement('span'); dot.className = 'notif-dot'; bell.appendChild(dot); }
  }

  /* ════════════════════════════════════════════
     ON-LOAD SYNC
     If a tab was closed and reopened, replay last event.
  ════════════════════════════════════════════ */
  document.addEventListener('DOMContentLoaded', function () {
    const saved = window.CE_latest();
    if (!saved) return;

    /* Only replay events from the last 10 minutes */
    if (Date.now() - saved.ts > 10 * 60 * 1000) return;

    /* Don't replay events sent by this same page's role */
    if (IS_CLIENT     && saved.from === 'client')     return;
    if (IS_FREELANCER && saved.from === 'freelancer')  return;

    /* short delay so page scripts finish init */
    setTimeout(() => _dispatch(saved), 800);
  });

})();
