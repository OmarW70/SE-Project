/* ============================================================
   FREELANCE PLATFORM - main.js
   ============================================================ */

/* ── Toast ─────────────────────────────────────────────────── */
function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✓', error: '✕', warn: '⚠' };
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'error' : type === 'warn' ? 'warn' : ''}`;
  toast.innerHTML = `<span style="font-size:16px;color:var(--accent)">${icons[type] || icons.success}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(20px)'; toast.style.transition = '.3s'; setTimeout(() => toast.remove(), 300); }, 3500);
}

/* ── Modal ─────────────────────────────────────────────────── */
function openModal(id)  { document.getElementById(id)?.classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id)?.classList.add('hidden'); }

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-backdrop')) {
    e.target.classList.add('hidden');
  }
});

/* ── Sidebar Toggle ─────────────────────────────────────────── */
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
}

/* ── Active Nav ─────────────────────────────────────────────── */
(function setActiveNav() {
  const path = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-item[data-page]').forEach(item => {
    if (item.dataset.page === path) item.classList.add('active');
    else item.classList.remove('active');
  });
})();

/* ── Progress Bars Animate ──────────────────────────────────── */
function animateProgress() {
  document.querySelectorAll('.progress-fill').forEach(bar => {
    const target = bar.dataset.width || bar.style.width;
    bar.style.width = '0%';
    setTimeout(() => { bar.style.width = target; }, 200);
  });
}

/* ── Tab Switcher ────────────────────────────────────────────── */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.tabs-wrap');
      group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const target = btn.dataset.tab;
      group.querySelectorAll('.tab-pane').forEach(pane => {
        pane.style.display = pane.id === target ? 'block' : 'none';
      });
    });
  });
}

/* ── Login Role Selector ──────────────────────────────────────── */
function initRoleSelector() {
  document.querySelectorAll('.role-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.role-option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      const role = opt.dataset.role;
      const input = document.getElementById('roleInput');
      if (input) input.value = role;
    });
  });
}

/* ── Login Form ───────────────────────────────────────────────── */
function initLoginForm() {
  // const form = document.getElementById('loginForm');
  // if (!form) return;
  // form.addEventListener('submit', e => {
  //   e.preventDefault();
  //   const role = document.getElementById('roleInput')?.value || 'client';
  //   const email = form.querySelector('[name="email"]')?.value;
  //   const pass  = form.querySelector('[name="password"]')?.value;

  //   if (!email || !pass) { showToast('Please fill in all fields.', 'error'); return; }

  //   const btn = form.querySelector('.btn-primary');
  //   btn.disabled = true;

  //   setTimeout(() => {
  //     if (role === 'freelancer') window.location.href = 'freelancer_dashboard.php';
  //     else if (role === 'admin') { showToast('Admin panel coming soon.', 'warn'); btn.textContent = '...'; btn.disabled = false; }
  //     else window.location.href = 'client_dashboard.php';
  //   }, 1200);
  // });
}

/* ── Signup Form ──────────────────────────────────────────────── */
function initSignupForm() {
  // const form = document.getElementById('signupForm');
  // if (!form) return;
  // form.addEventListener('submit', e => {
  //   e.preventDefault();
  //   const btn = form.querySelector('.btn-primary');
  //   btn.disabled = true;
  //   setTimeout(() => {
  //     showToast('Account created! Please verify your identity.');
  //     openModal('verifyModal');
  //     btn.textContent = 'Create Account';
  //     btn.disabled = false;
  //   }, 1000);
  // });
}

/* ── Fund Milestone ────────────────────────────────────────────── */
function fundMilestone(id, amount) {
  showToast(`Milestone #${id} funded — $${amount} in escrow.`);
}

/* ── Release Payment ───────────────────────────────────────────── */
function releasePayment(id) {
  const confirmed = confirm(`Release payment for Milestone #${id}?`);
  if (confirmed) showToast('Payment released! Fees & VAT calculated.');
}

/* ── Open Dispute ───────────────────────────────────────────────── */
function openDisputeFlow() {
  openModal('disputeModal');
}

/* ── Submit Work ─────────────────────────────────────────────────── */
function submitWork(milestoneId) {
  openModal('submitWorkModal');
  const titleEl = document.getElementById('submitWorkTitle');
  if (titleEl) titleEl.textContent = `Submit Work — Milestone #${milestoneId}`;
}

/* ── Schedule Interview ──────────────────────────────────────────── */
function scheduleInterview() {
  openModal('interviewModal');
}

/* ── Generic confirm action ────────────────────────────────────────── */
function confirmAction(message, onConfirm) {
  if (confirm(message)) onConfirm();
}

/* ── Copy to clipboard ─────────────────────────────────────────────── */
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => showToast('Copied to clipboard.'));
}

/* ── Sidebar burger for mobile ──────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  animateProgress();
  initTabs();
  initRoleSelector();
  initLoginForm();
  initSignupForm();

  // Burger
  const burger = document.getElementById('burgerBtn');
  if (burger) burger.addEventListener('click', toggleSidebar);

  // Close sidebar on nav click (mobile)
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      if (window.innerWidth < 1024) document.querySelector('.sidebar')?.classList.remove('open');
    });
  });
});