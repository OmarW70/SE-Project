<?php
// index.php — Login / Sign Up page
$page = isset($_GET['mode']) ? $_GET['mode'] : 'login';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Sign In</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="login-page">



  <!-- ── Right Panel ── -->
  <div class="login-right">
    <div class="login-form-wrap">

      <?php if($page === 'login'): ?>
      <!-- ── LOGIN ── -->
      <h2>Welcome back</h2>
      <p class="subtitle">Log in to your FreeLynk account</p>

      <input type="hidden" id="roleInput" value="client">

      <form id="loginForm" method="POST" action="../controllers/AuthController.php?action=login">
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" placeholder="you@example.com">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="••••••••">
        </div>
        <button type="submit" class="btn btn-primary w-full" style="justify-content:center;padding:12px;">
          <i class="fa-solid fa-right-to-bracket"></i> Log In
        </button>
      </form>

      <div class="divider">or</div>
      <p class="text-sm" style="text-align:center;color:var(--muted);">
        Don't have an account?
        <a href="?mode=signup">Create one</a>
      </p>

      <?php else: ?>
      <!-- ── SIGNUP ── -->
      <h2>Join FreeLynk</h2>
      <p class="subtitle">Create your account in seconds</p>

      <div class="role-selector">
        <div class="role-option active" data-role="client">
          <i class="fa-solid fa-briefcase"></i>
          <span>Client</span>
        </div>
        <div class="role-option" data-role="freelancer">
          <i class="fa-solid fa-laptop-code"></i>
          <span>Freelancer</span>
        </div>
        <div class="role-option" data-role="admin">
          <i class="fa-solid fa-user-shield"></i>
          <span>Admin</span>
        </div>
      </div>

      <form id="signupForm" method="POST" action="../controllers/AuthController.php?action=register">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">First Name</label>
            <input type="text" name="first_name" class="form-control" placeholder="FirstName" required>
          </div>
          <div class="form-group">
            <label class="form-label">Last Name</label>
            <input type="text" name="last_name" class="form-control" placeholder="LastName" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" placeholder="you@example.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Min. 8 characters" required>
        </div>
        <input type="hidden" name="role_id" id="roleIdInput" value="1">
        <button type="submit" class="btn btn-primary w-full" style="justify-content:center;padding:12px;">
          <i class="fa-solid fa-user-plus"></i> Create Account
        </button>
      </form>

      <p class="text-sm mt-3" style="text-align:center;color:var(--muted);">
        Already have an account? <a href="?mode=login">Log In</a>
      </p>
      <?php endif; ?>

    </div>
  </div>
</div>

<!-- Verify Identity Modal -->
<div class="modal-backdrop hidden" id="verifyModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-id-card text-accent"></i> &nbsp;Verify Your Identity</span>
      <button class="icon-btn" onclick="closeModal('verifyModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <p class="text-muted text-sm mb-4">Upload a valid government-issued ID or passport to activate your account (FR5).</p>
      <div class="form-group">
        <label class="form-label">Document Type</label>
        <select class="form-control">
          <option>National ID</option>
          <option>Passport</option>
          <option>Driver's License</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Upload Document</label>
        <input type="file" class="form-control" accept="image/*,.pdf">
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('verifyModal')">Skip for now</button>
      <button class="btn btn-primary btn-sm" onclick="closeModal('verifyModal');showToast('Document submitted for verification!')">
        <i class="fa-solid fa-upload"></i> Submit
      </button>
    </div>
  </div>
</div>

<div id="toast-container"></div>
<script>
  // تحديث الـ role_id عندما يختار المستخدم دوره
  document.querySelectorAll('.role-option').forEach(option => {
    option.addEventListener('click', function() {
      // إزالة الـ active من جميع العناصر
      document.querySelectorAll('.role-option').forEach(el => el.classList.remove('active'));
      
      // إضافة الـ active للعنصر المختار
      this.classList.add('active');
      
      // تحديث الـ role_id بناءً على الاختيار
      const role = this.dataset.role;
      const roleIdMap = {
        'client': 1,
        'freelancer': 2,
        'admin': 3
      };
      
      document.getElementById('roleIdInput').value = roleIdMap[role] || 1;
    });
  });
</script>
<script src="../assets/js/main.js"></script>
</body>
</html>