<?php
// client_dashboard.php — Client Dashboard
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';
require_once '../models/ProposalModel.php';
require_once '../models/ContractModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?mode=login");
    exit();
}

$userModel = new UserModel();
$user      = $userModel->getUserById($_SESSION['user_id']);

if (!$user) {
    session_destroy();
    header("Location: index.php?mode=login");
    exit();
}

$proposalModel = new ProposalModel();
$contractModel = new ContractModel();

$recentProposals = $proposalModel->getRecentProposalsByClient($_SESSION['user_id']);
$activeContracts = $contractModel->getActiveContracts($_SESSION['user_id'], 'Client');

$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name']  = $user['last_name'];
$_SESSION['email']      = $user['email'];

$firstName = htmlspecialchars($user['first_name']);
$lastName  = htmlspecialchars($user['last_name']);
$email     = htmlspecialchars($user['email']);
$fullName  = $firstName . ' ' . $lastName;
$initials  = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
$shortName = $firstName . '. ' . $lastName;
$edit_profile_success   = $_GET['edit_profile_success']   ?? '';
$edit_profile_error = $_GET['edit_profile_error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Client Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/chat-sidebar.css">
</head>
<body>
<div class="wrapper">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="brand">Free<span>Lynk</span></div>
    </div>
    <div class="sidebar-user">
      <div class="avatar"><?= $initials ?></div>
      <div class="sidebar-user-info">
        <div class="name"><?= $shortName ?></div>
        <div class="role">Client</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Overview</div>
      <div class="nav-item active" data-page="client_dashboard.php" onclick="window.location='client_dashboard.php'">
        <i class="fa-solid fa-gauge-high"></i> Dashboard
      </div>

      <div class="nav-section-label mt-3">Jobs</div>
      <div class="nav-item" onclick="openModal('postJobModal')">
        <i class="fa-solid fa-plus-circle"></i> Post a Job
      </div>
      <div class="nav-item" onclick="window.location='freelancers.php'">
        <i class="fa-solid fa-users"></i> Browse Freelancers
      </div>

      <div class="nav-section-label mt-3">Disputes</div>
      <div class="nav-item" onclick="openDisputeFlow()">
        <i class="fa-solid fa-triangle-exclamation"></i> Open Dispute
      </div>
    </nav>
    <div class="sidebar-footer">
      <div class="nav-item" onclick="window.location='index.php'">
        <i class="fa-solid fa-right-from-bracket"></i> Sign Out
      </div>
    </div>
  </aside>

  <!-- ── Main ── -->
  <div class="main">
    <div class="topbar">
      <span class="page-title">Dashboard</span>
      <div class="topbar-actions">
         <button class="btn btn-sm btn-primary" onclick="openModal('editProfileModal')">
          <i class="fa-solid fa-pen"></i> Edit Profile
        </button>
        <div class="icon-btn" onclick="showToast('No new notifications')">
          <i class="fa-solid fa-bell"></i>
          <span class="notif-dot"></span>
        </div>
        <a href="client_profile.php">
        </a>
      </div>
    </div>

    <div class="modal-backdrop hidden" id="editProfileModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">Edit Profile</span>
      <button class="icon-btn" onclick="closeModal('editProfileModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
        <?php if ($edit_profile_success === 'updated'): ?>
                <div style="background:rgba(0,229,192,.1);border:1px solid rgba(0,229,192,.3);border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13px;color:var(--success);">
                  <i class="fa-solid fa-circle-check"></i> &nbsp; Data updated successfully!
                </div>
                <?php elseif ($edit_profile_error === 'email_taken'): ?>
                <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13px;color:var(--danger);">
                  <i class="fa-solid fa-circle-xmark"></i> &nbsp; This email is already taken by another account.
                </div>
                <?php endif; ?>
    <form class="modal-body" action="../controllers/update_profile.php" method="POST">
      <div class="form-group">
        <label class="form-label">First Name</label>
        <input type="text" name="first_name" class="form-control" value="<?= $firstName ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Last Name</label>
        <input type="text" name="last_name" class="form-control" value="<?= $lastName ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= $email ?>" required>
      </div>
      <button type="submit" class="btn btn-primary">
        <i class="fa-solid fa-save"></i> Save Changes
      </button>

    </form>
  </div>
</div>

    <div class="page-content">

      
      <!-- Row 1 -->
      <div class="grid-2 mb-6">

        <!-- Active Contracts -->
        <div class="card fade-in-1">
           <div class="card-header">
            <span class="card-title">
              <i class="fa-solid fa-file-contract text-accent"></i> &nbsp;Active Contracts
            </span>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Freelancer</th>
                  <th>Project</th>
                  <th>Progress</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($activeContracts)): ?>
                <tr>
                  <td colspan="5" style="text-align:center;padding:20px;color:var(--muted);">No active contracts found.</td>
                </tr>
                <?php else: ?>
                  <?php foreach ($activeContracts as $contract): 
                    $freelancerName = htmlspecialchars($contract['first_name'] . ' ' . $contract['last_name']);
                    $initials = strtoupper(substr($contract['first_name'], 0, 1) . substr($contract['last_name'], 0, 1));
                  ?>
                  <tr class="contract-row" data-contract="<?= $contract['contract_id'] ?>" 
                      onclick="selectContract(<?= $contract['contract_id'] ?>)" style="cursor:pointer;">
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar" style="width:30px;height:30px;font-size:11px;"><?= $initials ?></div>
                        <span><?= $freelancerName ?></span>
                      </div>
                    </td>
                    <td><?= htmlspecialchars($contract['job_title']) ?></td>
                    <td>
                      <div class="progress-wrap" style="min-width:90px">
                        <div class="progress-bar"><div class="progress-fill" style="width:0%"></div></div>
                      </div>
                    </td>
                    <td><span class="badge badge-info"><?= ucfirst($contract['status']) ?></span></td>
                    <td>
                      <button class="btn btn-sm btn-danger" title="Open Dispute"
                        onclick="event.stopPropagation(); openDisputeFor(<?= $contract['contract_id'] ?>, '<?= addslashes($contract['job_title']) ?>', '<?= addslashes($freelancerName) ?>')">
                        <i class="fa-solid fa-flag"></i>
                      </button>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Escrow Overview -->
        <div class="card fade-in-2">
          <div class="card-header">
            <span class="card-title"><i class="fa-solid fa-vault text-accent"></i> &nbsp;Escrow Overview</span>
            <span class="badge badge-info" id="escrowContractBadge">FR20</span>
          </div>
          <div class="card-body" id="escrowBody">
            <!-- rendered by JS -->
          </div>
        </div>
      </div>

      <!-- Row 2 -->
      <div class="grid-2 mb-6">

        <!-- Milestones Timeline -->
        <div class="card fade-in-1">
          <div class="card-header">
            <span class="card-title" id="milestonesTitle"><i class="fa-solid fa-flag-checkered text-accent"></i> &nbsp;Milestones — React Job</span>
            <span class="badge badge-info">FR14</span>
          </div>
          <div class="card-body" id="milestonesBody">
            <!-- rendered by JS -->
          </div>
        </div>

        <!-- Dispute Panel -->
        <div class="card dispute-card fade-in-2">
          <div class="card-header">
            <span class="card-title"><i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Active Dispute</span>
            <span class="badge badge-danger">Under Review</span>
          </div>
          <div class="card-body">
            <div class="mb-4">
              <div class="text-muted text-sm mb-1">Dispute #001 · Contract #54</div>
              <div class="font-bold mb-2">React Job — Slow Delivery</div>
              <div class="text-sm text-muted">"Freelancer has not delivered Phase 2 components within the agreed timeline."</div>
            </div>

            <div class="flex gap-3 mb-4" style="flex-wrap:wrap;">
              <div style="flex:1;min-width:100px;background:var(--bg3);border-radius:8px;padding:12px;">
                <div class="text-muted text-sm">Filed by</div>
                <div class="font-bold text-sm mt-1"><?= $shortName ?> (You)</div>
              </div>
              <div style="flex:1;min-width:100px;background:var(--bg3);border-radius:8px;padding:12px;">
                <div class="text-muted text-sm">Against</div>
                <div class="font-bold text-sm mt-1">Ali Morsy</div>
              </div>
              <div style="flex:1;min-width:100px;background:var(--bg3);border-radius:8px;padding:12px;">
                <div class="text-muted text-sm">Admin Assigned</div>
                <div class="font-bold text-sm mt-1">MrLio (Y. Amer)</div>
              </div>
            </div>

            <div class="mb-4" style="background:var(--bg3);border-radius:8px;padding:14px;">
              <div class="text-muted text-sm mb-2"><i class="fa-solid fa-lock text-warn"></i> &nbsp;Restricted Channel (FR27)</div>
              <div style="font-size:12px;color:var(--muted);max-height:80px;overflow-y:auto;line-height:1.7;">
                <div><strong style="color:var(--text)">MrLio:</strong> Both parties, please provide your latest deliverables.</div>
                <div><strong style="color:var(--accent)">You:</strong> I've uploaded the contract and timeline as evidence.</div>
                <div><strong style="color:var(--text)">Ali Morsy:</strong> I had a medical emergency. Uploading proof now.</div>
              </div>
            </div>

            <div class="flex gap-2" style="flex-wrap:wrap;">
              <button class="btn btn-sm btn-secondary" onclick="showToast('Evidence uploaded to dispute file (FR25)')">
                <i class="fa-solid fa-paperclip"></i> Add Evidence
              </button>
              <button class="btn btn-sm btn-secondary" onclick="showToast('Second review requested (FR31)')">
                <i class="fa-solid fa-rotate-right"></i> Request 2nd Review
              </button>
              <button class="btn btn-sm btn-secondary" onclick="window.location='messages.php'">
                <i class="fa-solid fa-message"></i> Chat
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Row 3 — Recent Proposals & Scheduled Interview -->
      <div class="grid-2">

        <!-- Recent Proposals -->
        <div class="card fade-in-1">
          <div class="card-header">
            <span class="card-title"><i class="fa-solid fa-inbox text-accent"></i> &nbsp;Recent Proposals</span>
            <span class="badge badge-info">12 new</span>
          </div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Freelancer</th><th>Job</th><th>Bid</th><th>Score</th><th>Actions</th></tr>
              </thead>
              <tbody>
                <?php if (empty($recentProposals)): ?>
                <tr>
                  <td colspan="5" style="text-align:center;padding:20px;color:var(--muted);">No new proposals.</td>
                </tr>
                <?php else: ?>
                  <?php foreach ($recentProposals as $prop): 
                    $freelancerName = htmlspecialchars($prop['first_name'] . ' ' . $prop['last_name']);
                    $initials = strtoupper(substr($prop['first_name'], 0, 1) . substr($prop['last_name'], 0, 1));
                  ?>
                  <tr>
                    <td>
                      <div class="flex items-center gap-2">
                        <div class="avatar" style="width:28px;height:28px;font-size:10px;"><?= $initials ?></div> <?= $freelancerName ?>
                      </div>
                    </td>
                    <td><?= htmlspecialchars($prop['job_title']) ?></td>
                    <td class="text-accent font-bold">$<?= number_format($prop['bid_amount']) ?></td>
                    <td><span class="stars">★★★★★</span></td>
                    <td>
                      <div class="flex gap-1">
                        <button class="btn btn-sm btn-secondary" onclick="acceptProposal(<?= $prop['proposal_id'] ?>)">Accept</button>
                        <button class="btn btn-sm btn-danger" onclick="rejectProposal(<?= $prop['proposal_id'] ?>)">Reject</button>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Upcoming Interviews -->
        <div class="card fade-in-2">
          <div class="card-header">
            <span class="card-title"><i class="fa-solid fa-calendar-days text-accent"></i> &nbsp;Scheduled Interviews</span>
            <button class="btn btn-sm btn-primary" onclick="scheduleInterview()">
              <i class="fa-solid fa-plus"></i> Schedule
            </button>
          </div>
          <div class="card-body">
            <div style="display:flex;flex-direction:column;gap:12px;">

              <div style="background:var(--bg3);border-radius:10px;padding:14px;border:1px solid var(--border);display:flex;gap:12px;align-items:center;">
                <div style="background:rgba(0,229,192,.1);border-radius:8px;padding:10px 14px;text-align:center;min-width:52px;">
                  <div class="text-accent font-bold" style="font-size:18px;">22</div>
                  <div class="text-muted text-sm">Apr</div>
                </div>
                <div style="flex:1;">
                  <div class="font-bold text-sm">Ali Morsy — React Job</div>
                  <div class="text-muted text-sm mt-1"><i class="fa-solid fa-clock"></i> 10:00 AM · EET &nbsp;|&nbsp; <i class="fa-solid fa-video"></i> Zoom</div>
                  <div class="text-muted text-sm" style="font-size:11px;margin-top:4px;"><i class="fa-solid fa-globe"></i> Timezone adjusted (FR34)</div>
                </div>
                <button class="btn btn-sm btn-secondary" onclick="copyText('https://zoom.us/j/123456789')">
                  <i class="fa-solid fa-link"></i>
                </button>
              </div>

              <div style="background:var(--bg3);border-radius:10px;padding:14px;border:1px solid var(--border);display:flex;gap:12px;align-items:center;">
                <div style="background:rgba(108,99,255,.1);border-radius:8px;padding:10px 14px;text-align:center;min-width:52px;">
                  <div style="color:var(--accent2);" class="font-bold" style="font-size:18px;">28</div>
                  <div class="text-muted text-sm">Apr</div>
                </div>
                <div style="flex:1;">
                  <div class="font-bold text-sm">Sara Hassan — UI Design</div>
                  <div class="text-muted text-sm mt-1"><i class="fa-solid fa-clock"></i> 2:00 PM · EET &nbsp;|&nbsp; <i class="fa-solid fa-video"></i> Meet</div>
                </div>
                <button class="btn btn-sm btn-secondary" onclick="copyText('https://meet.google.com/abc-defg')">
                  <i class="fa-solid fa-link"></i>
                </button>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div><!-- /page-content -->
  </div><!-- /main -->
</div><!-- /wrapper -->

<!-- ════════════ MODALS ════════════ -->

<!-- Post Job Modal -->
<div class="modal-backdrop hidden" id="postJobModal">
  <div class="modal" style="max-width:560px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-plus-circle text-accent"></i> &nbsp;Post a Job</span>
      <button class="icon-btn" onclick="closeModal('postJobModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <form action="../controllers/post_job.php" method="POST">
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Job Category</label>
        <select class="form-control" name="category" id="jobCategory" onchange="updateJobForm()" required>
          <option value="">Select a category…</option>
          <option value="Web Development">Web Development</option>
          <option value="UI/UX Design">UI/UX Design</option>
          <option value="Content Writing">Content Writing</option>
          <option value="Data Science">Data Science</option>
          <option value="Mobile Development">Mobile Development</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Job Title</label>
        <input type="text" name="title" class="form-control" placeholder="e.g. Build a React Dashboard" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" placeholder="Describe the project scope and requirements…" required></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Budget ($)</label>
          <input type="number" name="budget" class="form-control" placeholder="1250" min="1" required>
        </div>
        <div class="form-group">
          <label class="form-label">Deadline</label>
          <input type="date" class="form-control">
        </div>
      </div>
      <div id="dynamicFields"></div>
      <div class="flex gap-2 items-center" style="margin-top:8px;">
        <input type="checkbox" id="privateJob" style="accent-color:var(--accent)">
        <label for="privateJob" style="font-size:13px;cursor:pointer;">
          <i class="fa-solid fa-lock text-accent"></i> &nbsp;Private job — invite only
        </label>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary btn-sm" onclick="closeModal('postJobModal')">Cancel</button>
      <button type="submit" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-paper-plane"></i> Publish Job
      </button>
    </div>
    </form>
  </div>
</div>

<!-- Schedule Interview Modal -->
<div class="modal-backdrop hidden" id="interviewModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-calendar-check text-accent"></i> &nbsp;Schedule Interview</span>
      <button class="icon-btn" onclick="closeModal('interviewModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Freelancer</label>
        <select class="form-control">
          <option>Ali Morsy</option>
          <option>Sara Hassan</option>
        </select>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Date</label>
          <input type="date" class="form-control">
        </div>
        <div class="form-group">
          <label class="form-label">Time (Local)</label>
          <input type="time" class="form-control">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Platform</label>
        <select class="form-control">
          <option>Zoom</option>
          <option>Google Meet</option>
          <option>Microsoft Teams</option>
        </select>
      </div>
      <div style="background:rgba(0,229,192,.06);border:1px solid rgba(0,229,192,.15);border-radius:8px;padding:12px;font-size:12px;color:var(--muted);">
        <i class="fa-solid fa-globe text-accent"></i> &nbsp;Calendar will be synced & timezone auto-adjusted (FR34)
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('interviewModal')">Cancel</button>
      <button class="btn btn-primary btn-sm" onclick="closeModal('interviewModal');showToast('Interview scheduled! Both parties notified.')">
        <i class="fa-solid fa-calendar-plus"></i> Confirm
      </button>
    </div>
  </div>
</div>

<!-- Open Dispute Modal -->
<div class="modal-backdrop hidden" id="disputeModal">
  <div class="modal" style="max-width:520px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Open Dispute</span>
      <button class="icon-btn" onclick="closeModal('disputeModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <!-- pre-filled contract info banner -->
      <div class="form-group">
        <label class="form-label">Related Contract</label>
        <select class="form-control" id="disputeContractSelect">
          <option value="54">Contract #54 — React Job (Ali Morsy)</option>
          <option value="55">Contract #55 — UI Design (Sara Hassan)</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Reason</label>
        <textarea class="form-control" id="disputeReason" rows="3" placeholder="Describe the issue in detail…"></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Upload Evidence (FR25)</label>
        <input type="file" class="form-control" multiple>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('disputeModal')">Cancel</button>
      <button class="btn btn-danger btn-sm" onclick="closeModal('disputeModal');showToast('Dispute filed. Admin assigned.','warn')">
        <i class="fa-solid fa-flag"></i> File Dispute
      </button>
    </div>
  </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/chat-sidebar.js"></script>
<script src="../assets/js/contractEvents.js"></script>
<script>
/* ══════════════════════════════════════════════════════════
   CONTRACT DATA
   ══════════════════════════════════════════════════════════
   escrowLocked  = المبلغ المُقفَل حالياً في escrow للـ milestone النشط
   releasedTotal = إجمالي ما صدر للـ freelancer
   totalValue    = إجمالي قيمة الكونتراكت كاملاً
   ══════════════════════════════════════════════════════════ */
const contractsData = {
  <?php foreach($activeContracts as $c): ?>
  <?= $c['contract_id'] ?>: {
    title:        '<?= addslashes($c['job_title']) ?>',
    freelancer:   '<?= addslashes($c['first_name'] . " " . $c['last_name']) ?>',
    initials:     '<?= strtoupper(substr($c['first_name'], 0, 1) . substr($c['last_name'], 0, 1)) ?>',
    gradient:     '135deg,#22c55e,#00e5c0',
    clientBudget: <?= $c['bid_amount'] ?>,
    escrowLocked: <?= $c['bid_amount'] ?>,
    releasedTotal: 0,
    totalValue:   <?= $c['bid_amount'] ?>,
    milestones: [
      { id:1, title:'Project Implementation', amount:<?= $c['bid_amount'] ?>, status:'active', due:'TBD', funded:true, progress:0 },
    ],
  },
  <?php endforeach; ?>
};

let activeContractId = <?= !empty($activeContracts) ? $activeContracts[0]['contract_id'] : 'null' ?>;
const ROW_ACTIVE_STYLE = 'background:rgba(0,229,192,.07);outline:2px solid var(--accent);outline-offset:-2px;border-radius:6px;';

/* ══════════════════════════════════════════════════════════
   GLOBAL STATS — حساب مجموع escrow كل الكونتراكتس
   ══════════════════════════════════════════════════════════ */
function calcTotalEscrow() {
  return Object.values(contractsData).reduce((sum, c) => sum + c.escrowLocked, 0);
}

function calcActiveContracts() {
  return Object.values(contractsData).filter(c =>
    c.milestones.some(m => m.status === 'active')
  ).length;
}

function updateStatCards() {
  const totalEscrow     = calcTotalEscrow();
  const activeContracts = calcActiveContracts();

  /* In Escrow stat */
  const escrowEl  = document.getElementById('statEscrow');
  const changeEl  = document.getElementById('statEscrowChange');
  if (escrowEl) {
    escrowEl.textContent = '$' + totalEscrow.toLocaleString();
    /* لو بقى صفر وضّح إن فيه حاجة ناقصة */
    if (changeEl) {
      if (totalEscrow === 0) {
        changeEl.textContent = 'No funds locked';
        changeEl.className   = 'change down';
      } else {
        changeEl.textContent = 'Secured';
        changeEl.className   = 'change up';
      }
    }
    /* flash animation */
    escrowEl.style.transition = 'color .3s';
    escrowEl.style.color      = 'var(--accent)';
    setTimeout(() => { escrowEl.style.color = ''; }, 600);
  }

  /* Active Contracts stat */
  const contractsEl = document.getElementById('statActiveContracts');
  if (contractsEl) contractsEl.textContent = activeContracts;
}

/* ══════════════════════════════════════════════════════════
   selectContract
   ══════════════════════════════════════════════════════════ */
function selectContract(id) {
  if (activeContractId === id) return;
  activeContractId = id;

  document.querySelectorAll('.contract-row').forEach(row => {
    row.style.cssText = '';
    row.classList.remove('active-row');
  });
  const activeRow = document.querySelector(`.contract-row[data-contract="${id}"]`);
  if (activeRow) {
    activeRow.style.cssText = ROW_ACTIVE_STYLE;
    activeRow.classList.add('active-row');
  }

  renderEscrow(id);
  renderMilestones(id);
}

/* ══════════════════════════════════════════════════════════
   fundMilestone — يقفل المبلغ في escrow للـ milestone النشط
   ══════════════════════════════════════════════════════════ */
function fundMilestone(contractId, amount) {
  const c = contractsData[contractId];
  if (!c) return;

  /* إيجاد الـ active milestone اللي لسه مش funded */
  const m = c.milestones.find(ms => ms.status === 'active' && !ms.funded);
  if (!m) {
    showToast('No pending milestone to fund.', 'warn');
    return;
  }

  const confirmed = confirm(
    `Fund "${m.title}" with $${m.amount.toLocaleString()} into escrow?\n\nThis amount will be locked until you approve the work.`
  );
  if (!confirmed) return;

  /* تحديث الداتا */
  m.funded          = true;
  c.escrowLocked   += m.amount;

  showToast(`$${m.amount.toLocaleString()} funded into escrow for "${m.title}" (FR20)`);

  /* ── notify freelancer via cross-page event ── */
  if (typeof window.CE_emit === 'function') {
    window.CE_emit('funded', contractId, m.id, m.amount, c.freelancer);
  }

  /* إعادة رسم كل حاجة */
  renderEscrow(contractId);
  renderMilestones(contractId);
  updateStatCards();

  /* تحديث badge الصف في الجدول */
  const row = document.querySelector(`.contract-row[data-contract="${contractId}"]`);
  if (row) {
    const badge = row.querySelector('.badge');
    if (badge) { badge.className = 'badge badge-info'; badge.textContent = 'In Progress'; }
  }
}

/* ══════════════════════════════════════════════════════════
   approveMilestone — يحرّر الـ payment ويفتح الـ phase التالية
   ══════════════════════════════════════════════════════════ */
function approveMilestone(contractId, milestoneId) {
  const c   = contractsData[contractId];
  const idx = c.milestones.findIndex(m => m.id === milestoneId);
  if (idx === -1) return;

  const m = c.milestones[idx];
  if (m.status !== 'active') return;

  /* التحقق إن الـ milestone مموّل قبل التحرير */
  if (!m.funded) {
    showToast('Fund this milestone first before approving!', 'error');
    return;
  }

  /* 1 — تحديث هذه المرحلة: done */
  c.releasedTotal += m.amount;
  c.escrowLocked  -= m.amount;
  if (c.escrowLocked < 0) c.escrowLocked = 0;
  m.status = 'done';

  /* 2 — فتح المرحلة التالية */
  const next = c.milestones[idx + 1];
  if (next && next.status === 'locked') {
    next.status   = 'active';
    next.progress = 0;
    next.funded   = false;       // تحتاج تمويل جديد
    /* escrow لا يُقفل تلقائياً — العميل لازم يضغط Fund */
  }

  const isComplete = c.milestones.every(ms => ms.status === 'done');

  /* 3 — toast */
  if (isComplete) {
    showToast(`🎉 Contract #${contractId} complete! $${m.amount.toLocaleString()} released. Total paid: $${c.releasedTotal.toLocaleString()}`);
  } else {
    showToast(
      next
        ? `Phase ${milestoneId} approved! $${m.amount.toLocaleString()} released → Fund Phase ${next.id} to continue.`
        : `Phase ${milestoneId} approved! $${m.amount.toLocaleString()} released.`
    );
  }

  /* ── notify freelancer via cross-page event ── */
  if (typeof window.CE_emit === 'function') {
    window.CE_emit('released', contractId, milestoneId, m.amount, c.freelancer);
  }

  /* 4 — re-render panels */
  renderMilestones(contractId);
  renderEscrow(contractId);
  updateStatCards();

  /* 5 — تحديث progress bar في جدول الكونتراكتس */
  const doneCount = c.milestones.filter(ms => ms.status === 'done').length;
  const pct = Math.round((doneCount / c.milestones.length) * 100);
  const row = document.querySelector(`.contract-row[data-contract="${contractId}"]`);
  if (row) {
    const fill = row.querySelector('.progress-fill');
    if (fill) { fill.style.width = pct + '%'; fill.dataset.width = pct + '%'; }
    const badge = row.querySelector('.badge');
    if (badge && isComplete) { badge.className = 'badge badge-success'; badge.textContent = 'Completed'; }
  }
}

/* ══════════════════════════════════════════════════════════
   renderEscrow
   ══════════════════════════════════════════════════════════ */
function renderEscrow(id) {
  const c     = contractsData[id];
  const body  = document.getElementById('escrowBody');
  const badge = document.getElementById('escrowContractBadge');

  badge.textContent = 'Contract #' + id;
  badge.className   = 'badge badge-info';

  /* الـ milestone النشط */
  const activeMilestone = c.milestones.find(m => m.status === 'active');
  /* الـ milestone الأول locked (ما بعد النشط) */
  const nextLocked = c.milestones.find(m => m.status === 'locked');

  /* صف الـ milestone النشط */
  let activeRowHTML = '';
  if (activeMilestone) {
    if (activeMilestone.funded) {
      /* مموّل → يمكن إصداره */
      activeRowHTML = `
        <div class="flex items-center gap-3 mb-3">
          <span class="text-muted text-sm" style="flex:1;">${c.title} — ${activeMilestone.title.split('—')[0].trim()}</span>
          <span class="badge badge-success"><i class="fa-solid fa-lock"></i> $${activeMilestone.amount.toLocaleString()} Funded</span>
          <button class="btn btn-sm btn-primary" onclick="approveMilestone(${id},${activeMilestone.id})">
            <i class="fa-solid fa-check"></i> Release
          </button>
        </div>`;
    } else {
      /* غير مموّل → يحتاج fund */
      activeRowHTML = `
        <div class="flex items-center gap-3 mb-3">
          <span class="text-muted text-sm" style="flex:1;">${c.title} — ${activeMilestone.title.split('—')[0].trim()}</span>
          <span class="badge badge-warn"><i class="fa-solid fa-clock"></i> Needs Funding</span>
          <button class="btn btn-sm btn-secondary" onclick="fundMilestone(${id},${activeMilestone.amount})">
            <i class="fa-solid fa-vault"></i> Fund $${activeMilestone.amount.toLocaleString()}
          </button>
        </div>`;
    }
  }

  /* صف الـ milestone القادم (locked) */
  let nextRowHTML = '';
  if (nextLocked) {
    nextRowHTML = `
      <div class="flex items-center gap-3">
        <span class="text-muted text-sm" style="flex:1;">${c.title} — ${nextLocked.title.split('—')[0].trim()}</span>
        <span class="badge badge-muted"><i class="fa-solid fa-lock"></i> Locked</span>
        <span class="text-muted text-sm">$${nextLocked.amount.toLocaleString()}</span>
      </div>`;
  }

  /* إجمالي قيمة الكونتراكت */
  const totalValue    = c.milestones.reduce((s, m) => s + m.amount, 0);
  const remainingVal  = totalValue - c.releasedTotal;
  const isComplete    = c.milestones.every(m => m.status === 'done');

  body.style.opacity   = '0';
  body.style.transform = 'translateY(8px)';
  body.style.transition = 'opacity .25s, transform .25s';

  body.innerHTML = `
    <div class="escrow-visual">
      <div class="escrow-party">
        <div class="ep-label">You (Client)</div>
        <div class="avatar" style="margin:0 auto 8px;"><?= $initials ?></div>
        <div class="ep-amount">$${c.clientBudget.toLocaleString()}</div>
        <div class="ep-name"><?= $shortName ?></div>
      </div>
      <div class="escrow-arrow">
        <div class="arrow-bar"></div>
        <div class="escrow-vault">${isComplete ? '✅' : '🔒'}</div>
        <div class="escrow-label">ESCROW</div>
        <div class="text-muted text-sm mt-1" style="color:${c.escrowLocked > 0 ? 'var(--accent)' : 'var(--warn)'};">
          $${c.escrowLocked.toLocaleString()} locked
        </div>
        <div class="arrow-bar" style="margin-top:4px"></div>
      </div>
      <div class="escrow-party">
        <div class="ep-label">Freelancer</div>
        <div class="avatar" style="margin:0 auto 8px;background:linear-gradient(${c.gradient});">${c.initials}</div>
        <div class="ep-amount" style="color:var(--success);">$${c.releasedTotal.toLocaleString()}</div>
        <div class="ep-name">Released so far</div>
      </div>
    </div>

    <!-- Summary bar -->
    <div style="margin:12px 0 14px;background:var(--bg3);border-radius:8px;padding:10px 14px;">
      <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-bottom:6px;">
        <span>Released</span>
        <span>Remaining</span>
      </div>
      <div class="progress-bar" style="height:8px;border-radius:4px;">
        <div class="progress-fill" style="width:${totalValue > 0 ? Math.round((c.releasedTotal/totalValue)*100) : 0}%;height:100%;border-radius:4px;background:var(--success);"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-top:5px;">
        <span style="color:var(--success);font-weight:700;">$${c.releasedTotal.toLocaleString()} / $${totalValue.toLocaleString()}</span>
        <span style="color:var(--muted);">$${remainingVal.toLocaleString()} remaining</span>
      </div>
    </div>

    <div style="border-top:1px solid var(--border);padding-top:14px;">
      ${activeRowHTML || (!isComplete ? '' : `<div class="text-sm text-success" style="text-align:center;padding:8px;"><i class="fa-solid fa-circle-check"></i> Contract fully completed &amp; paid</div>`)}
      ${nextRowHTML}
    </div>`;

  requestAnimationFrame(() => {
    body.style.opacity   = '1';
    body.style.transform = 'translateY(0)';
  });
}

/* ══════════════════════════════════════════════════════════
   renderMilestones
   ══════════════════════════════════════════════════════════ */
function renderMilestones(id) {
  const c     = contractsData[id];
  const title = document.getElementById('milestonesTitle');
  const body  = document.getElementById('milestonesBody');

  title.innerHTML = `<i class="fa-solid fa-flag-checkered text-accent"></i> &nbsp;Milestones — ${c.title}`;

  body.style.opacity    = '0';
  body.style.transform  = 'translateY(8px)';
  body.style.transition = 'opacity .25s, transform .25s';

  body.innerHTML = '<div class="milestone-list">' +
    c.milestones.map(m => buildMilestoneHTML(id, m)).join('') +
  '</div>';

  requestAnimationFrame(() => {
    body.style.opacity   = '1';
    body.style.transform = 'translateY(0)';
  });
}

/* ── builds a single milestone item ── */
function buildMilestoneHTML(contractId, m) {
  const dotClass = m.status === 'done'   ? 'milestone-dot done'
                 : m.status === 'active' ? 'milestone-dot active'
                 : 'milestone-dot';

  const dotIcon  = m.status === 'done'   ? '<i class="fa-solid fa-check"></i>'
                 : m.status === 'active' ? '<i class="fa-solid fa-spinner fa-spin" style="font-size:10px;"></i>'
                 : '<i class="fa-solid fa-lock" style="font-size:10px;"></i>';

  let metaHTML = '';

  if (m.status === 'done') {
    metaHTML = `<div class="milestone-meta">Completed · ${m.due} · <span style="color:var(--success);">$${m.amount.toLocaleString()} released</span></div>`;

  } else if (m.status === 'active') {
    const fundNotice = !m.funded
      ? `<div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);border-radius:8px;padding:9px 12px;font-size:12px;color:var(--warn);margin-bottom:10px;">
           <i class="fa-solid fa-triangle-exclamation"></i> &nbsp;Milestone not funded yet — fund it first to allow work to begin (FR20)
         </div>`
      : (m.submitted
          ? `<div style="background:rgba(108,99,255,.12);border:1px solid rgba(108,99,255,.4);border-radius:8px;padding:9px 12px;font-size:12px;color:#a78bfa;margin-bottom:10px;">
               <i class="fa-solid fa-upload"></i> &nbsp;Freelancer submitted work — review &amp; release payment (FR15)
             </div>`
          : `<div style="background:rgba(34,197,94,.07);border:1px solid rgba(34,197,94,.2);border-radius:8px;padding:7px 12px;font-size:12px;color:var(--success);margin-bottom:10px;">
               <i class="fa-solid fa-lock"></i> &nbsp;$${m.amount.toLocaleString()} secured in escrow
             </div>`);

    const buttons = m.funded
      ? (m.submitted
          ? `<button class="btn btn-sm btn-primary" style="animation:cePulse 1.2s infinite alternate;"
               onclick="approveMilestone(${contractId},${m.id})">
               <i class="fa-solid fa-circle-check"></i> Release $${m.amount.toLocaleString()}
             </button>
             <button class="btn btn-sm btn-danger" onclick="openDisputeFlow()">
               <i class="fa-solid fa-flag"></i> Dispute
             </button>`
          : `<button class="btn btn-sm btn-primary" onclick="approveMilestone(${contractId},${m.id})">
               <i class="fa-solid fa-check"></i> Approve &amp; Release
             </button>
             <button class="btn btn-sm btn-danger" onclick="openDisputeFlow()">
               <i class="fa-solid fa-flag"></i> Dispute
             </button>`)
      : `<button class="btn btn-sm btn-secondary" onclick="fundMilestone(${contractId},${m.amount})">
           <i class="fa-solid fa-vault"></i> Fund $${m.amount.toLocaleString()} into Escrow
         </button>`;

    metaHTML = `
      <div class="milestone-meta flex gap-3 mt-1">
        <span>Due: ${m.due}</span>
        <span class="${m.funded ? 'text-accent' : 'text-warn'}">$${m.amount.toLocaleString()} ${m.funded ? 'in escrow' : '— not funded'}</span>
      </div>
      <div class="progress-wrap mt-2">
        <div class="progress-label"><span>Progress</span><span>${m.progress || 0}%</span></div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${m.progress || 0}%;" data-width="${m.progress || 0}%"></div>
        </div>
      </div>
      <div style="margin-top:12px;">${fundNotice}</div>
      <div class="flex gap-2">${buttons}</div>`;

  } else {
    /* locked */
    metaHTML = `<div class="milestone-meta">Locked — awaiting previous phase · $${m.amount.toLocaleString()}</div>`;
  }

  return `
    <div class="milestone-item">
      <div class="${dotClass}">${dotIcon}</div>
      <div class="milestone-content">
        <div class="milestone-title">${m.title}</div>
        ${metaHTML}
      </div>
    </div>`;
}

/* ══════════════════════════════════════════════════════════
   openDisputeFor — pre-fills the dispute modal with contract info
   ══════════════════════════════════════════════════════════ */
function openDisputeFor(contractId, projectName, freelancerName) {
  /* set the select */
  const sel = document.getElementById('disputeContractSelect');
  if (sel) sel.value = contractId;

  /* show the banner */
  const banner   = document.getElementById('disputeContractBanner');
  const bannerTxt = document.getElementById('disputeBannerText');
  if (banner && bannerTxt) {
    bannerTxt.innerHTML =
      `<strong>Contract #${contractId}</strong> — ${projectName} &nbsp;·&nbsp; Against: <strong>${freelancerName}</strong>`;
    banner.style.display = '';
  }

  /* clear previous reason */
  const reason = document.getElementById('disputeReason');
  if (reason) reason.value = '';

  openModal('disputeModal');
}

/* keep the old openDisputeFlow working (from milestone Dispute btn) */
function openDisputeFlow() {
  openDisputeFor(activeContractId,
    contractsData[activeContractId]?.title      || '—',
    contractsData[activeContractId]?.freelancer || '—'
  );
}

function acceptProposal(proposalId) {
  if(!confirm("Are you sure you want to accept this proposal and create a contract?")) return;

  fetch('../controllers/accept_proposal.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `proposal_id=${proposalId}`
  })
  .then(res => res.json())
  .then(data => {
    if(data.success) {
      showToast("Proposal accepted! Contract created 🔥");
      setTimeout(() => window.location.reload(), 1500);
    } else {
      console.error("Accept error:", data.error);
      showToast(data.error || "Error accepting proposal", "error");
    }
  })
  .catch(err => {
    console.error("Fetch error:", err);
    showToast("Server error. Please try again.", "error");
  });
}

function rejectProposal(proposalId) {
  if(!confirm("Are you sure you want to reject this proposal?")) return;

  fetch('../controllers/reject_proposal.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `proposal_id=${proposalId}`
  })
  .then(res => res.json())
  .then(data => {
    if(data.success) {
      showToast("Proposal rejected successfully.");
      setTimeout(() => window.location.reload(), 1500);
    } else {
      showToast(data.error || "Error rejecting proposal", "error");
    }
  });
}


function updateJobForm() {
  const cat = document.getElementById('jobCategory').value;
  const el  = document.getElementById('dynamicFields');
  const fields = {
    dev:     `<div class="form-group"><label class="form-label">Tech Stack</label><input type="text" class="form-control" placeholder="React, Node.js, PostgreSQL…"></div>`,
    design:  `<div class="form-group"><label class="form-label">Design Tools Required</label><input type="text" class="form-control" placeholder="Figma, Adobe XD…"></div>`,
    writing: `<div class="form-group"><label class="form-label">Word Count / Deliverable</label><input type="text" class="form-control" placeholder="e.g. 5 blog posts, 1000 words each"></div>`,
    data:    `<div class="form-group"><label class="form-label">Dataset / Tools</label><input type="text" class="form-control" placeholder="Python, TensorFlow, CSV data…"></div>`,
  };
  el.innerHTML = cat && fields[cat] ? fields[cat] : '';
}

/* ══════════════════════════════════════════════════════════
   Init
   ══════════════════════════════════════════════════════════ */
/* cePulse for submitted-work release button */
const _cePulseStyle = document.createElement('style');
_cePulseStyle.textContent = `
  @keyframes cePulse {
    from { box-shadow: 0 0 0 0 rgba(108,99,255,.6); }
    to   { box-shadow: 0 0 0 8px rgba(108,99,255,0); }
  }
`;
document.head.appendChild(_cePulseStyle);
document.addEventListener('DOMContentLoaded', () => {
  /* highlight default row */
  const defaultRow = document.querySelector('.contract-row.active-row');
  if (defaultRow) defaultRow.style.cssText = ROW_ACTIVE_STYLE;

  /* initial render */
  renderEscrow(54);
  renderMilestones(54);
  updateStatCards();
});
</script>

<?php include 'chat_sidebar.php'; ?>

</body>
</html>