<?php
// jobs.php — Browse Jobs (Freelancer view)
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?mode=login");
    exit();
}

$userModel = new UserModel();
$user      = $userModel->getUserById($_SESSION['user_id']);

if (!$user) {
    session_destroy();
    header("Location: index.php?mode=login");
    exit();
}

$firstName = htmlspecialchars($user['first_name']);
$lastName  = htmlspecialchars($user['last_name']);
$initials  = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
$shortName = $firstName . '. ' . $lastName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Browse Jobs</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/chat-sidebar.css">
  <style>
    /* ── Page-specific extras ── */
    .job-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 22px 24px;
      transition: border-color .2s, transform .2s, box-shadow .2s;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .job-card::before {
      content: '';
      position: absolute;
      top: 0; left: 0;
      width: 4px; height: 100%;
      background: var(--border);
      transition: background .2s;
    }
    .job-card:hover { border-color: var(--accent); transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,229,192,.08); }
    .job-card:hover::before { background: var(--accent); }
    .job-card.featured::before { background: var(--warn); }
    .job-card.featured { border-color: rgba(245,158,11,.3); }

    .job-title { font-family: 'Syne', sans-serif; font-size: 16px; font-weight: 700; margin-bottom: 6px; }
    .job-meta  { display: flex; flex-wrap: wrap; gap: 14px; font-size: 12px; color: var(--muted); margin-bottom: 12px; }
    .job-meta span { display: flex; align-items: center; gap: 5px; }
    .job-desc  { font-size: 13px; color: var(--muted); line-height: 1.6; margin-bottom: 14px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .job-footer { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
    .job-budget { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 800; color: var(--accent); }

    .filter-sidebar { width: 260px; flex-shrink: 0; }
    .filter-section { margin-bottom: 22px; }
    .filter-section-title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 12px; text-transform: uppercase; letter-spacing: .8px; color: var(--muted); margin-bottom: 10px; }
    .filter-option { display: flex; align-items: center; gap: 9px; padding: 6px 0; cursor: pointer; font-size: 13px; color: var(--text); }
    .filter-option input { accent-color: var(--accent); width: 14px; height: 14px; cursor: pointer; }
    .filter-option .count { margin-left: auto; font-size: 11px; color: var(--muted); background: var(--bg3); border-radius: 10px; padding: 1px 7px; }

    .search-bar-wrap {
      display: flex; gap: 10px; margin-bottom: 24px; align-items: stretch;
    }
    .search-bar-wrap .form-control {
      flex: 1; padding: 11px 16px; font-size: 14px;
    }
    .search-bar-wrap .btn { padding: 11px 20px; }

    .jobs-layout { display: flex; gap: 24px; align-items: flex-start; }
    .jobs-list { flex: 1; display: flex; flex-direction: column; gap: 14px; }

    .sort-bar { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
    .sort-bar .results-count { font-size: 13px; color: var(--muted); margin-right: auto; }

    .pagination { display: flex; gap: 6px; justify-content: center; margin-top: 24px; }
    .page-btn { width: 36px; height: 36px; border-radius: 8px; border: 1px solid var(--border); background: var(--panel); color: var(--muted); display: flex; align-items: center; justify-content: center; font-size: 13px; cursor: pointer; transition: all .2s; font-family: 'Syne', sans-serif; font-weight: 700; }
    .page-btn:hover, .page-btn.active { border-color: var(--accent); color: var(--accent); background: rgba(0,229,192,.06); }

    .range-slider { -webkit-appearance: none; width: 100%; height: 4px; border-radius: 2px; background: var(--border); outline: none; }
    .range-slider::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; border-radius: 50%; background: var(--accent); cursor: pointer; }
  </style>
</head>
<body>
<div class="wrapper">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo"><div class="brand">Free<span>Lynk</span></div></div>
    <div class="sidebar-user">
      <div class="avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);"><?= $initials ?></div>
      <div class="sidebar-user-info">
        <div class="name"><?= $shortName ?></div>
        <div class="role">Freelancer</div>
      </div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Overview</div>
      <div class="nav-item" onclick="window.location='freelancer_dashboard.php'">
        <i class="fa-solid fa-gauge-high"></i> Dashboard
      </div>
     
      <div class="nav-section-label mt-3">Work</div>
      <div class="nav-item active" onclick="window.location='jobs.php'">
        <i class="fa-solid fa-magnifying-glass"></i> Browse Jobs
      </div>
      <div class="nav-section-label mt-3">Disputes</div>
      <div class="nav-item" onclick="openDisputeFlow()">
        <i class="fa-solid fa-triangle-exclamation"></i> Open Dispute
      </div>
    </nav>
    <div class="sidebar-footer">
      <div class="nav-item" onclick="window.location='index.php'">
        <i class="fa-solid fa-right-from-bracket"></i> Sign Out
      </div>
    </div>
  </aside>

  <!-- ── Main ── -->
  <div class="main">
    <div class="topbar">
      <span class="page-title">Browse Jobs</span>
      <div class="topbar-actions">
        <div class="icon-btn" onclick="showToast('No new notifications')">
          <i class="fa-solid fa-bell"></i><span class="notif-dot"></span>
        </div>
        <a href="freelancer_profile.php">
          <div class="avatar" style="width:34px;height:34px;font-size:12px;background:linear-gradient(135deg,#22c55e,#00e5c0);"><?= $initials ?></div>
        </a>
      </div>
    </div>

    <div class="page-content">

      <!-- Search Bar -->
      <div class="search-bar-wrap fade-in">
        <input type="text" class="form-control" id="jobSearch" placeholder="Search jobs by title, skill, or keyword…" oninput="filterJobs()">
        <select class="form-control" id="categoryFilter" style="max-width:180px;" onchange="filterJobs()">
          <option value="">All Categories</option>
          <option value="Web Development">Web Dev</option>
          <option value="UI/UX Design">UI/UX</option>
          <option value="Data Science">Data Science</option>
          <option value="Content Writing">Writing</option>
          <option value="Mobile Dev">Mobile</option>
          <option value="DevOps">DevOps</option>
        </select>
        <button class="btn btn-primary" onclick="filterJobs()"><i class="fa-solid fa-magnifying-glass"></i> Search</button>
      </div>

      <!-- Layout -->
      <div class="jobs-layout">

        <!-- ── Filter Sidebar ── -->
        <div class="filter-sidebar fade-in-1" style="display: none;">
          <div class="card">
            <div class="card-header" style="padding:16px 20px;">
              <span class="card-title" style="font-size:13px;"><i class="fa-solid fa-sliders text-accent"></i> &nbsp;Filters</span>
              <button class="btn btn-sm" style="font-size:11px;color:var(--accent);background:none;border:none;cursor:pointer;padding:0;" onclick="resetFilters()">Reset</button>
            </div>
            <div style="padding:16px 20px;">

              <!-- Budget Range -->
              <div class="filter-section">
                <div class="filter-section-title">Budget Range</div>
                <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-bottom:8px;">
                  <span>$0</span><span id="budgetVal" class="text-accent font-bold">$5,000</span>
                </div>
                <input type="range" class="range-slider" min="0" max="10000" value="5000" id="budgetRange" oninput="document.getElementById('budgetVal').textContent='$'+parseInt(this.value).toLocaleString();filterJobs()">
              </div>

            </div>
          </div>
        </div>

        <!-- ── Jobs List ── -->       
         <div style="flex:1;">
          <div class="sort-bar fade-in-2">
            <span class="results-count" id="resultsCount">Showing <strong id="jobCount">...</strong> jobs</span>
          </div>

          <div class="jobs-list" id="jobsList">
            <?php
            // ── Jobs من الداتابيز (اللي نشرها الـ clients) ──
            $dbJobs = [];
            try {
                require_once '../models/Database.php';
                require_once '../models/JobModel.php';
                $jobModel = new JobModel();
                $rawJobs  = $jobModel->getOpenJobs();
                foreach ($rawJobs as $j) {
                    $clientName = htmlspecialchars($j['first_name'] . ' ' . $j['last_name']);
                    $dbJobs[] = [
                        'id'         => (int)$j['job_id'],
                        'title'      => htmlspecialchars($j['title']),
                        'client'     => $clientName,
                        'location'   => 'Remote · Egypt',
                        'category'   => htmlspecialchars($j['category']),
                        'budget'     => '$' . number_format($j['budget']),
                        'budget_raw' => (int)$j['budget'],
                        'type'       => 'Fixed Price',
                        'level'      => 'Intermediate',
                        'duration'   => 'TBD',
                        'proposals'  => (int)$j['proposal_count'],
                        'posted'     => 'Recently',
                        'desc'       => htmlspecialchars($j['description']),
                        'skills'     => [htmlspecialchars($j['category'])],
                        'featured'   => false,
                        'verified'   => true,
                        'is_new'     => true,
                    ];
                }
            } catch (Exception $e) {
                // لو في مشكلة في الداتابيز، نكمل بالـ static jobs بس
            }


            // ── دمج الـ DB jobs (الأحدث أولاً) مع الـ static jobs ──
            $jobs = $dbJobs ; 
            $totalJobs = count($jobs);
            ?>
            <script>document.getElementById('jobCount').textContent = '<?= $totalJobs ?>';</script>

            <?php foreach($jobs as $job): ?>
            <div class="job-card fade-in <?= $job['featured'] ? 'featured' : '' ?>"
                 data-title="<?= strtolower($job['title']) ?>"
                 data-category="<?= $job['category'] ?>"
                 data-budget="<?= $job['budget_raw'] ?>"
                 onclick="openJobDetail(<?= $job['id'] ?>)">

              <!-- Top row -->
              <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:10px;">
                <div style="flex:1;">
                  <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                    <?php if(!empty($job['is_new'])): ?>
                    <span class="badge badge-info" style="font-size:10px;"><i class="fa-solid fa-bolt"></i> New</span>
                    <?php endif; ?>
                    <?php if($job['featured']): ?>
                    <span class="badge badge-warn" style="font-size:10px;"><i class="fa-solid fa-star"></i> Featured</span>
                    <?php endif; ?>
                    <?php if($job['verified']): ?>
                    <span class="badge badge-success" style="font-size:10px;"><i class="fa-solid fa-shield-check"></i> Verified Client</span>
                    <?php endif; ?>
                    <span class="badge badge-muted" style="font-size:10px;"><?= $job['type'] ?></span>
                  </div>
                  <div class="job-title"><?= $job['title'] ?></div>
                </div>
                <button class="icon-btn" onclick="event.stopPropagation();toggleSave(this)" title="Save job">
                  <i class="fa-regular fa-bookmark"></i>
                </button>
              </div>

              <!-- Meta -->
              <div class="job-meta">
                <span><i class="fa-solid fa-building"></i> <?= $job['client'] ?></span>
                <span><i class="fa-solid fa-location-dot"></i> <?= $job['location'] ?></span>
                <span><i class="fa-solid fa-layer-group"></i> <?= $job['category'] ?></span>
                <span><i class="fa-solid fa-signal"></i> <?= $job['level'] ?></span>
                <span><i class="fa-solid fa-clock"></i> <?= $job['duration'] ?></span>
                <span><i class="fa-solid fa-users"></i> <?= $job['proposals'] ?> proposals</span>
              </div>

              <!-- Description -->
              <p class="job-desc"><?= $job['desc'] ?></p>

              <!-- Skills -->
              <div class="skill-tags mb-3">
                <?php foreach($job['skills'] as $s): ?>
                <span class="skill-tag" style="font-size:11px;padding:3px 8px;"><?= $s ?></span>
                <?php endforeach; ?>
              </div>

              <!-- Footer -->
              <div class="job-footer">
                <div class="job-budget"><?= $job['budget'] ?></div>
                <span class="text-muted text-sm" style="margin-right:auto;">Posted <?= $job['posted'] ?></span>
                <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();openJobDetail(<?= $job['id'] ?>)">
                  View Details
                </button>
                <button class="btn btn-sm btn-primary" onclick="event.stopPropagation();openProposalModal(<?= $job['id'] ?>, '<?= addslashes($job['title']) ?>', '<?= $job['budget'] ?>')">
                  <i class="fa-solid fa-paper-plane"></i> Apply Now
                </button>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

         
        </div><!-- /jobs-list wrap -->

      </div><!-- /jobs-layout -->
    </div><!-- /page-content -->
  </div><!-- /main -->
</div><!-- /wrapper -->

<!-- ════════════ JOB DETAIL MODAL ════════════ -->
<div class="modal-backdrop hidden" id="jobDetailModal">
  <div class="modal" style="max-width:640px;max-height:90vh;overflow-y:auto;">
    <div class="modal-header" style="position:sticky;top:0;background:var(--panel);z-index:1;">
      <span class="modal-title" id="jobDetailTitle"><i class="fa-solid fa-briefcase text-accent"></i> &nbsp;Job Details</span>
      <button class="icon-btn" onclick="closeModal('jobDetailModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body" id="jobDetailBody">
      <!-- filled by JS -->
    </div>
    <div class="modal-footer" style="position:sticky;bottom:0;background:var(--panel);">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('jobDetailModal')">Close</button>
      <button class="btn btn-primary btn-sm" id="applyFromDetail" onclick="closeModal('jobDetailModal'); openProposalModal(window.currentJob.id, window.currentJob.title, window.currentJob.budget)">
        <i class="fa-solid fa-paper-plane"></i> Apply Now
      </button>
    </div>
  </div>
</div>

<!-- ════════════ PROPOSAL MODAL ════════════ -->
<div class="modal-backdrop hidden" id="proposalModal">
  <div class="modal" style="max-width:520px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-paper-plane text-accent"></i> &nbsp;Submit Proposal</span>
      <button class="icon-btn" onclick="closeModal('proposalModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="proposalJobId">
      <div style="background:var(--bg3);border-radius:8px;padding:12px 16px;margin-bottom:18px;">
        <div class="text-muted text-sm">Applying for:</div>
        <div class="font-bold text-sm mt-1" id="proposalJobTitle">—</div>
        <div class="text-accent font-bold" id="proposalJobBudget" style="font-size:13px;margin-top:2px;"></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Your Bid Amount ($)</label>
          <input type="number" class="form-control" id="bidAmount" placeholder="e.g. 1,500">
        </div>
        <div class="form-group">
          <label class="form-label">Delivery Time (days)</label>
          <input type="number" class="form-control" id="deliveryTime" placeholder="e.g. 14">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Cover Letter</label>
        <textarea class="form-control" id="coverLetter" rows="5" placeholder="Explain why you're the best fit. Mention relevant experience and how you'll approach this project…"></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Attach Portfolio / Sample Work (optional)</label>
        <input type="file" class="form-control" multiple>
      </div>
      <div style="background:rgba(0,229,192,.06);border:1px solid rgba(0,229,192,.15);border-radius:8px;padding:10px 14px;font-size:12px;color:var(--muted);">
        <i class="fa-solid fa-circle-info text-accent"></i> &nbsp;Your proposal will be tracked with version history (FR9). You can update it anytime before the client responds.
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('proposalModal')">Cancel</button>
     <button onclick="submitProposal()" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-paper-plane"></i> Submit Proposal
      </button>
    </div>
  </div>
</div>

<!-- DISPUTE MODAL -->
<div class="modal-backdrop hidden" id="disputeModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Open Dispute</span>
      <button class="icon-btn" onclick="closeModal('disputeModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Contract</label>
        <select class="form-control"><option>Contract #54 — React Job</option></select></div>
      <div class="form-group"><label class="form-label">Reason</label>
        <textarea class="form-control" placeholder="Describe the issue…"></textarea></div>
      <div class="form-group"><label class="form-label">Evidence</label>
        <input type="file" class="form-control" multiple></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('disputeModal')">Cancel</button>
      <button class="btn btn-danger btn-sm" onclick="closeModal('disputeModal');showToast('Dispute filed.','warn')">
        <i class="fa-solid fa-flag"></i> File Dispute
      </button>
    </div>
  </div>
</div>

<div id="toast-container"></div>
<script>
const jobsData = <?= json_encode($jobs) ?>;
</script>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/chat-sidebar.js"></script>
<script>

function openJobDetail(id) {
  const j = jobsData.find(job => job.id == id);
  if (!j) return;

  window.currentJob = j; // Store current job

  document.getElementById('jobDetailTitle').innerHTML = j.title;

  document.getElementById('jobDetailBody').innerHTML = `
    <p>${j.desc}</p>
    <div><strong>Budget:</strong> ${j.budget}</div>
    <div><strong>Client:</strong> ${j.client}</div>
  `;

  openModal('jobDetailModal');
}

function openProposalModal(id, title, budget) {
  console.log("Opening proposal modal for job ID:", id);
  window.currentJobId = id;
  const input = document.getElementById('proposalJobId');
  if (input) input.value = id;

  // Also store it on the submit button itself
  const submitBtn = document.querySelector('#proposalModal .btn-primary');
  if(submitBtn) submitBtn.setAttribute('data-job-id', id);

  document.getElementById('proposalJobTitle').textContent = title;
  document.getElementById('proposalJobBudget').textContent = 'Client budget: ' + budget;

  openModal('proposalModal');
}

function toggleSave(btn) {
  const icon = btn.querySelector('i');
  icon.classList.toggle('fa-regular');
  icon.classList.toggle('fa-solid');
  showToast(icon.classList.contains('fa-solid') ? 'Job saved!' : 'Job removed from saved.');
}


function submitProposal() {
  const input = document.getElementById('proposalJobId');
  const submitBtn = document.querySelector('#proposalModal .btn-primary');
  
  const jobId = (input && input.value) || 
                (submitBtn && submitBtn.getAttribute('data-job-id')) || 
                window.currentJobId;

  const bid = document.getElementById('bidAmount').value;
  const delivery = document.getElementById('deliveryTime').value;
  const letter = document.getElementById('coverLetter').value;

  console.log("Submitting proposal. Found Job ID:", jobId);

  if(!jobId || jobId === 'undefined' || jobId === 'null') {
    showToast("Error: Job ID is missing. Please refresh and try again.", "error");
    return;
  }

  if(!bid || !delivery || !letter) {
    showToast("Please fill all fields", "error");
    return;
  }

  fetch('../controllers/apply_job.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `job_id=${encodeURIComponent(jobId)}&bid=${encodeURIComponent(bid)}&delivery_time=${encodeURIComponent(delivery)}&cover_letter=${encodeURIComponent(letter)}`
  })
  .then(res => res.json())
  .then(data => {
    if(data.success) {
      showToast("Applied successfully 🔥");
      closeModal('proposalModal');
    } else {
      showToast(data.error || "Error submitting proposal", "error");
    }
  });
}
</script>
</body>
</html>