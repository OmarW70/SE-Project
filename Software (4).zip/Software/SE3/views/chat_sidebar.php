<?php
// chat_sidebar.php - Side chat sidebar for clients and freelancers
require_once '../models/Database.php';
require_once '../models/UserModel.php';
require_once '../models/DisputeModel.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$userModel = new UserModel();
$disputeModel = new DisputeModel();

// Get current user info
$currentUser = null;
if (isset($_SESSION['user_id'])) {
    $currentUser = $userModel->getUserById($_SESSION['user_id']);
}

// Get user's restricted channels if they exist
$restrictedChannels = [];
if ($currentUser) {
    // Get channels where user is a member
    $stmt = Database::getInstance()->prepare("
        SELECT rc.*, d.title as dispute_title, d.contract_id, 
               u1.first_name as client_first, u1.last_name as client_last,
               u2.first_name as freelancer_first, u2.last_name as freelancer_last
        FROM restricted_channels rc
        JOIN disputes d ON rc.dispute_id = d.dispute_id
        JOIN channel_members cm ON rc.channel_id = cm.channel_id
        JOIN users u1 ON d.client_id = u1.user_id
        JOIN users u2 ON d.freelancer_id = u2.user_id
        WHERE cm.user_id = ? AND rc.is_active = TRUE
        ORDER BY rc.created_at DESC
    ");
    $stmt->execute([$currentUser['user_id']]);
    $restrictedChannels = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$initials = $currentUser ? strtoupper(substr($currentUser['first_name'], 0, 1) . substr($currentUser['last_name'], 0, 1)) : '';
?>

<style>
/* Chat Sidebar Styles */
.chat-sidebar {
    position: fixed;
    right: 0;
    top: 0;
    height: 100vh;
    width: 300px;
    background: var(--bg2);
    border-left: 1px solid var(--border);
    transform: translateX(100%);
    transition: transform 0.3s ease;
    z-index: 1000;
    display: flex;
    flex-direction: column;
}

.chat-sidebar.open {
    transform: translateX(0);
}

.chat-sidebar-header {
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: var(--bg3);
}

.chat-sidebar-title {
    font-family: 'Syne', sans-serif;
    font-weight: 700;
    font-size: 15px;
    color: var(--text);
}

.chat-sidebar-close {
    width: 32px;
    height: 32px;
    border: none;
    background: var(--bg);
    border-radius: 8px;
    color: var(--muted);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
}

.chat-sidebar-close:hover {
    color: var(--text);
    background: var(--border);
}

.chat-sidebar-tabs {
    display: flex;
    border-bottom: 1px solid var(--border);
}

.chat-sidebar-tab {
    flex: 1;
    padding: 12px;
    text-align: center;
    font-size: 12px;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    color: var(--muted);
    cursor: pointer;
    transition: all 0.2s;
    border-bottom: 2px solid transparent;
}

.chat-sidebar-tab.active {
    color: var(--accent);
    border-bottom-color: var(--accent);
}

.chat-sidebar-tab:hover {
    color: var(--text);
}

.chat-sidebar-content {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
}

.chat-conversation-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    cursor: pointer;
    transition: all 0.2s;
    margin-bottom: 8px;
}

.chat-conversation-item:hover {
    background: var(--bg3);
}

.chat-conversation-item.active {
    background: var(--panel);
    border: 1px solid var(--accent);
}

.chat-conversation-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 700;
    font-family: 'Syne', sans-serif;
    flex-shrink: 0;
}

.chat-conversation-avatar.client {
    background: linear-gradient(135deg, var(--accent2), var(--accent));
    color: white;
}

.chat-conversation-avatar.freelancer {
    background: linear-gradient(135deg, #22c55e, var(--accent));
    color: var(--bg);
}

.chat-conversation-avatar.admin {
    background: linear-gradient(135deg, var(--danger), #f59e0b);
    color: white;
}

.chat-conversation-info {
    flex: 1;
    min-width: 0;
}

.chat-conversation-name {
    font-weight: 600;
    font-size: 13px;
    margin-bottom: 2px;
}

.chat-conversation-preview {
    font-size: 11px;
    color: var(--muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.chat-conversation-meta {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 4px;
}

.chat-conversation-time {
    font-size: 10px;
    color: var(--muted);
}

.chat-conversation-badge {
    background: var(--danger);
    color: white;
    font-size: 9px;
    padding: 2px 6px;
    border-radius: 10px;
    font-weight: 600;
}

.chat-popup {
    position: fixed;
    bottom: 20px;
    right: 320px;
    width: 350px;
    height: 450px;
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,.4);
    display: none;
    flex-direction: column;
    z-index: 1001;
}

.chat-popup.open {
    display: flex;
}

.chat-popup-header {
    padding: 12px 16px;
    border-bottom: 1px solid var(--border);
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--bg3);
    border-radius: 12px 12px 0 0;
}

.chat-popup-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: 700;
    font-family: 'Syne', sans-serif;
}

.chat-popup-name {
    flex: 1;
    font-weight: 600;
    font-size: 13px;
}

.chat-popup-close {
    width: 24px;
    height: 24px;
    border: none;
    background: none;
    color: var(--muted);
    cursor: pointer;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.chat-popup-close:hover {
    color: var(--text);
    background: var(--border);
}

.chat-popup-messages {
    flex: 1;
    overflow-y: auto;
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.chat-message {
    display: flex;
    gap: 8px;
    align-items: flex-start;
}

.chat-message.own {
    flex-direction: row-reverse;
}

.chat-message-avatar {
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 9px;
    font-weight: 700;
    font-family: 'Syne', sans-serif;
    flex-shrink: 0;
}

.chat-message-content {
    max-width: 70%;
}

.chat-message-bubble {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 8px 12px;
    font-size: 12px;
    line-height: 1.4;
}

.chat-message.own .chat-message-bubble {
    background: var(--accent);
    color: var(--bg);
    border-color: var(--accent);
}

.chat-message-time {
    font-size: 9px;
    color: var(--muted);
    margin-top: 2px;
    text-align: right;
}

.chat-popup-input {
    padding: 12px;
    border-top: 1px solid var(--border);
    display: flex;
    gap: 8px;
    align-items: flex-end;
}

.chat-popup-textarea {
    flex: 1;
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 8px;
    color: var(--text);
    padding: 8px 12px;
    font-size: 12px;
    font-family: 'DM Sans', sans-serif;
    resize: none;
    outline: none;
    max-height: 80px;
    transition: border-color .2s;
}

.chat-popup-textarea:focus {
    border-color: var(--accent);
}

.chat-popup-send {
    width: 32px;
    height: 32px;
    background: var(--accent);
    border: none;
    border-radius: 8px;
    color: var(--bg);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: filter .2s;
}

.chat-popup-send:hover {
    filter: brightness(1.1);
}

.chat-toggle-button {
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 56px;
    height: 56px;
    background: var(--accent);
    border: none;
    border-radius: 50%;
    color: var(--bg);
    font-size: 20px;
    cursor: pointer;
    box-shadow: 0 4px 20px rgba(0,229,192,.3);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s;
    z-index: 999;
}

.chat-toggle-button:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 24px rgba(0,229,192,.4);
}

.chat-toggle-button.unread::after {
    content: '';
    position: absolute;
    top: 8px;
    right: 8px;
    width: 8px;
    height: 8px;
    background: var(--danger);
    border-radius: 50%;
    border: 2px solid var(--bg);
}

/* Responsive */
@media (max-width: 768px) {
    .chat-sidebar {
        width: 100%;
    }
    
    .chat-popup {
        right: 20px;
        width: calc(100vw - 40px);
        max-width: 400px;
    }
}
</style>

<!-- Chat Toggle Button -->
<button class="chat-toggle-button" id="chatToggleBtn" onclick="toggleChatSidebar()">
    <i class="fa-solid fa-message"></i>
</button>

<!-- Chat Sidebar -->
<div class="chat-sidebar" id="chatSidebar">
    <div class="chat-sidebar-header">
        <div class="chat-sidebar-title">Messages</div>
        <button class="chat-sidebar-close" onclick="toggleChatSidebar()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    
    <div class="chat-sidebar-tabs">
        <div class="chat-sidebar-tab active" onclick="switchChatTab('all')">All</div>
        <div class="chat-sidebar-tab" onclick="switchChatTab('restricted')">Disputes</div>
    </div>
    
    <div class="chat-sidebar-content" id="chatSidebarContent">
        <!-- Conversations will be loaded here -->
    </div>
</div>

<!-- Chat Popup -->
<div class="chat-popup" id="chatPopup">
    <div class="chat-popup-header">
        <div class="chat-popup-avatar" id="chatPopupAvatar"></div>
        <div class="chat-popup-name" id="chatPopupName"></div>
        <button class="chat-popup-close" onclick="closeChatPopup()">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    
    <div class="chat-popup-messages" id="chatPopupMessages">
        <!-- Messages will be loaded here -->
    </div>
    
    <div class="chat-popup-input">
        <textarea class="chat-popup-textarea" id="chatPopupTextarea" 
                  placeholder="Type a message..." rows="1"
                  onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendChatMessage();}"></textarea>
        <button class="chat-popup-send" onclick="sendChatMessage()">
            <i class="fa-solid fa-paper-plane"></i>
        </button>
    </div>
</div>

<script>
let currentChatChannel = null;
let currentChatUser = null;
let chatSidebarOpen = false;

// Toggle chat sidebar
function toggleChatSidebar() {
    const sidebar = document.getElementById('chatSidebar');
    chatSidebarOpen = !chatSidebarOpen;
    sidebar.classList.toggle('open', chatSidebarOpen);
    
    if (chatSidebarOpen) {
        loadChatConversations();
    }
}

// Switch chat tab
function switchChatTab(tab) {
    document.querySelectorAll('.chat-sidebar-tab').forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    loadChatConversations(tab);
}

// Load chat conversations
function loadChatConversations(tab = 'all') {
    const content = document.getElementById('chatSidebarContent');
    content.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">Loading...</div>';
    
    // Simulate loading conversations
    setTimeout(() => {
        let conversations = [];
        
        if (tab === 'restricted') {
            // Load restricted channels (disputes)
            <?php if (!empty($restrictedChannels)): ?>
                <?php foreach ($restrictedChannels as $channel): ?>
                    conversations.push({
                        id: 'channel-<?= $channel["channel_id"] ?>',
                        name: '<?= htmlspecialchars($channel["dispute_title"]) ?>',
                        preview: 'Dispute for contract <?= htmlspecialchars($channel["contract_id"]) ?>',
                        time: '2h ago',
                        type: 'restricted',
                        otherParty: '<?= $currentUser["role_id"] == 1 ? htmlspecialchars($channel["freelancer_first"] . " " . $channel["freelancer_last"]) : htmlspecialchars($channel["client_first"] . " " . $channel["client_last"]) ?>',
                        otherRole: '<?= $currentUser["role_id"] == 1 ? "freelancer" : "client" ?>'
                    });
                <?php endforeach; ?>
            <?php else: ?>
                content.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">No dispute channels</div>';
                return;
            <?php endif; ?>
        } else {
            // Load all conversations (regular messages + restricted)
            <?php if (!empty($restrictedChannels)): ?>
                <?php foreach ($restrictedChannels as $channel): ?>
                    conversations.push({
                        id: 'channel-<?= $channel["channel_id"] ?>',
                        name: '<?= htmlspecialchars($channel["dispute_title"]) ?>',
                        preview: 'Dispute for contract <?= htmlspecialchars($channel["contract_id"]) ?>',
                        time: '2h ago',
                        type: 'restricted',
                        otherParty: '<?= $currentUser["role_id"] == 1 ? htmlspecialchars($channel["freelancer_first"] . " " . $channel["freelancer_last"]) : htmlspecialchars($channel["client_first"] . " " . $channel["client_last"]) ?>',
                        otherRole: '<?= $currentUser["role_id"] == 1 ? "freelancer" : "client" ?>'
                    });
                <?php endforeach; ?>
            <?php endif; ?>
            
            // Add some dummy regular conversations for demo
            conversations.push(
                {
                    id: 'conv-1',
                    name: 'Support Team',
                    preview: 'Welcome to FreeLynk! How can we help?',
                    time: '1d ago',
                    type: 'support',
                    otherParty: 'Support',
                    otherRole: 'support'
                }
            );
        }
        
        renderConversations(conversations);
    }, 500);
}

// Render conversations
function renderConversations(conversations) {
    const content = document.getElementById('chatSidebarContent');
    
    if (conversations.length === 0) {
        content.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">No conversations</div>';
        return;
    }
    
    content.innerHTML = conversations.map(conv => `
        <div class="chat-conversation-item" onclick="openChatPopup('${conv.id}', '${conv.otherParty}', '${conv.otherRole}', '${conv.type}')">
            <div class="chat-conversation-avatar ${conv.otherRole}">
                ${conv.otherParty.split(' ').map(n => n[0]).join('')}
            </div>
            <div class="chat-conversation-info">
                <div class="chat-conversation-name">${conv.name}</div>
                <div class="chat-conversation-preview">${conv.preview}</div>
            </div>
            <div class="chat-conversation-meta">
                <div class="chat-conversation-time">${conv.time}</div>
                ${conv.type === 'restricted' ? '<div class="chat-conversation-badge">⚠</div>' : ''}
            </div>
        </div>
    `).join('');
}

// Open chat popup
function openChatPopup(channelId, otherParty, otherRole, type) {
    currentChatChannel = channelId;
    currentChatUser = { name: otherParty, role: otherRole };
    
    const popup = document.getElementById('chatPopup');
    const avatar = document.getElementById('chatPopupAvatar');
    const name = document.getElementById('chatPopupName');
    
    avatar.className = `chat-popup-avatar ${otherRole}`;
    avatar.textContent = otherParty.split(' ').map(n => n[0]).join('');
    name.textContent = otherParty;
    
    popup.classList.add('open');
    
    loadChatMessages(channelId);
}

// Close chat popup
function closeChatPopup() {
    document.getElementById('chatPopup').classList.remove('open');
    currentChatChannel = null;
    currentChatUser = null;
}

// Load chat messages
function loadChatMessages(channelId) {
    const messagesContainer = document.getElementById('chatPopupMessages');
    messagesContainer.innerHTML = '<div style="text-align: center; padding: 20px; color: var(--muted);">Loading messages...</div>';
    
    // Simulate loading messages
    setTimeout(() => {
        let messages = [];
        
        if (channelId.startsWith('channel-')) {
            // Load restricted channel messages
            messages = [
                {
                    text: "This is a restricted dispute channel. All messages are monitored by admin.",
                    time: "2h ago",
                    isOwn: false,
                    sender: "System"
                },
                {
                    text: "Hello, I wanted to discuss the contract details.",
                    time: "1h ago",
                    isOwn: true,
                    sender: "Me"
                },
                {
                    text: "Sure, what would you like to clarify?",
                    time: "45m ago",
                    isOwn: false,
                    sender: currentChatUser.name
                }
            ];
        } else {
            // Regular conversation messages
            messages = [
                {
                    text: "Hello! How can I help you today?",
                    time: "1d ago",
                    isOwn: false,
                    sender: currentChatUser.name
                }
            ];
        }
        
        renderMessages(messages);
    }, 500);
}

// Render messages
function renderMessages(messages) {
    const container = document.getElementById('chatPopupMessages');
    
    container.innerHTML = messages.map(msg => `
        <div class="chat-message ${msg.isOwn ? 'own' : ''}">
            <div class="chat-message-avatar ${msg.isOwn ? 'own' : currentChatUser.role}">
                ${msg.sender.split(' ').map(n => n[0]).join('')}
            </div>
            <div class="chat-message-content">
                <div class="chat-message-bubble">${msg.text}</div>
                <div class="chat-message-time">${msg.time}</div>
            </div>
        </div>
    `).join('');
    
    container.scrollTop = container.scrollHeight;
}

// Send chat message
function sendChatMessage() {
    const textarea = document.getElementById('chatPopupTextarea');
    const text = textarea.value.trim();
    
    if (!text || !currentChatChannel) return;
    
    // Add message to UI
    const container = document.getElementById('chatPopupMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message own';
    messageDiv.innerHTML = `
        <div class="chat-message-avatar own">${currentUser.name.split(' ').map(n => n[0]).join('')}</div>
        <div class="chat-message-content">
            <div class="chat-message-bubble">${text}</div>
            <div class="chat-message-time">Just now</div>
        </div>
    `;
    
    container.appendChild(messageDiv);
    container.scrollTop = container.scrollHeight;
    
    textarea.value = '';
    
    // Simulate sending to server
    setTimeout(() => {
        showToast('Message sent');
    }, 200);
}

// Show toast notification
function showToast(message, type = 'success') {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="fa-solid fa-${type === 'success' ? 'check' : 'info'}"></i>
        ${message}
    `;
    
    document.getElementById('toast-container').appendChild(toast);
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Add toast container if not exists
    if (!document.getElementById('toast-container')) {
        const container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
});
</script>