<?php
// admin_dashboard.php — Admin Control Panel
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Admin auth check
if (!isset($_SESSION['user_id']) || ($_SESSION['role_id'] ?? 0) != 3) {
    header("Location: index.php?mode=login");
    exit();
}

$userModel = new UserModel();
$user      = $userModel->getUserById($_SESSION['user_id']);
$deleteMessage = '';
$deleteStatus = '';
$addMessage = '';
$addStatus = '';

// معالجة إضافة مستخدم جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_user') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $password   = trim($_POST['password'] ?? '');
    $role_id    = intval($_POST['role_id'] ?? 1);

    // التحقق من البيانات
    if ($first_name === '' || $last_name === '' || $email === '' || $password === '') {
        $addMessage = 'All fields are required to create a new account.';
        $addStatus = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $addMessage = 'Please enter a valid email address.';
        $addStatus = 'error';
    } elseif (strlen($password) < 8) {
        $addMessage = 'Password must be at least 8 characters long.';
        $addStatus = 'error';
    } elseif ($userModel->getUserByEmail($email)) {
        $addMessage = 'This email is already registered. Choose a different email.';
        $addStatus = 'error';
    } else {
        $success = $userModel->register($first_name, $last_name, $email, $password, $role_id);
        if ($success) {
            $addMessage = 'New user (' . htmlspecialchars($email) . ') created successfully.';
            $addStatus = 'success';
        } else {
            $addMessage = 'Unable to create user. Please try again or check the database.';
            $addStatus = 'error';
        }
    }
}

// معالجة حذف مستخدم
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_user') {
    $email        = trim($_POST['email'] ?? '');
    $confirmEmail = trim($_POST['confirm_email'] ?? '');
    $reason       = trim($_POST['reason'] ?? '');

    if ($email === '' || $confirmEmail === '') {
        $deleteMessage = 'Please enter and confirm the email address of the user to delete.';
        $deleteStatus = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !filter_var($confirmEmail, FILTER_VALIDATE_EMAIL)) {
        $deleteMessage = 'Please provide a valid email address.';
        $deleteStatus = 'error';
    } elseif ($email !== $confirmEmail) {
        $deleteMessage = 'The email addresses do not match. Please retype the email to confirm.';
        $deleteStatus = 'error';
    } elseif ($reason === '') {
        $deleteMessage = 'Please provide a reason for the account removal.';
        $deleteStatus = 'error';
    } elseif ($email === ($user['email'] ?? '')) {
        $deleteMessage = 'You cannot delete your own admin account from this panel.';
        $deleteStatus = 'error';
    } else {
        if ($userModel->removeUserByEmail($email)) {
            $deleteMessage = 'User account removed successfully from the database.';
            $deleteStatus = 'success';
        } else {
            $deleteMessage = 'Could not delete the user. The email was not found or there was a database issue.';
            $deleteStatus = 'error';
        }
    }
}

if (!$user) { session_destroy(); header("Location: index.php?mode=login"); exit(); }

$firstName = htmlspecialchars($user['first_name']);
$lastName  = htmlspecialchars($user['last_name']);
$initials  = strtoupper(substr($firstName,0,1).substr($lastName,0,1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Admin Panel</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <style>
    /* ═══════════════════════════════════════════
       CSS VARIABLES (with fallbacks)
       ═══════════════════════════════════════════ */
    :root {
      --bg: #0d0f14;
      --bg2: #151922;
      --bg3: #1e2230;
      --panel: #1a1e2e;
      --border: #2a2f40;
      --accent: #00e5c0;
      --accent2: #6c63ff;
      --danger: #ef4444;
      --warn: #f59e0b;
      --success: #22c55e;
      --muted: #8b92a8;
      --text: #e2e4ea;
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; }

    /* ══ Helper Classes ══ */
    .badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 10px; border-radius: 6px;
      font-size: 11px; font-weight: 700; font-family: 'Syne', sans-serif;
      border: 1px solid transparent;
    }
    .badge-info    { background: rgba(0,229,192,.12); color: var(--accent); border-color: rgba(0,229,192,.25); }
    .badge-purple  { background: rgba(108,99,255,.12); color: var(--accent2); border-color: rgba(108,99,255,.25); }
    .badge-warn    { background: rgba(245,158,11,.12); color: var(--warn); border-color: rgba(245,158,11,.25); }
    .badge-danger  { background: rgba(239,68,68,.12); color: var(--danger); border-color: rgba(239,68,68,.25); }
    .badge-success { background: rgba(34,197,94,.12); color: var(--success); border-color: rgba(34,197,94,.25); }
    .badge-muted   { background: rgba(139,146,168,.12); color: var(--muted); border-color: rgba(139,146,168,.25); }

    .server-alert {
      padding: 14px 18px;
      border-radius: 12px;
      margin-bottom: 18px;
      font-weight: 600;
      border: 1px solid transparent;
    }
    .server-alert.success { background: rgba(34,197,94,.12); color: var(--success); border-color: rgba(34,197,94,.25); }
    .server-alert.error   { background: rgba(239,68,68,.12); color: var(--danger); border-color: rgba(239,68,68,.25); }

    .btn {
      display: inline-flex; align-items: center; gap: 7px;
      padding: 9px 18px; border-radius: 10px;
      font-size: 13px; font-family: 'Syne', sans-serif;
      font-weight: 700; cursor: pointer; border: none;
      transition: filter .2s, transform .1s;
    }
    .btn:hover { filter: brightness(1.15); }
    .btn:active { transform: scale(0.97); }
    .btn-primary   { background: var(--accent); color: var(--bg); }
    .btn-secondary { background: var(--bg3); color: var(--text); border: 1px solid var(--border); }
    .btn-danger    { background: var(--danger); color: #fff; }
    .btn-sm { padding: 7px 14px; font-size: 12px; border-radius: 8px; }

    .icon-btn {
      width: 32px; height: 32px;
      display: flex; align-items: center; justify-content: center;
      border-radius: 8px; cursor: pointer;
      color: var(--muted); background: var(--bg3);
      border: 1px solid var(--border);
      transition: .2s;
    }
    .icon-btn:hover { color: var(--text); border-color: var(--accent); }

    .card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 20px;
    }

    /* Toast */
    #toast-container {
      position: fixed; bottom: 24px; right: 24px;
      z-index: 500;
      display: flex; flex-direction: column; gap: 10px;
    }
    .toast {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 14px 20px;
      font-size: 13px;
      font-weight: 600;
      box-shadow: 0 8px 32px rgba(0,0,0,.4);
      display: flex; align-items: center; gap: 10px;
      animation: toastIn .3s ease;
      max-width: 360px;
    }
    .toast.toast-success { border-left: 3px solid var(--success); }
    .toast.toast-warn    { border-left: 3px solid var(--warn); }
    .toast.toast-error   { border-left: 3px solid var(--danger); }
    @keyframes toastIn {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    /* ══ Admin Page Layout (no sidebar) ══ */
    body { background: var(--bg); }
    .admin-wrapper { display: flex; flex-direction: column; min-height: 100vh; }

    /* ── Top Navigation Bar ── */
    .admin-topbar {
      position: sticky; top: 0; z-index: 80;
      background: var(--bg2);
      border-bottom: 1px solid var(--border);
      padding: 0 32px;
      height: 60px;
      display: flex;
      align-items: center;
      gap: 20px;
    }
    .admin-brand {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 20px;
      color: var(--accent);
      margin-right: auto;
    }
    .admin-brand span { color: var(--text); }
    .admin-brand small {
      font-size: 11px;
      background: rgba(239,68,68,.15);
      color: var(--danger);
      border: 1px solid rgba(239,68,68,.3);
      padding: 2px 8px;
      border-radius: 20px;
      margin-left: 8px;
      font-family: 'DM Sans', sans-serif;
      font-weight: 600;
      letter-spacing: .3px;
      vertical-align: middle;
    }

    /* Tab nav */
    .admin-tabs {
      display: flex;
      gap: 4px;
    }
    .admin-tab {
      padding: 6px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      color: var(--muted);
      cursor: pointer;
      transition: .2s;
      border: 1px solid transparent;
    }
    .admin-tab:hover { color: var(--text); background: var(--bg3); }
    .admin-tab.active {
      color: var(--accent);
      background: rgba(0,229,192,.08);
      border-color: rgba(0,229,192,.2);
    }

    /* top-right buttons */
    .admin-topbar-right { display: flex; align-items: center; gap: 10px; }
    .topbar-action-btn {
      display: flex; align-items: center; gap: 7px;
      padding: 7px 16px;
      border-radius: 9px;
      font-size: 12px;
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      cursor: pointer;
      border: none;
      transition: .2s;
    }
    .btn-add-user  { background: var(--accent);  color: var(--bg); }
    .btn-add-user:hover  { filter: brightness(1.1); }
    .btn-rem-user  { background: rgba(239,68,68,.12); color: var(--danger); border: 1px solid rgba(239,68,68,.3); }
    .btn-rem-user:hover  { background: rgba(239,68,68,.2); }



    /* admin avatar pill */
    .admin-pill {
      display: flex; align-items: center; gap: 8px;
      padding: 5px 12px 5px 5px;
      background: var(--bg3);
      border: 1px solid var(--border);
      border-radius: 40px;
      font-size: 12px;
      font-weight: 600;
    }
    .admin-pill .av {
      width: 28px; height: 28px; border-radius: 50%;
      background: linear-gradient(135deg, var(--danger), var(--accent2));
      display: flex; align-items: center; justify-content: center;
      font-size: 11px; font-weight: 700; font-family: 'Syne', sans-serif;
    }

    /* ── Main Content ── */
    .admin-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 28px 32px;
      width: 100%;
    }

    /* Section heading */
    .section-head {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 13px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .6px;
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .section-head::after {
      content: '';
      flex: 1;
      height: 1px;
      background: var(--border);
    }

    /* Stats row */
    .stats-row {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 14px;
      margin-bottom: 28px;
    }
    .s-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 16px 18px;
      position: relative;
      overflow: hidden;
    }
    .s-card::before {
      content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
    }
    .s-card.c-teal::before  { background: var(--accent); }
    .s-card.c-purple::before{ background: var(--accent2); }
    .s-card.c-warn::before  { background: var(--warn); }
    .s-card.c-danger::before{ background: var(--danger); }
    .s-label { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: .5px; margin-bottom: 6px; }
    .s-val   { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 26px; }
    .s-card.c-teal .s-val  { color: var(--accent); }
    .s-card.c-purple .s-val{ color: var(--accent2); }
    .s-card.c-warn .s-val  { color: var(--warn); }
    .s-card.c-danger .s-val{ color: var(--danger); }

    /* Tab pages */
    .tab-page { display: none; }
    .tab-page.active { display: block; }

    /* ── Restricted Channels Section ── */
    .channels-grid {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    /* Channel card */
    .channel-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-left: 3px solid var(--danger);
      border-radius: 12px;
      overflow: hidden;
      transition: box-shadow .2s;
    }
    .channel-card:hover { box-shadow: 0 0 0 1px rgba(239,68,68,.3); }

    .channel-head {
      padding: 14px 18px;
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      user-select: none;
    }
    .channel-lock-icon {
      width: 32px; height: 32px;
      background: rgba(239,68,68,.1);
      border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      color: var(--danger);
      font-size: 13px;
      flex-shrink: 0;
    }
    .channel-info { flex: 1; min-width: 0; }
    .channel-title {
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: 14px;
      margin-bottom: 3px;
    }
    .channel-meta { font-size: 12px; color: var(--muted); }
    .channel-actions { display: flex; align-items: center; gap: 8px; }
    .ch-toggle {
      width: 30px; height: 30px;
      border-radius: 7px;
      background: var(--bg3);
      border: 1px solid var(--border);
      display: flex; align-items: center; justify-content: center;
      color: var(--muted);
      font-size: 12px;
      cursor: pointer;
      transition: .2s;
    }
    .ch-toggle:hover { color: var(--text); border-color: var(--accent); }

    /* Parties chips */
    .parties-row {
      padding: 0 18px 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .parties-label { font-size: 11px; color: var(--muted); }
    .party-chip {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 5px 10px;
      background: var(--bg3);
      border: 1px solid var(--border);
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: .2s;
    }
    .party-chip:hover { border-color: var(--danger); color: var(--danger); }
    .party-chip .av-xs {
      width: 20px; height: 20px; border-radius: 50%;
      font-size: 9px; font-weight: 700; font-family: 'Syne', sans-serif;
      display: flex; align-items: center; justify-content: center;
    }
    .party-chip.is-client .av-xs   { background: linear-gradient(135deg,var(--accent2),var(--accent)); }
    .party-chip.is-freelancer .av-xs { background: linear-gradient(135deg,#22c55e,var(--accent)); }

    /* Chat pane inside channel */
    .channel-chat {
      display: none;
      border-top: 1px solid var(--border);
    }
    .channel-chat.open { display: flex; flex-direction: column; }

    /* Restricted banner inside chat */
    .ch-restricted-bar {
      background: rgba(239,68,68,.06);
      border-bottom: 1px solid rgba(239,68,68,.15);
      padding: 8px 18px;
      font-size: 11px;
      color: var(--danger);
      display: flex; align-items: center; gap: 8px;
    }

    /* Admin identity bar */
    .admin-identity-bar {
      background: rgba(245,158,11,.05);
      border-bottom: 1px solid rgba(245,158,11,.15);
      padding: 8px 18px;
      font-size: 11px;
      color: var(--warn);
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
    }
    .admin-identity-chips { display: flex; gap: 8px; }
    .admin-chip {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 4px 10px;
      background: rgba(245,158,11,.08);
      border: 1px solid rgba(245,158,11,.2);
      border-radius: 6px;
      font-size: 11px;
      cursor: pointer;
      color: var(--warn);
      transition: .2s;
    }
    .admin-chip:hover { background: rgba(239,68,68,.12); border-color: rgba(239,68,68,.3); color: var(--danger); }

    /* Chat messages area */
    .ch-messages {
      max-height: 260px;
      overflow-y: auto;
      padding: 16px 18px;
      display: flex;
      flex-direction: column;
      gap: 12px;
      background: var(--bg);
    }
    .ch-msg { display: flex; gap: 10px; align-items: flex-start; }
    .ch-msg .av-sm {
      width: 28px; height: 28px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 10px; font-weight: 700; font-family: 'Syne', sans-serif;
      flex-shrink: 0;
    }
    .ch-msg-body { flex: 1; }
    .ch-msg-who  { font-size: 10px; font-weight: 700; margin-bottom: 3px; }
    .ch-msg-who.client { color: var(--accent); }
    .ch-msg-who.freelancer { color: #22c55e; }
    .ch-msg-who.admin { color: var(--warn); }
    .ch-msg-bubble {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 8px 12px;
      font-size: 12.5px;
      line-height: 1.5;
      display: inline-block;
      max-width: 85%;
    }
    .ch-msg-time { font-size: 10px; color: var(--muted); margin-top: 3px; }

    /* Admin send area */
    .ch-admin-input {
      border-top: 1px solid var(--border);
      padding: 12px 18px;
      background: var(--bg2);
      display: flex;
      gap: 8px;
      align-items: flex-end;
    }
    .ch-admin-textarea {
      flex: 1;
      background: var(--bg3);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text);
      padding: 8px 12px;
      font-size: 13px;
      font-family: 'DM Sans', sans-serif;
      resize: none;
      outline: none;
      max-height: 80px;
      transition: border-color .2s;
    }
    .ch-admin-textarea:focus { border-color: var(--warn); }
    .ch-send-btn {
      width: 34px; height: 34px;
      background: var(--warn);
      border: none;
      border-radius: 8px;
      color: var(--bg);
      font-size: 13px;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: filter .2s;
      flex-shrink: 0;
    }
    .ch-send-btn:hover { filter: brightness(1.1); }

    /* ── Penalty Dropdown ── */
    .penalty-dropdown {
      position: fixed; z-index: 300;
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 12px;
      width: 280px;
      box-shadow: 0 12px 40px rgba(0,0,0,.5);
      overflow: hidden;
      display: none;
    }
    .penalty-dropdown.open { display: block; }
    .pd-header {
      padding: 12px 14px;
      background: rgba(239,68,68,.08);
      border-bottom: 1px solid rgba(239,68,68,.2);
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: 13px;
      color: var(--danger);
    }
    .pd-target {
      padding: 8px 14px 0;
      font-size: 12px;
      color: var(--muted);
    }
    .pd-target strong { color: var(--text); }
    .pd-opts { padding: 8px 10px 10px; display: flex; flex-direction: column; gap: 4px; }
    .pd-opt {
      display: flex; align-items: center; gap: 10px;
      padding: 9px 12px;
      border-radius: 8px;
      border: 1px solid var(--border);
      cursor: pointer;
      transition: .2s;
    }
    .pd-opt:hover { border-color: var(--danger); background: rgba(239,68,68,.06); }
    .pd-opt.selected { border-color: var(--danger); background: rgba(239,68,68,.1); }
    .pd-icon {
      width: 26px; height: 26px;
      border-radius: 6px;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px;
      flex-shrink: 0;
    }
    .pd-opt-info { flex: 1; }
    .pd-opt-name { font-size: 12px; font-weight: 700; }
    .pd-opt-desc { font-size: 10px; color: var(--muted); }
    .pd-footer { padding: 0 10px 10px; }
    .pd-reason {
      width: 100%;
      background: var(--bg3);
      border: 1px solid var(--border);
      color: var(--text);
      border-radius: 8px;
      padding: 7px 10px;
      font-size: 12px;
      font-family: 'DM Sans', sans-serif;
      outline: none;
      margin-bottom: 8px;
      display: none;
    }
    .pd-reason.show { display: block; }
    .pd-apply {
      width: 100%;
      padding: 8px;
      background: var(--danger);
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      font-family: 'Syne', sans-serif;
      cursor: pointer;
      transition: filter .2s;
    }
    .pd-apply:hover { filter: brightness(1.1); }

    /* ── User Management popups ── */

    /* ── User Management popups ── */
    .popup-overlay {
      display: none;
      position: fixed; inset: 0; z-index: 400;
      background: rgba(0,0,0,.55);
      align-items: center; justify-content: center;
    }
    .popup-overlay.open { display: flex; }
    .popup-box {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      width: 420px;
      max-width: 95vw;
      overflow: hidden;
    }
    .popup-head {
      padding: 18px 22px;
      border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between;
    }
    .popup-title {
      font-family: 'Syne', sans-serif;
      font-weight: 800; font-size: 16px;
    }
    .popup-body { padding: 22px; }
    .popup-foot {
      padding: 14px 22px;
      border-top: 1px solid var(--border);
      display: flex; gap: 10px; justify-content: flex-end;
    }
    .form-lbl { display: block; font-size: 12px; color: var(--muted); margin-bottom: 5px; }
    .form-ctrl {
      width: 100%; background: var(--bg3); border: 1px solid var(--border);
      color: var(--text); padding: 9px 13px; border-radius: 9px;
      font-size: 13px; font-family: 'DM Sans', sans-serif; outline: none; transition: border-color .2s;
    }
    .form-ctrl:focus { border-color: var(--accent); }
    .form-group-mg { margin-bottom: 14px; }
    .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .role-pills { display: flex; gap: 8px; flex-wrap: wrap; }
    .role-pill {
      padding: 6px 14px; border-radius: 20px;
      border: 1px solid var(--border);
      font-size: 12px; font-family: 'Syne', sans-serif; font-weight: 700;
      cursor: pointer; color: var(--muted); transition: .2s;
    }
    .role-pill.active-client     { border-color: var(--accent); color: var(--accent); background: rgba(0,229,192,.08); }
    .role-pill.active-freelancer { border-color: #22c55e; color: #22c55e; background: rgba(34,197,94,.08); }
    .role-pill.active-admin      { border-color: var(--danger); color: var(--danger); background: rgba(239,68,68,.08); }

    .warn-box {
      background: rgba(239,68,68,.07);
      border: 1px solid rgba(239,68,68,.2);
      border-radius: 9px;
      padding: 11px 14px;
      font-size: 12px;
      color: var(--danger);
      margin-bottom: 14px;
    }

    /* Penalty log table */
    .log-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .log-table th {
      text-align: left; padding: 10px 16px;
      background: var(--bg3); color: var(--muted);
      font-size: 11px; text-transform: uppercase; letter-spacing: .4px;
      font-family: 'Syne', sans-serif;
    }
    .log-table th:first-child { border-radius: 8px 0 0 8px; }
    .log-table th:last-child  { border-radius: 0 8px 8px 0; }
    .log-table td {
      padding: 12px 16px;
      border-bottom: 1px solid var(--border);
      vertical-align: middle;
    }
    .log-table tr:last-child td { border-bottom: none; }
    .log-table tr:hover td { background: rgba(255,255,255,.02); }

    /* Responsive */
    @media(max-width: 768px) {
      .admin-topbar { padding: 0 16px; }
      .admin-content { padding: 20px 16px; }
      .stats-row { grid-template-columns: 1fr 1fr; }
      .admin-tabs { display: none; }
    }
  </style>
</head>
<body>
<div class="admin-wrapper">

  <!-- ══════════════════════════════
       TOP NAVIGATION BAR
  ══════════════════════════════ -->
  <div class="admin-topbar">

    <div class="admin-brand">
      Free<span>Lynk</span>
      <small>ADMIN</small>
    </div>

    <!-- Page Tabs -->
    <div class="admin-tabs">
      <div class="admin-tab active" onclick="switchTab(this,'channels')">
        <i class="fa-solid fa-lock" style="font-size:11px;"></i> Restricted Channels
        <span id="channelsBadge" style="background:rgba(239,68,68,.2);color:var(--danger);font-size:10px;padding:1px 6px;border-radius:10px;margin-left:4px;">3</span>
      </div>
    </div>

    <!-- Right Actions -->
    <div class="admin-topbar-right">
      <button class="topbar-action-btn btn-add-user" onclick="openPopup('addUserPopup')">
        <i class="fa-solid fa-user-plus"></i> Add User
      </button>
      <button class="topbar-action-btn btn-rem-user" onclick="openPopup('removeUserPopup')">
        <i class="fa-solid fa-user-minus"></i> Remove User
      </button>

      <div class="admin-pill">
        <div class="av"><?= $initials ?></div>
        <span><?= $firstName ?></span>
      </div>
      <div class="icon-btn" onclick="if(confirm('Sign out?')) window.location='index.php'" title="Sign Out">
        <i class="fa-solid fa-right-from-bracket"></i>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════
       MAIN CONTENT
  ══════════════════════════════ -->
  <div class="admin-content">

    <?php if (!empty($addMessage)): ?>
      <div class="server-alert <?= $addStatus === 'success' ? 'success' : 'error' ?>">
        <?= htmlspecialchars($addMessage, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($deleteMessage)): ?>
      <div class="server-alert <?= $deleteStatus === 'success' ? 'success' : 'error' ?>">
        <?= htmlspecialchars($deleteMessage, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>
      </div>
    <?php endif; ?>




    <!-- ────────────── CHANNELS TAB ────────────── -->
    <div class="tab-page" id="tab-channels">

      <div class="section-head">Active Dispute Channels</div>
      <div style="font-size:13px;color:var(--muted);margin-bottom:18px;">
        These are restricted channels visible only to involved parties and admins.
        Click a user chip to apply a penalty. You can send messages as admin directly inside each channel.
      </div>

      <div class="channels-grid" id="channelsGrid">

        <!-- ── Channel 1 ── -->
        <div class="channel-card" id="channel-1">
          <div class="channel-head" onclick="toggleChannelChat('channel-1')">
            <div class="channel-lock-icon"><i class="fa-solid fa-lock"></i></div>
            <div class="channel-info">
              <div class="channel-title">Contract #1042 — Logo Design</div>
              <div class="channel-meta">
                <i class="fa-solid fa-circle" style="color:var(--danger);font-size:8px;"></i>
                Dispute opened 2h ago &nbsp;·&nbsp; Awaiting admin review
              </div>
            </div>
            <div class="channel-actions">
              <span class="badge badge-danger">DISPUTE</span>
              <div class="ch-toggle" title="Toggle chat"><i class="fa-solid fa-chevron-down"></i></div>
            </div>
          </div>
          <div class="parties-row">
            <span class="parties-label"><i class="fa-solid fa-users" style="font-size:10px;"></i> Parties:</span>
            <span class="party-chip is-client"
              onclick="openPenaltyFor(event,'Omar Khalil','client','#1042')">
              <span class="av-xs">OK</span>
              Omar Khalil <span style="color:var(--muted);font-weight:400;">(Client)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
            <span class="party-chip is-freelancer"
              onclick="openPenaltyFor(event,'Sara Medhat','freelancer','#1042')">
              <span class="av-xs">SM</span>
              Sara Medhat <span style="color:var(--muted);font-weight:400;">(Freelancer)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
          </div>
          <div class="channel-chat" id="chat-channel-1">
            <div class="ch-restricted-bar">
              <i class="fa-solid fa-lock"></i>
              Restricted channel — all messages are logged and visible to admin only
            </div>
            <div class="admin-identity-bar">
              <span><i class="fa-solid fa-crown" style="font-size:10px;"></i> Admin view — click a name to apply penalty:</span>
              <div class="admin-identity-chips">
                <span class="admin-chip" onclick="openPenaltyFor(event,'Omar Khalil','client','#1042')">
                  Omar Khalil <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
                <span class="admin-chip" onclick="openPenaltyFor(event,'Sara Medhat','freelancer','#1042')">
                  Sara Medhat <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
              </div>
            </div>
            <div class="ch-messages" id="msgs-channel-1">
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,var(--accent2),var(--accent));color:#fff;">OK</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who client">Omar Khalil · Client</div>
                  <div class="ch-msg-bubble">The delivered logo doesn't match the agreed brief at all. The colors are completely wrong.</div>
                  <div class="ch-msg-time">2h ago</div>
                </div>
              </div>
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,#22c55e,var(--accent));color:#0d0f14;">SM</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who freelancer">Sara Medhat · Freelancer</div>
                  <div class="ch-msg-bubble">I followed all the requirements listed in the contract. The brief said "professional and clean" which I delivered.</div>
                  <div class="ch-msg-time">1h 45m ago</div>
                </div>
              </div>
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,var(--accent2),var(--accent));color:#fff;">OK</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who client">Omar Khalil · Client</div>
                  <div class="ch-msg-bubble">I specifically mentioned blue and white palette in the revision notes. Requesting full refund and escalating to admin.</div>
                  <div class="ch-msg-time">1h ago</div>
                </div>
              </div>
            </div>
            <div class="ch-admin-input">
              <div class="av-sm" style="background:linear-gradient(135deg,var(--danger),#f59e0b);color:#fff;flex-shrink:0;"><?= $initials ?></div>
              <textarea class="ch-admin-textarea" id="adminInput-channel-1" rows="1"
                placeholder="Type as admin… (visible to both parties)"
                onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();adminSend('channel-1')}"></textarea>
              <button class="ch-send-btn" onclick="adminSend('channel-1')">
                <i class="fa-solid fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div><!-- /channel-1 -->


        <!-- ── Channel 2 ── -->
        <div class="channel-card" id="channel-2">
          <div class="channel-head" onclick="toggleChannelChat('channel-2')">
            <div class="channel-lock-icon"><i class="fa-solid fa-lock"></i></div>
            <div class="channel-info">
              <div class="channel-title">Contract #0987 — Web Development</div>
              <div class="channel-meta">
                <i class="fa-solid fa-circle" style="color:var(--warn);font-size:8px;"></i>
                Opened 1 day ago &nbsp;·&nbsp; Warning penalty applied
              </div>
            </div>
            <div class="channel-actions">
              <span class="badge badge-warn">WARNING ISSUED</span>
              <div class="ch-toggle" title="Toggle chat"><i class="fa-solid fa-chevron-down"></i></div>
            </div>
          </div>
          <div class="parties-row">
            <span class="parties-label"><i class="fa-solid fa-users" style="font-size:10px;"></i> Parties:</span>
            <span class="party-chip is-client"
              onclick="openPenaltyFor(event,'Nada Saleh','client','#0987')">
              <span class="av-xs">NS</span>
              Nada Saleh <span style="color:var(--muted);font-weight:400;">(Client)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
            <span class="party-chip is-freelancer"
              onclick="openPenaltyFor(event,'Kareem Abdo','freelancer','#0987')">
              <span class="av-xs">KA</span>
              Kareem Abdo <span style="color:var(--muted);font-weight:400;">(Freelancer)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
          </div>
          <div class="channel-chat" id="chat-channel-2">
            <div class="ch-restricted-bar">
              <i class="fa-solid fa-lock"></i>
              Restricted channel — all messages are logged and visible to admin only
            </div>
            <div class="admin-identity-bar">
              <span><i class="fa-solid fa-crown" style="font-size:10px;"></i> Admin view — click a name to apply penalty:</span>
              <div class="admin-identity-chips">
                <span class="admin-chip" onclick="openPenaltyFor(event,'Nada Saleh','client','#0987')">
                  Nada Saleh <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
                <span class="admin-chip" onclick="openPenaltyFor(event,'Kareem Abdo','freelancer','#0987')">
                  Kareem Abdo <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
              </div>
            </div>
            <div class="ch-messages" id="msgs-channel-2">
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,var(--accent2),var(--accent));color:#fff;">NS</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who client">Nada Saleh · Client</div>
                  <div class="ch-msg-bubble">Deadline passed 3 days ago. No delivery. I need this project urgently.</div>
                  <div class="ch-msg-time">1d ago</div>
                </div>
              </div>
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,#22c55e,var(--accent));color:#0d0f14;">KA</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who freelancer">Kareem Abdo · Freelancer</div>
                  <div class="ch-msg-bubble">I had serious technical issues with my server. I will send the deliverables today for sure.</div>
                  <div class="ch-msg-time">23h ago</div>
                </div>
              </div>
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,var(--danger),#f59e0b);color:#fff;"><?= $initials ?></div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who admin">Admin · FreeLynk</div>
                  <div class="ch-msg-bubble">⚠ Formal warning issued to Kareem Abdo for missed deadline. Delivery must happen within 24 hours or further penalties will apply.</div>
                  <div class="ch-msg-time">20h ago</div>
                </div>
              </div>
            </div>
            <div class="ch-admin-input">
              <div class="av-sm" style="background:linear-gradient(135deg,var(--danger),#f59e0b);color:#fff;flex-shrink:0;"><?= $initials ?></div>
              <textarea class="ch-admin-textarea" id="adminInput-channel-2" rows="1"
                placeholder="Type as admin… (visible to both parties)"
                onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();adminSend('channel-2')}"></textarea>
              <button class="ch-send-btn" onclick="adminSend('channel-2')">
                <i class="fa-solid fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div><!-- /channel-2 -->


        <!-- ── Channel 3 ── -->
        <div class="channel-card" id="channel-3">
          <div class="channel-head" onclick="toggleChannelChat('channel-3')">
            <div class="channel-lock-icon"><i class="fa-solid fa-lock"></i></div>
            <div class="channel-info">
              <div class="channel-title">Contract #1105 — Social Media Campaign</div>
              <div class="channel-meta">
                <i class="fa-solid fa-circle" style="color:var(--danger);font-size:8px;"></i>
                Opened 3h ago &nbsp;·&nbsp; Evidence under review
              </div>
            </div>
            <div class="channel-actions">
              <span class="badge badge-danger">DISPUTE</span>
              <div class="ch-toggle" title="Toggle chat"><i class="fa-solid fa-chevron-down"></i></div>
            </div>
          </div>
          <div class="parties-row">
            <span class="parties-label"><i class="fa-solid fa-users" style="font-size:10px;"></i> Parties:</span>
            <span class="party-chip is-client"
              onclick="openPenaltyFor(event,'Tamer Nour','client','#1105')">
              <span class="av-xs">TN</span>
              Tamer Nour <span style="color:var(--muted);font-weight:400;">(Client)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
            <span class="party-chip is-freelancer"
              onclick="openPenaltyFor(event,'Rana Fathy','freelancer','#1105')">
              <span class="av-xs">RF</span>
              Rana Fathy <span style="color:var(--muted);font-weight:400;">(Freelancer)</span>
              <i class="fa-solid fa-chevron-down" style="font-size:9px;color:var(--muted);"></i>
            </span>
          </div>
          <div class="channel-chat" id="chat-channel-3">
            <div class="ch-restricted-bar">
              <i class="fa-solid fa-lock"></i>
              Restricted channel — all messages are logged and visible to admin only
            </div>
            <div class="admin-identity-bar">
              <span><i class="fa-solid fa-crown" style="font-size:10px;"></i> Admin view — click a name to apply penalty:</span>
              <div class="admin-identity-chips">
                <span class="admin-chip" onclick="openPenaltyFor(event,'Tamer Nour','client','#1105')">
                  Tamer Nour <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
                <span class="admin-chip" onclick="openPenaltyFor(event,'Rana Fathy','freelancer','#1105')">
                  Rana Fathy <i class="fa-solid fa-gavel" style="font-size:9px;"></i>
                </span>
              </div>
            </div>
            <div class="ch-messages" id="msgs-channel-3">
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,#22c55e,var(--accent));color:#0d0f14;">RF</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who freelancer">Rana Fathy · Freelancer</div>
                  <div class="ch-msg-bubble">I delivered all 10 posts, the client approved them, and the campaign ran successfully. Payment has not been released despite completion.</div>
                  <div class="ch-msg-time">3h ago</div>
                </div>
              </div>
              <div class="ch-msg">
                <div class="av-sm" style="background:linear-gradient(135deg,var(--accent2),var(--accent));color:#fff;">TN</div>
                <div class="ch-msg-body">
                  <div class="ch-msg-who client">Tamer Nour · Client</div>
                  <div class="ch-msg-bubble">The engagement results were below what was promised. This does not meet the quality standard agreed upon.</div>
                  <div class="ch-msg-time">2h ago</div>
                </div>
              </div>
            </div>
            <div class="ch-admin-input">
              <div class="av-sm" style="background:linear-gradient(135deg,var(--danger),#f59e0b);color:#fff;flex-shrink:0;"><?= $initials ?></div>
              <textarea class="ch-admin-textarea" id="adminInput-channel-3" rows="1"
                placeholder="Type as admin… (visible to both parties)"
                onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();adminSend('channel-3')}"></textarea>
              <button class="ch-send-btn" onclick="adminSend('channel-3')">
                <i class="fa-solid fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div><!-- /channel-3 -->

      </div><!-- /channels-grid -->
    </div><!-- /channels tab -->









  </div><!-- /admin-content -->
</div><!-- /admin-wrapper -->


<!-- ══════════════════════════════
     PENALTY DROPDOWN
══════════════════════════════ -->
<div class="penalty-dropdown" id="penaltyDropdown">
  <div class="pd-header">
    <i class="fa-solid fa-gavel"></i> Apply Penalty
  </div>
  <div class="pd-target">
    Applying to: <strong id="pdTargetName">—</strong>
    <span id="pdTargetBadge" style="margin-left:6px;"></span>
  </div>
  <div class="pd-opts">
    <div class="pd-opt" onclick="selectPenalty(this,'warning')">
      <div class="pd-icon" style="background:rgba(245,158,11,.15);color:var(--warn);">
        <i class="fa-solid fa-triangle-exclamation"></i>
      </div>
      <div class="pd-opt-info">
        <div class="pd-opt-name">Warning</div>
        <div class="pd-opt-desc">Formal notice, no access restriction</div>
      </div>
    </div>
    <div class="pd-opt" onclick="selectPenalty(this,'limited')">
      <div class="pd-icon" style="background:rgba(108,99,255,.15);color:var(--accent2);">
        <i class="fa-solid fa-ban"></i>
      </div>
      <div class="pd-opt-info">
        <div class="pd-opt-name">Limited Access</div>
        <div class="pd-opt-desc">Cannot create contracts or proposals</div>
      </div>
    </div>
    <div class="pd-opt" onclick="selectPenalty(this,'ban')">
      <div class="pd-icon" style="background:rgba(239,68,68,.15);color:var(--danger);">
        <i class="fa-solid fa-skull-crossbones"></i>
      </div>
      <div class="pd-opt-info">
        <div class="pd-opt-name">Permanent Ban</div>
        <div class="pd-opt-desc">Account permanently deactivated</div>
      </div>
    </div>
  </div>
  <div class="pd-footer">
    <input type="text" class="pd-reason" id="pdReason" placeholder="Reason shown to user…">
    <button class="pd-apply" onclick="applyPenalty()">
      <i class="fa-solid fa-gavel"></i> Apply & Notify User
    </button>
  </div>
</div>





<!-- ══════════════════════════════
     ADD USER POPUP
══════════════════════════════ -->
<div class="popup-overlay" id="addUserPopup" onclick="if(event.target===this)closePopup('addUserPopup')">
  <div class="popup-box">
    <div class="popup-head">
      <div class="popup-title" style="color:var(--accent);">
        <i class="fa-solid fa-user-plus"></i> Create Account
      </div>
      <div class="icon-btn" onclick="closePopup('addUserPopup')">
        <i class="fa-solid fa-xmark"></i>
      </div>
    </div>
    <form id="addUserForm" method="POST" action="admin_dashboard.php">
      <input type="hidden" name="action" value="add_user">
      <div class="popup-body">
        <div class="form-row-2 form-group-mg">
          <div>
            <label class="form-lbl">First Name</label>
            <input type="text" class="form-ctrl" placeholder="Ahmed" name="first_name" required>
          </div>
          <div>
            <label class="form-lbl">Last Name</label>
            <input type="text" class="form-ctrl" placeholder="Hassan" name="last_name" required>
          </div>
        </div>
        <div class="form-group-mg">
          <label class="form-lbl">Email Address</label>
          <input type="email" class="form-ctrl" placeholder="user@example.com" name="email" required>
        </div>
        <div class="form-group-mg">
          <label class="form-lbl">Password</label>
          <input type="password" class="form-ctrl" placeholder="Min. 8 characters" name="password" required>
        </div>
        <div class="form-group-mg">
          <label class="form-lbl" style="margin-bottom:8px;">Role</label>
          <div class="role-pills">
            <div class="role-pill active-client" data-role="1" onclick="selectAddUserRole(this)">
              <i class="fa-solid fa-briefcase"></i> Client
            </div>
            <div class="role-pill" data-role="2" onclick="selectAddUserRole(this)">
              <i class="fa-solid fa-laptop-code"></i> Freelancer
            </div>
            <div class="role-pill" data-role="3" onclick="selectAddUserRole(this)">
              <i class="fa-solid fa-user-shield"></i> Admin
            </div>
          </div>
          <input type="hidden" name="role_id" id="add-role-input" value="1">
        </div>
      </div>
      <div class="popup-foot">
        <button type="button" class="btn btn-secondary btn-sm" onclick="closePopup('addUserPopup')">Cancel</button>
        <button type="submit" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-user-plus"></i> Create Account
        </button>
      </div>
    </form>
  </div>
</div>


<!-- ══════════════════════════════
     REMOVE USER POPUP
══════════════════════════════ -->
<div class="popup-overlay" id="removeUserPopup" onclick="if(event.target===this)closePopup('removeUserPopup')">
  <div class="popup-box">
    <div class="popup-head">
      <div class="popup-title" style="color:var(--danger);">
        <i class="fa-solid fa-user-minus"></i> Remove Account
      </div>
      <div class="icon-btn" onclick="closePopup('removeUserPopup')">
        <i class="fa-solid fa-xmark"></i>
      </div>
    </div>
    <div class="popup-body">
      <form id="removeUserForm" method="post" action="admin_dashboard.php">
        <input type="hidden" name="action" value="delete_user">
        <div class="warn-box">
          <i class="fa-solid fa-triangle-exclamation"></i>
          This action is <strong>permanent and irreversible</strong>. All user data, contracts,
          messages, and history will be deleted. Proceed with extreme caution.
        </div>
        <div class="form-group-mg">
          <label class="form-lbl">Email Address of Account to Remove</label>
          <input type="email" class="form-ctrl" placeholder="user@example.com" id="rem-email" name="email">
        </div>
        <div class="form-group-mg">
          <label class="form-lbl">Confirm Email (retype to confirm)</label>
          <input type="email" class="form-ctrl" placeholder="Retype email to confirm" id="rem-email2" name="confirm_email">
        </div>
        <div class="form-group-mg">
          <label class="form-lbl">Reason for Removal</label>
          <input type="text" class="form-ctrl" placeholder="e.g. Fraudulent activity, Repeated violations" id="rem-reason" name="reason">
        </div>
      </form>
    </div>
    <div class="popup-foot">
      <button class="btn btn-secondary btn-sm" onclick="closePopup('removeUserPopup')">Cancel</button>
      <button class="btn btn-danger btn-sm" onclick="removeAccount()">
        <i class="fa-solid fa-trash"></i> Delete Account
      </button>
    </div>
  </div>
</div>


<div id="toast-container"></div>

<script src="../assets/js/main.js"></script>
<script>
/* ════════════════════════════════════════════════
   ADMIN DASHBOARD JS
════════════════════════════════════════════════ */

// ── State ──────────────────────────────────────
let selectedPenaltyType = '';
let penaltyTargetName   = '';
let penaltyTargetRole   = '';
let penaltyTargetContract = '';
const adminInitials = '<?= $initials ?>';

// ── Tab Switcher ───────────────────────────────
function switchTab(el, tabId) {
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.tab-page').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-' + tabId).classList.add('active');
}

// ── Channel Chat Toggle ────────────────────────
function toggleChannelChat(channelId) {
  const chat   = document.getElementById('chat-' + channelId);
  const toggle = document.querySelector('#' + channelId + ' .ch-toggle i');
  const isOpen = chat.classList.contains('open');
  chat.classList.toggle('open');
  if (toggle) {
    toggle.className = isOpen ? 'fa-solid fa-chevron-down' : 'fa-solid fa-chevron-up';
  }
}

// ── Admin Send Message ─────────────────────────
function adminSend(channelId) {
  const textarea = document.getElementById('adminInput-' + channelId);
  const text = textarea.value.trim();
  if (!text) return;

  const area = document.getElementById('msgs-' + channelId);
  const msg  = document.createElement('div');
  msg.className = 'ch-msg';
  msg.innerHTML = `
    <div class="av-sm" style="background:linear-gradient(135deg,var(--danger),#f59e0b);color:#fff;">${adminInitials}</div>
    <div class="ch-msg-body">
      <div class="ch-msg-who admin">Admin · FreeLynk</div>
      <div class="ch-msg-bubble">${escapeHtml(text)}</div>
      <div class="ch-msg-time">Just now</div>
    </div>`;
  area.appendChild(msg);
  area.scrollTop = area.scrollHeight;
  textarea.value = '';

  showToast('Message sent to both parties.');
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Penalty Dropdown ───────────────────────────
function openPenaltyFor(e, name, role, contract) {
  e.stopPropagation();
  selectedPenaltyType   = '';
  penaltyTargetName     = name;
  penaltyTargetRole     = role;
  penaltyTargetContract = contract;

  document.querySelectorAll('.pd-opt').forEach(o => o.classList.remove('selected'));
  document.getElementById('pdReason').classList.remove('show');
  document.getElementById('pdReason').value = '';
  document.getElementById('pdTargetName').textContent = name;

  const roleLbl = role === 'client' ? 'Client' : 'Freelancer';
  const roleClr = role === 'client' ? 'var(--accent)' : '#22c55e';
  document.getElementById('pdTargetBadge').innerHTML =
    `<span style="background:rgba(0,0,0,.15);color:${roleClr};font-size:10px;padding:2px 7px;border-radius:10px;border:1px solid ${roleClr}33;">${roleLbl}</span>`;

  const dd  = document.getElementById('penaltyDropdown');
  const btn = e.currentTarget;
  const r   = btn.getBoundingClientRect();
  dd.style.top  = (r.bottom + 6) + 'px';
  dd.style.left = Math.min(r.left, window.innerWidth - 290) + 'px';
  dd.classList.add('open');
}

function selectPenalty(el, type) {
  document.querySelectorAll('.pd-opt').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  selectedPenaltyType = type;
  document.getElementById('pdReason').classList.add('show');
}

function applyPenalty() {
  if (!selectedPenaltyType) { showToast('Select a penalty type.', 'warn'); return; }

  const labels = { warning: 'Warning', limited: 'Limited Access', ban: 'Permanent Ban' };
  const label  = labels[selectedPenaltyType];
  const reason = document.getElementById('pdReason').value.trim() || 'Platform policy violation';

  // Close dropdown
  document.getElementById('penaltyDropdown').classList.remove('open');

  // Add to penalty log
  addPenaltyRow(penaltyTargetName, penaltyTargetRole, label, penaltyTargetContract, reason);

  // Update stats
  if (selectedPenaltyType === 'ban') {
    const banEl = document.getElementById('stat-banned');
    if (banEl) banEl.textContent = parseInt(banEl.textContent.replace(/,/g,'')) + 1;
  }

  // Notification to admin log

  showToast(`${label} applied & notification sent to ${penaltyTargetName}.`, 'success');
  selectedPenaltyType = '';
}

function addPenaltyRow(name, role, penalty, contract, reason) {
  const tb  = document.getElementById('penaltyLog');
  const now = new Date().toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
  const penaltyBadge = penalty === 'Warning'
    ? '<span class="badge badge-warn"><i class="fa-solid fa-triangle-exclamation"></i> Warning</span>'
    : penalty === 'Limited Access'
    ? '<span class="badge badge-purple"><i class="fa-solid fa-ban"></i> Limited Access</span>'
    : '<span class="badge badge-danger"><i class="fa-solid fa-skull-crossbones"></i> Perm. Ban</span>';
  const roleBadge = role === 'client'
    ? '<span class="badge badge-info">Client</span>'
    : '<span class="badge badge-purple">Freelancer</span>';
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td style="font-weight:600;">${name}</td>
    <td>${roleBadge}</td>
    <td>${penaltyBadge}</td>
    <td style="color:var(--muted);font-size:12px;">${contract}</td>
    <td style="font-size:12px;color:var(--muted);">${reason}</td>
    <td style="font-size:12px;color:var(--muted);">${now}</td>
    <td><span style="font-size:11px;color:var(--success);"><i class="fa-solid fa-check"></i> Notified</span></td>`;
  tb.insertBefore(tr, tb.firstChild);

  // Also add to activity log
  const al = document.getElementById('activityLog');
  if (al) {
    const atr = document.createElement('tr');
    atr.innerHTML = `
      <td><span class="badge badge-danger"><i class="fa-solid fa-gavel"></i> ${penalty} Issued</span></td>
      <td>${name}</td>
      <td>${roleBadge}</td>
      <td style="color:var(--muted);font-size:12px;">Just now</td>
      <td><span style="font-size:11px;color:var(--success);">Notified ✓</span></td>`;
    al.insertBefore(atr, al.firstChild);
  }
}

// Close penalty dropdown on outside click
document.addEventListener('click', e => {
  const dd = document.getElementById('penaltyDropdown');
  if (!dd.contains(e.target)) dd.classList.remove('open');
});

// ── User Management ────────────────────────────

// ── User Management ────────────────────────────
function openPopup(id)  { document.getElementById(id).classList.add('open'); }
function closePopup(id) { document.getElementById(id).classList.remove('open'); }

function selectRole(el, roleClass) {
  document.querySelectorAll('.role-pill').forEach(p => {
    p.className = 'role-pill';
  });
  el.classList.add('active-' + roleClass);
  document.getElementById('add-role').value = el.dataset.role;
}

function selectAddUserRole(el) {
  document.querySelectorAll('.role-pill').forEach(p => {
    p.className = 'role-pill';
  });
  const roleId = el.dataset.role;
  const roleClass = roleId === '1' ? 'active-client' : roleId === '2' ? 'active-freelancer' : 'active-admin';
  el.classList.add(roleClass);
  document.getElementById('add-role-input').value = roleId;
}

function createAccount() {
  const fn    = document.getElementById('add-fn').value.trim();
  const ln    = document.getElementById('add-ln').value.trim();
  const email = document.getElementById('add-email').value.trim();
  const pass  = document.getElementById('add-pass').value;
  const roleId = document.getElementById('add-role').value;
  const roleNames = { '1':'Client', '2':'Freelancer', '3':'Admin' };

  if (!fn || !ln || !email || !pass) { showToast('Please fill in all fields.', 'warn'); return; }
  if (pass.length < 8) { showToast('Password must be at least 8 characters.', 'error'); return; }
  if (!email.includes('@')) { showToast('Invalid email address.', 'error'); return; }

  // Add to activity log
  const al = document.getElementById('activityLog');
  const roleBadge = roleId === '1' ? 'badge-info' : roleId === '2' ? 'badge-purple' : 'badge-danger';
  const atr = document.createElement('tr');
  atr.innerHTML = `
    <td><span class="badge badge-info"><i class="fa-solid fa-user-plus"></i> Account Created</span></td>
    <td>${fn} ${ln}</td>
    <td><span class="badge ${roleBadge}">${roleNames[roleId]}</span></td>
    <td style="color:var(--muted);font-size:12px;">Just now</td>
    <td><span style="font-size:11px;color:var(--success);">Active ✓</span></td>`;
  al.insertBefore(atr, al.firstChild);

  // Stats
  const totalEl = document.getElementById('stat-total');
  if (totalEl) totalEl.textContent = (parseInt(totalEl.textContent.replace(/,/g,'')) + 1).toLocaleString();
  if (roleId === '2') {
    const flEl = document.getElementById('stat-freelancers');
    if (flEl) flEl.textContent = (parseInt(flEl.textContent.replace(/,/g,'')) + 1).toLocaleString();
  }

  showToast(`Account created for ${fn} ${ln} as ${roleNames[roleId]}.`);
  closePopup('addUserPopup');

  // Reset form
  ['add-fn','add-ln','add-email','add-pass'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('add-role').value = '1';
  document.querySelectorAll('.role-pill').forEach(p => p.className = 'role-pill');
  document.querySelector('.role-pill[data-role="1"]').classList.add('active-client');
}

function removeAccount() {
  const email  = document.getElementById('rem-email').value.trim();
  const email2 = document.getElementById('rem-email2').value.trim();
  const reason = document.getElementById('rem-reason').value.trim();

  if (!email || !email2) { showToast('Please fill in both email fields.', 'warn'); return; }
  if (email !== email2)  { showToast('Emails do not match.', 'error'); return; }
  if (!reason) { showToast('Please provide a reason for removal.', 'warn'); return; }

  if (!confirm(`⚠ Permanently delete account:\n${email}\n\nReason: ${reason}\n\nThis cannot be undone!`)) return;

  document.getElementById('removeUserForm').submit();
}

// ── Init ───────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Auto-open first channel
  setTimeout(() => toggleChannelChat('channel-1'), 300);
});
</script>
</body>
</html>