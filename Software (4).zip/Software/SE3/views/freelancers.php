<?php
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';
$conn = mysqli_connect("localhost", "root", "", "freelance_platform");

if (!$conn) {
  die("Connection failed");
}
$query = "SELECT * FROM users WHERE role_id = 2";
$result = mysqli_query($conn, $query);

$freelancers = [];

while ($row = mysqli_fetch_assoc($result)) {
  $freelancers[] = $row;
}



if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php?mode=login");
    exit();
}

$userModel = new UserModel();
$user      = $userModel->getUserById($_SESSION['user_id']);

if (!$user) {
    session_destroy();
    header("Location: index.php?mode=login");
    exit();
}

$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name']  = $user['last_name'];
$_SESSION['email']      = $user['email'];

$firstName = htmlspecialchars($user['first_name']);
$lastName  = htmlspecialchars($user['last_name']);
$email     = htmlspecialchars($user['email']);
$fullName  = $firstName . ' ' . $lastName;
$initials  = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1));
$shortName = $firstName . '. ' . $lastName;
$edit_profile_success   = $_GET['edit_profile_success']   ?? '';
$edit_profile_error = $_GET['edit_profile_error'] ?? '';

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Browse Freelancers</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/chat-sidebar.css">
  <style>
    .fl-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 24px;
      transition: border-color .2s, transform .2s, box-shadow .2s;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .fl-card:hover {
      border-color: var(--accent);
      transform: translateY(-3px);
      box-shadow: 0 12px 32px rgba(0, 229, 192, .1);
    }

    .fl-card.top-rated::after {
      content: '⭐ Top Rated';
      position: absolute;
      top: 16px;
      right: 16px;
      font-size: 10px;
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      background: rgba(245, 158, 11, .15);
      color: var(--warn);
      border: 1px solid rgba(245, 158, 11, .3);
      border-radius: 20px;
      padding: 3px 10px;
    }

    .fl-avatar-wrap {
      position: relative;
      display: inline-block;
      margin-bottom: 14px;
    }

    .fl-avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 22px;
      color: var(--bg);
    }

    .fl-status-dot {
      position: absolute;
      bottom: 3px;
      right: 3px;
      width: 14px;
      height: 14px;
      border-radius: 50%;
      border: 3px solid var(--panel);
    }

    .fl-status-dot.online {
      background: var(--success);
    }

    .fl-status-dot.busy {
      background: var(--warn);
    }

    .fl-status-dot.offline {
      background: var(--muted);
    }

    .fl-name {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 16px;
      margin-bottom: 2px;
    }

    .fl-title {
      font-size: 12px;
      color: var(--muted);
      margin-bottom: 10px;
    }

    .fl-stats {
      display: flex;
      gap: 14px;
      margin-bottom: 12px;
    }

    .fl-stat {
      text-align: center;
    }

    .fl-stat .sv {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 15px;
      color: var(--accent);
    }

    .fl-stat .sl {
      font-size: 10px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .5px;
    }

    .fl-desc {
      font-size: 12px;
      color: var(--muted);
      line-height: 1.6;
      margin-bottom: 12px;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .fl-footer {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 14px;
      padding-top: 14px;
      border-top: 1px solid var(--border);
    }

    .fl-rate {
      font-family: 'Syne', sans-serif;
      font-size: 15px;
      font-weight: 800;
      color: var(--accent);
      margin-right: auto;
    }

    .fl-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 16px;
    }

    .filter-sidebar {
      width: 260px;
      flex-shrink: 0;
    }

    .layout-wrap {
      display: flex;
      gap: 24px;
      align-items: flex-start;
    }

    .filter-section {
      margin-bottom: 22px;
    }

    .filter-section-title {
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: .8px;
      color: var(--muted);
      margin-bottom: 10px;
    }

    .filter-option {
      display: flex;
      align-items: center;
      gap: 9px;
      padding: 6px 0;
      cursor: pointer;
      font-size: 13px;
    }

    .filter-option input {
      accent-color: var(--accent);
      width: 14px;
      height: 14px;
    }

    .filter-option .count {
      margin-left: auto;
      font-size: 11px;
      color: var(--muted);
      background: var(--bg3);
      border-radius: 10px;
      padding: 1px 7px;
    }

    .sort-bar {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 18px;
      flex-wrap: wrap;
    }

    .sort-bar .results-count {
      margin-right: auto;
      font-size: 13px;
      color: var(--muted);
    }

    .range-slider {
      -webkit-appearance: none;
      width: 100%;
      height: 4px;
      border-radius: 2px;
      background: var(--border);
      outline: none;
    }

    .range-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: var(--accent);
      cursor: pointer;
    }

    .view-toggle {
      display: flex;
      gap: 4px;
    }

    .view-btn {
      width: 32px;
      height: 32px;
      border-radius: 6px;
      border: 1px solid var(--border);
      background: var(--bg3);
      color: var(--muted);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 13px;
      transition: all .2s;
    }

    .view-btn.active {
      border-color: var(--accent);
      color: var(--accent);
      background: rgba(0, 229, 192, .06);
    }
  </style>
</head>

<body>
  <div class="wrapper">

    <!-- ── Sidebar ── -->
    <aside class="sidebar">
      <div class="sidebar-logo">
        <div class="brand">Free<span>Lynk</span></div>
      </div>
      <div class="sidebar-user">
       <div class="avatar"><?= $initials ?></div>
      <div class="sidebar-user-info">
        <div class="name"><?= $shortName ?></div>
        <div class="role">Client</div>
      </div>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section-label">Overview</div>
        <div class="nav-item" onclick="window.location='client_dashboard.php'">
          <i class="fa-solid fa-gauge-high"></i> Dashboard
        </div>
      
        <div class="nav-section-label mt-3">Jobs</div>
        <div class="nav-item" onclick="openModal('postJobModal')">
          <i class="fa-solid fa-plus-circle"></i> Post a Job
        </div>
        <div class="nav-item active" data-page="browse_freelancers.php">
          <i class="fa-solid fa-users"></i> Browse Freelancers
        </div>
        <div class="nav-section-label mt-3">Disputes</div>
        <div class="nav-item" onclick="openDisputeFlow()">
          <i class="fa-solid fa-triangle-exclamation"></i> Open Dispute
        </div>
      </nav>
      <div class="sidebar-footer">
        <div class="nav-item" onclick="window.location='index.php'">
          <i class="fa-solid fa-right-from-bracket"></i> Sign Out
        </div>
      </div>
    </aside>

    <!-- ── Main ── -->
    <div class="main">
      <div class="topbar">
        <span class="page-title">Browse Freelancers</span>
        <div class="topbar-actions">
          <div class="icon-btn" onclick="showToast('No new notifications')">
            <i class="fa-solid fa-bell"></i><span class="notif-dot"></span>
          </div>
          <a href="client_profile.php">
            <div class="avatar" style="width:34px;height:34px;font-size:12px;">AN</div>
          </a>
        </div>
      </div>

      <div class="page-content">

        <!-- Search Row -->
        <div style="display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;" class="fade-in">
          <input type="text" class="form-control" style="flex:1;min-width:200px;" id="flSearch" placeholder="Search by name, skill, or title…" oninput="filterFreelancers()">
          <div class="view-toggle">
            <div class="view-btn active" id="gridViewBtn" onclick="setView('grid')" title="Grid"><i class="fa-solid fa-grip"></i></div>
            <div class="view-btn" id="listViewBtn" onclick="setView('list')" title="List"><i class="fa-solid fa-list"></i></div>
          </div>
        </div>

        <div class="layout-wrap">

          <!-- ── Filter Sidebar ── -->
          <div class="filter-sidebar fade-in-1" style="display: none;">
            <div class="card">
              <div class="card-header" style="padding:16px 20px;">
                <span class="card-title" style="font-size:13px;"><i class="fa-solid fa-sliders text-accent"></i> &nbsp;Filters</span>
                <button style="font-size:11px;color:var(--accent);background:none;border:none;cursor:pointer;padding:0;font-family:'Syne',sans-serif;" onclick="resetFilters()">Reset</button>
              </div>
              <div style="padding:16px 20px;">

                <!-- Hourly Rate -->
                <div class="filter-section">
                  <div class="filter-section-title">Max Hourly Rate</div>
                  <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-bottom:8px;">
                    <span>$0/hr</span><span id="rateVal" class="text-accent font-bold">$100/hr</span>
                  </div>
                  <input type="range" class="range-slider" min="0" max="200" value="100" id="rateRange" oninput="document.getElementById('rateVal').textContent='$'+this.value+'/hr';filterFreelancers()">
                </div>

                <!-- Availability -->
                <div class="filter-section">
                  <div class="filter-section-title">Availability</div>
                  <label class="filter-option"><input type="checkbox" checked class="avail-filter"> Available Now <span class="count">8</span></label>
                  <label class="filter-option"><input type="checkbox" checked class="avail-filter"> Busy <span class="count">5</span></label>
                  <label class="filter-option"><input type="checkbox" class="avail-filter"> Offline <span class="count">3</span></label>
                </div>

                <!-- Experience -->
                <div class="filter-section">
                  <div class="filter-section-title">Experience Level</div>
                  <label class="filter-option"><input type="checkbox" checked> Entry <span class="count">4</span></label>
                  <label class="filter-option"><input type="checkbox" checked> Intermediate <span class="count">7</span></label>
                  <label class="filter-option"><input type="checkbox" checked> Expert <span class="count">5</span></label>
                </div>

                <!-- Verification -->
                <div class="filter-section">
                  <div class="filter-section-title">Verification</div>
                  <label class="filter-option"><input type="checkbox" checked> Verified Only <span class="count">12</span></label>
                  <label class="filter-option"><input type="checkbox" checked> Top Rated <span class="count">6</span></label>
                </div>

                <!-- Skills -->
                <div class="filter-section">
                  <div class="filter-section-title">Skills</div>
                  <div class="skill-tags" style="gap:6px;">
                    <?php
                    $skills = ['React', 'Node.js', 'Python', 'Figma', 'Vue.js', 'TypeScript', 'AWS', 'Docker', 'PHP', 'Laravel'];
                    foreach ($skills as $s): ?>
                      <span class="skill-tag" style="font-size:11px;padding:3px 8px;cursor:pointer;" onclick="toggleSkillFilter(this,'<?= $s ?>')"><?= $s ?></span>
                    <?php endforeach; ?>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <!-- ── Freelancers Grid ── -->
          <div style="flex:1;">
            <div class="sort-bar fade-in-2">
              <span class="results-count" id="flCount">
                Showing <strong><?= count($freelancers) ?></strong> freelancers
              </span>
            </div>

            <div class="fl-grid" id="freelancerGrid">
              <?php if (empty($freelancers)): ?>

                <p>No freelancers yet</p>
               
              <?php else: ?>
              <?php foreach ($freelancers as $fl): ?>
                <div class="fl-card"
                  data-name="<?= strtolower($fl['first_name'] . ' ' . $fl['last_name']) ?>"
                  data-title="freelancer"
                  data-category="General"
                  data-rate="0"
                  data-status="online">

                  <div class="fl-avatar-wrap">
                    <div class="fl-avatar" style="background:linear-gradient(135deg,#6c63ff,#00e5c0);">
                     <?= strtoupper(substr($fl['first_name'], 0, 1) . substr($fl['last_name'], 0, 1)) ?>
                    </div>
                    <div class="fl-status-dot online"></div>
                  </div>

                  <div class="fl-name"><?= $fl['first_name'] . ' ' . $fl['last_name'] ?></div>

                  <div class="fl-title">
                    Freelancer
                  </div>

                 

                  <p class="fl-desc">
                    <?= $fl['email'] ?>
                  </p>

                  <div class="fl-footer">
                  <div class="fl-rate">
  $<?= $fl['rate'] ?? 0 ?>/hr
</div>

                  
                    <button class="btn btn-sm btn-secondary">
                      <i class="fa-solid fa-calendar"></i>
                    </button>

                    <button class="btn btn-sm btn-primary">
                      Invite
                    </button>
                  </div>

                </div>

              <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

        </div><!-- /grid wrap -->
      </div><!-- /layout-wrap -->
    </div><!-- /page-content -->
  </div><!-- /main -->
  </div><!-- /wrapper -->

  <!-- ════════════ FREELANCER DETAIL MODAL ════════════ -->
  <div class="modal-backdrop hidden" id="flDetailModal">
    <div class="modal" style="max-width:620px;max-height:90vh;overflow-y:auto;">
      <div class="modal-header" style="position:sticky;top:0;background:var(--panel);z-index:1;">
        <span class="modal-title" id="flDetailName"><i class="fa-solid fa-user text-accent"></i> &nbsp;Freelancer Profile</span>
        <button class="icon-btn" onclick="closeModal('flDetailModal')"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="modal-body" id="flDetailBody"></div>
      <div class="modal-footer" style="position:sticky;bottom:0;background:var(--panel);">
        <button class="btn btn-secondary btn-sm" onclick="closeModal('flDetailModal')">Close</button>
        <button class="btn btn-secondary btn-sm" id="interviewFromDetail"><i class="fa-solid fa-calendar"></i> Interview</button>
        <button class="btn btn-primary btn-sm" id="inviteFromDetail"><i class="fa-solid fa-paper-plane"></i> Invite to Job</button>
      </div>
    </div>
  </div>

  <!-- Schedule Interview Modal -->
  <div class="modal-backdrop hidden" id="interviewModal">
    <div class="modal">
      <div class="modal-header">
        <span class="modal-title"><i class="fa-solid fa-calendar-check text-accent"></i> &nbsp;Schedule Interview</span>
        <button class="icon-btn" onclick="closeModal('interviewModal')"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Freelancer</label>
          <input type="text" class="form-control" id="interviewFlName" readonly>
        </div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Date</label><input type="date" class="form-control"></div>
          <div class="form-group"><label class="form-label">Time (Local)</label><input type="time" class="form-control"></div>
        </div>
        <div class="form-group">
          <label class="form-label">Platform</label>
          <select class="form-control">
            <option>Zoom</option>
            <option>Google Meet</option>
            <option>Teams</option>
          </select>
        </div>
        <div style="background:rgba(0,229,192,.06);border:1px solid rgba(0,229,192,.15);border-radius:8px;padding:10px 14px;font-size:12px;color:var(--muted);">
          <i class="fa-solid fa-globe text-accent"></i> &nbsp;Timezone auto-adjusted (FR34)
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" onclick="closeModal('interviewModal')">Cancel</button>
        <button class="btn btn-primary btn-sm" onclick="closeModal('interviewModal');showToast('Interview scheduled! Both parties notified.')">
          <i class="fa-solid fa-calendar-plus"></i> Confirm
        </button>
      </div>
    </div>
  </div>

  <!-- Post Job Modal (simplified) -->
 <div class="modal-backdrop hidden" id="postJobModal">
  <div class="modal" style="max-width:560px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-plus-circle text-accent"></i> &nbsp;Post a Job</span>
      <button class="icon-btn" onclick="closeModal('postJobModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <form action="../controllers/post_job.php" method="POST">
    <div class="modal-body">
      <div class="form-group">
        <label class="form-label">Job Category</label>
        <select class="form-control" name="category" id="jobCategory" onchange="updateJobForm()" required>
          <option value="">Select a category…</option>
          <option value="Web Development">Web Development</option>
          <option value="UI/UX Design">UI/UX Design</option>
          <option value="Content Writing">Content Writing</option>
          <option value="Data Science">Data Science</option>
          <option value="Mobile Development">Mobile Development</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Job Title</label>
        <input type="text" name="title" class="form-control" placeholder="e.g. Build a React Dashboard" required>
      </div>
      <div class="form-group">
        <label class="form-label">Description</label>
        <textarea name="description" class="form-control" placeholder="Describe the project scope and requirements…" required></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Budget ($)</label>
          <input type="number" name="budget" class="form-control" placeholder="1250" min="1" required>
        </div>
        <div class="form-group">
          <label class="form-label">Deadline</label>
          <input type="date" class="form-control">
        </div>
      </div>
      <div id="dynamicFields"></div>
      <div class="flex gap-2 items-center" style="margin-top:8px;">
        <input type="checkbox" id="privateJob" style="accent-color:var(--accent)">
        <label for="privateJob" style="font-size:13px;cursor:pointer;">
          <i class="fa-solid fa-lock text-accent"></i> &nbsp;Private job — invite only
        </label>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary btn-sm" onclick="closeModal('postJobModal')">Cancel</button>
      <button type="submit" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-paper-plane"></i> Publish Job
      </button>
    </div>
    </form>
  </div>
</div>

  <!-- Open Dispute Modal -->
  <div class="modal-backdrop hidden" id="disputeModal">
    <div class="modal">
      <div class="modal-header">
        <span class="modal-title"><i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Open Dispute</span>
        <button class="icon-btn" onclick="closeModal('disputeModal')"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Contract</label>
          <select class="form-control">
            <option>Contract #54 — React Job</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Reason</label>
          <textarea class="form-control" placeholder="Describe the issue…"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-sm" onclick="closeModal('disputeModal')">Cancel</button>
        <button class="btn btn-danger btn-sm" onclick="closeModal('disputeModal');showToast('Dispute filed.','warn')">
          <i class="fa-solid fa-flag"></i> File
        </button>
      </div>
    </div>
  </div>

  <div id="toast-container"></div>
  <script src="../assets/js/main.js"></script>
  <script src="../assets/js/chat-sidebar.js"></script>
  <script>
    const statusLabel = {
      online: '<span class="badge badge-success"><i class="fa-solid fa-circle" style="font-size:7px"></i> Available</span>',
      busy: '<span class="badge badge-warn">Busy</span>',
      offline: '<span class="badge badge-muted">Offline</span>'
    };

    function openFreelancerDetail(id) {
      const f = flData[id];
      if (!f) return;
      document.getElementById('flDetailName').innerHTML = `<i class="fa-solid fa-user text-accent"></i> &nbsp;${f.name}`;
      document.getElementById('flDetailBody').innerHTML = `
    <div style="display:flex;gap:20px;align-items:flex-start;margin-bottom:20px;">
      <div style="position:relative;flex-shrink:0;">
        <div style="width:72px;height:72px;border-radius:50%;background:linear-gradient(${f.gradient});display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:800;font-size:24px;color:var(--bg);">${f.initials}</div>
        <div style="position:absolute;bottom:3px;right:3px;width:14px;height:14px;border-radius:50%;border:3px solid var(--panel);background:${f.status==='online'?'var(--success)':f.status==='busy'?'var(--warn)':'var(--muted)'};"></div>
      </div>
      <div style="flex:1;">
        <div style="font-family:'Syne',sans-serif;font-size:20px;font-weight:800;margin-bottom:4px;">${f.name} ${f.verified?'<span class="badge badge-success" style="font-size:10px;vertical-align:middle;"><i class="fa-solid fa-shield-check"></i> Verified</span>':''}</div>
        <div style="font-size:13px;color:var(--muted);margin-bottom:8px;">${f.title} &nbsp;·&nbsp; ${statusLabel[f.status]}</div>
        <div style="font-size:22px;font-family:'Syne',sans-serif;font-weight:800;color:var(--accent);">$${f.rate}<span style="font-size:13px;color:var(--muted);font-weight:400;">/hr</span></div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:18px;">
      ${[['Score',f.score,'var(--accent)'],['Jobs Done',f.jobs,'var(--text)'],['Reviews',f.reviews,'var(--text)'],['Success',f.success+'%','var(--success)']].map(s=>`<div style="background:var(--bg3);border-radius:8px;padding:10px;text-align:center;"><div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:${s[2]};">${s[1]}</div><div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin-top:2px;">${s[0]}</div></div>`).join('')}
    </div>
    <div style="margin-bottom:16px;">
      <div style="font-family:'Syne',sans-serif;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:8px;">About</div>
      <p style="font-size:13px;color:var(--text);line-height:1.7;">${f.desc}</p>
    </div>
    <div>
      <div style="font-family:'Syne',sans-serif;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:8px;">Skills</div>
      <div class="skill-tags">${f.skills.map(s=>`<span class="skill-tag">${s}</span>`).join('')}</div>
    </div>
  `;
      document.getElementById('shortlistFromDetail').onclick = () => {
        closeModal('flDetailModal');
        shortlistFreelancer(f.name);
      };
      document.getElementById('interviewFromDetail').onclick = () => {
        closeModal('flDetailModal');
        openInterviewForFL(f.name);
      };
      document.getElementById('inviteFromDetail').onclick = () => {
        closeModal('flDetailModal');
        inviteFreelancer(f.name);
      };
      openModal('flDetailModal');
    }

    function shortlistFreelancer(name) {
      showToast(`${name} added to your shortlist! (FR12)`);
    }

    function inviteFreelancer(name) {
      showToast(`Job invitation sent to ${name}!`);
    }

    function openInterviewForFL(name) {
      document.getElementById('interviewFlName').value = name;
      openModal('interviewModal');
    }

    function scheduleInterview() {
      openModal('interviewModal');
    }

    function openDisputeFlow() {
      openModal('disputeModal');
    }

    function filterFreelancers() {
      const q = document.getElementById('flSearch').value.toLowerCase();
      const cat = document.getElementById('catFilter').value;
      const maxRate = parseInt(document.getElementById('rateRange').value);
      let count = 0;
      document.querySelectorAll('.fl-card').forEach(card => {
        const name = card.dataset.name || '',
          title = card.dataset.title || '';
        const category = card.dataset.category || '';
        const rate = parseInt(card.dataset.rate) || 0;
        const show = (!q || name.includes(q) || title.includes(q)) && (!cat || category === cat) && rate <= maxRate;
        card.style.display = show ? '' : 'none';
        if (show) count++;
      });
      document.getElementById('flCount').innerHTML = `Showing <strong>${count}</strong> freelancers`;
    }

    function toggleSkillFilter(el, skill) {
      el.style.borderColor = el.style.borderColor ? '' : 'var(--accent)';
      el.style.color = el.style.color ? '' : 'var(--accent)';
    }

    function resetFilters() {
      document.getElementById('flSearch').value = '';
      document.getElementById('catFilter').value = '';
      document.getElementById('rateRange').value = 200;
      document.getElementById('rateVal').textContent = '$200/hr';
      filterFreelancers();
    }

    function setView(mode) {
      const grid = document.getElementById('freelancerGrid');
      document.getElementById('gridViewBtn').classList.toggle('active', mode === 'grid');
      document.getElementById('listViewBtn').classList.toggle('active', mode === 'list');
      if (mode === 'list') {
        grid.style.gridTemplateColumns = '1fr';
        document.querySelectorAll('.fl-card').forEach(c => {
          c.style.display = 'flex';
          c.style.gap = '20px';
          c.style.alignItems = 'center';
        });
      } else {
        grid.style.gridTemplateColumns = '';
        document.querySelectorAll('.fl-card').forEach(c => {
          c.style.display = '';
          c.style.flexDirection = '';
          c.style.gap = '';
          c.style.alignItems = '';
        });
      }
    }
  </script>
</body>

</html>