<?php
// messages.php — Messaging Center (shared by client & freelancer)
// role passed via query param: ?role=client (default) or ?role=freelancer
$role = isset($_GET['role']) && $_GET['role']==='freelancer' ? 'freelancer' : 'client';
$isClient = $role === 'client';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FreeLynk — Messages</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/chat-sidebar.css">
  <style>
    /* ── Chat Layout ── */
    .chat-layout {
      display: flex;
      height: calc(100vh - 64px);
      overflow: hidden;
    }

    /* ── Conversations List ── */
    .conv-list {
      width: 300px;
      flex-shrink: 0;
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      background: var(--bg2);
      overflow: hidden;
    }
    .conv-list-header {
      padding: 16px 20px;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .conv-list-header .title { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 15px; }
    .conv-search { padding: 12px 16px; border-bottom: 1px solid var(--border); }
    .conv-search input { width: 100%; background: var(--bg3); border: 1px solid var(--border); color: var(--text); border-radius: 8px; padding: 8px 12px; font-size: 13px; outline: none; font-family: 'DM Sans', sans-serif; }
    .conv-search input:focus { border-color: var(--accent); }
    .conv-search input::placeholder { color: var(--muted); }

    .conv-tabs { display: flex; border-bottom: 1px solid var(--border); }
    .conv-tab { flex: 1; padding: 10px; text-align: center; font-size: 12px; font-family: 'Syne', sans-serif; font-weight: 700; color: var(--muted); cursor: pointer; transition: all .2s; border-bottom: 2px solid transparent; }
    .conv-tab.active { color: var(--accent); border-bottom-color: var(--accent); }

    .conv-items { flex: 1; overflow-y: auto; }
    .conv-item {
      padding: 14px 16px;
      display: flex;
      gap: 12px;
      cursor: pointer;
      border-bottom: 1px solid rgba(42,47,64,.4);
      transition: background .15s;
      position: relative;
    }
    .conv-item:hover { background: rgba(255,255,255,.03); }
    .conv-item.active { background: rgba(0,229,192,.06); border-left: 3px solid var(--accent); }
    .conv-item .avatar { flex-shrink: 0; width: 42px; height: 42px; font-size: 14px; }
    .conv-item-info { flex: 1; min-width: 0; }
    .conv-item-name { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 13px; margin-bottom: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .conv-item-preview { font-size: 12px; color: var(--muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .conv-item-meta { display: flex; flex-direction: column; align-items: flex-end; gap: 5px; flex-shrink: 0; }
    .conv-item-time { font-size: 10px; color: var(--muted); }
    .conv-unread { background: var(--accent); color: var(--bg); font-size: 10px; font-weight: 700; font-family: 'Syne', sans-serif; border-radius: 10px; padding: 1px 6px; min-width: 18px; text-align: center; }

    /* ── Chat Window ── */
    .chat-window {
      flex: 1;
      display: flex;
      flex-direction: column;
      background: var(--bg);
      overflow: hidden;
    }
    .chat-header {
      padding: 14px 24px;
      border-bottom: 1px solid var(--border);
      background: var(--bg2);
      display: flex;
      align-items: center;
      gap: 14px;
    }
    .chat-header .avatar { width: 40px; height: 40px; font-size: 14px; flex-shrink: 0; }
    .chat-header-info { flex: 1; }
    .chat-header-name { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 15px; }
    .chat-header-sub { font-size: 12px; color: var(--muted); }
    .chat-header-actions { display: flex; gap: 8px; }

    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 24px;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .msg-group { display: flex; flex-direction: column; gap: 4px; }
    .msg-group.mine { align-items: flex-end; }
    .msg-group.theirs { align-items: flex-start; }

    .msg-row { display: flex; align-items: flex-end; gap: 8px; max-width: 70%; }
    .msg-group.mine .msg-row { flex-direction: row-reverse; }

    .msg-bubble {
      padding: 10px 14px;
      border-radius: 14px;
      font-size: 13.5px;
      line-height: 1.6;
      max-width: 100%;
      word-break: break-word;
    }
    .msg-group.mine .msg-bubble {
      background: var(--accent);
      color: var(--bg);
      border-bottom-right-radius: 4px;
    }
    .msg-group.theirs .msg-bubble {
      background: var(--panel);
      border: 1px solid var(--border);
      color: var(--text);
      border-bottom-left-radius: 4px;
    }
    .msg-meta { font-size: 10px; color: var(--muted); padding: 0 4px; }
    .msg-avatar { width: 28px; height: 28px; font-size: 10px; flex-shrink: 0; }

    /* System / restricted message */
    .msg-system {
      text-align: center;
      font-size: 11px;
      color: var(--muted);
      padding: 8px 20px;
      background: rgba(239,68,68,.06);
      border: 1px solid rgba(239,68,68,.15);
      border-radius: 8px;
      margin: 0 auto;
      max-width: 400px;
    }

    /* File attachment bubble */
    .msg-file {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(0,229,192,.08);
      border: 1px solid rgba(0,229,192,.2);
      border-radius: 10px;
      padding: 10px 14px;
      font-size: 13px;
      margin-top: 4px;
      cursor: pointer;
      transition: background .2s;
    }
    .msg-file:hover { background: rgba(0,229,192,.14); }

    /* Date separator */
    .date-sep { display: flex; align-items: center; gap: 12px; color: var(--muted); font-size: 11px; }
    .date-sep::before, .date-sep::after { content: ''; flex: 1; height: 1px; background: var(--border); }

    /* Chat input area */
    .chat-input-area {
      padding: 16px 24px;
      border-top: 1px solid var(--border);
      background: var(--bg2);
    }
    .chat-input-row {
      display: flex;
      gap: 10px;
      align-items: flex-end;
      background: var(--bg3);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 10px 14px;
      transition: border-color .2s;
    }
    .chat-input-row:focus-within { border-color: var(--accent); }

    .chat-input {
      flex: 1;
      background: none;
      border: none;
      color: var(--text);
      font-family: 'DM Sans', sans-serif;
      font-size: 14px;
      outline: none;
      resize: none;
      max-height: 120px;
      line-height: 1.5;
    }
    .chat-input::placeholder { color: var(--muted); }

    .chat-input-actions { display: flex; gap: 6px; align-items: flex-end; }
    .send-btn {
      width: 36px; height: 36px;
      border-radius: 8px;
      background: var(--accent);
      border: none;
      color: var(--bg);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-size: 14px;
      transition: filter .2s, transform .2s;
      flex-shrink: 0;
    }
    .send-btn:hover { filter: brightness(1.1); transform: scale(1.05); }

    /* Restricted banner */
    .restricted-banner {
      background: rgba(239,68,68,.08);
      border-bottom: 1px solid rgba(239,68,68,.2);
      padding: 8px 24px;
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 12px;
      color: var(--danger);
    }

    /* Contract info bar */
    .contract-bar {
      background: rgba(0,229,192,.06);
      border-bottom: 1px solid rgba(0,229,192,.15);
      padding: 10px 24px;
      display: flex;
      align-items: center;
      gap: 14px;
      font-size: 12px;
    }
    .contract-bar .cb-label { color: var(--muted); }
    .contract-bar .cb-value { font-family: 'Syne', sans-serif; font-weight: 700; color: var(--accent); }

    /* Empty state */
    .empty-chat {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: var(--muted);
      gap: 14px;
    }
    .empty-chat i { font-size: 48px; opacity: .3; }
    .empty-chat p { font-size: 14px; }
  </style>
</head>
<body>
<div class="wrapper">

  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo"><div class="brand">Free<span>Lynk</span></div></div>
    <div class="sidebar-user">
      <?php if($isClient): ?>
      <div class="avatar">AN</div>
      <div class="sidebar-user-info"><div class="name">A. Nassar</div><div class="role">Client</div></div>
      <?php else: ?>
      <div class="avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
      <div class="sidebar-user-info"><div class="name">Ali Morsy</div><div class="role">Freelancer</div></div>
      <?php endif; ?>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section-label">Overview</div>
      <?php if($isClient): ?>
      <div class="nav-item" onclick="window.location='client_dashboard.php'"><i class="fa-solid fa-gauge-high"></i> Dashboard</div>
      <div class="nav-item" onclick="window.location='client_profile.php'"><i class="fa-solid fa-circle-user"></i> My Profile</div>
      <div class="nav-section-label mt-3">Jobs</div>
      <div class="nav-item" onclick="showToast('Post Job')"><i class="fa-solid fa-plus-circle"></i> Post a Job</div>
      <div class="nav-item" onclick="window.location='freelancers.php'"><i class="fa-solid fa-users"></i> Browse Freelancers</div>
      <?php else: ?>
      <div class="nav-item" onclick="window.location='freelancer_dashboard.php'"><i class="fa-solid fa-gauge-high"></i> Dashboard</div>
      <div class="nav-item" onclick="window.location='freelancer_profile.php'"><i class="fa-solid fa-circle-user"></i> My Profile</div>
      <div class="nav-section-label mt-3">Work</div>
      <div class="nav-item" onclick="window.location='browse_jobs.php'"><i class="fa-solid fa-magnifying-glass"></i> Browse Jobs</div>
      <div class="nav-item" onclick="showToast('My Proposals')"><i class="fa-solid fa-paper-plane"></i> My Proposals <span class="nav-badge">4</span></div>
      <div class="nav-item" onclick="showToast('Active Contracts')"><i class="fa-solid fa-file-contract"></i> Active Contracts <span class="nav-badge">2</span></div>
      <?php endif; ?>
      <div class="nav-section-label mt-3">Communication</div>
      <div class="nav-item active" data-page="messages.php">
        <i class="fa-solid fa-message"></i> Messages
        <span class="nav-badge"><?= $isClient ? '5' : '3' ?></span>
      </div>
      <div class="nav-section-label mt-3">Disputes</div>
      <div class="nav-item" onclick="openDisputeFlow()"><i class="fa-solid fa-triangle-exclamation"></i> Open Dispute</div>
    </nav>
    <div class="sidebar-footer">
      <div class="nav-item" onclick="window.location='index.php'"><i class="fa-solid fa-right-from-bracket"></i> Sign Out</div>
    </div>
  </aside>

  <!-- ── Main (no padding override) ── -->
  <div class="main" style="overflow:hidden;">
    <div class="topbar">
      <span class="page-title">Messages</span>
      <div class="topbar-actions">
        <div class="icon-btn" onclick="showToast('No new notifications')">
          <i class="fa-solid fa-bell"></i><span class="notif-dot"></span>
        </div>
        <a href="<?= $isClient ? 'client_profile.php' : 'freelancer_profile.php' ?>">
          <div class="avatar" style="width:34px;height:34px;font-size:12px;<?= !$isClient ? 'background:linear-gradient(135deg,#22c55e,#00e5c0);' : '' ?>">
            <?= $isClient ? 'AN' : 'AM' ?>
          </div>
        </a>
      </div>
    </div>

    <!-- ── Chat Layout ── -->
    <div class="chat-layout">

      <!-- ── Conversations Sidebar ── -->
      <div class="conv-list">
        <div class="conv-list-header">
          <span class="title">Inbox</span>
          <button class="icon-btn" onclick="showToast('New conversation — coming soon')"><i class="fa-solid fa-pen-to-square"></i></button>
        </div>
        <div class="conv-search">
          <input type="text" placeholder="Search conversations…" oninput="filterConvs(this.value)">
        </div>
        <div class="conv-tabs">
          <div class="conv-tab active" onclick="switchTab(this,'all')">All</div>
          <div class="conv-tab" onclick="switchTab(this,'unread')">Unread</div>
          <div class="conv-tab" onclick="switchTab(this,'dispute')">Disputes</div>
        </div>
        <div class="conv-items" id="convList">
          <?php
          $conversations = [
            ['id'=>1,'name'=>$isClient?'Ali Morsy':'A. Nassar','role'=>$isClient?'Freelancer':'Client','initials'=>$isClient?'AM':'AN','gradient'=>'135deg,#22c55e,#00e5c0','preview'=>'Phase 2 files are uploaded, please review','time'=>'2m','unread'=>3,'type'=>'contract','online'=>true,'active'=>true,'restricted'=>false],
            ['id'=>2,'name'=>$isClient?'Sara Hassan':'TechStart Inc.','role'=>$isClient?'Freelancer':'Client','initials'=>$isClient?'SH':'TI','gradient'=>'135deg,#f59e0b,#ef4444','preview'=>'Can you send the revised wireframes?','time'=>'1h','unread'=>2,'type'=>'contract','online'=>false,'active'=>false,'restricted'=>false],
            ['id'=>3,'name'=>$isClient?'Admin — Dispute #001':'Admin — Dispute #001','role'=>'System','initials'=>'⚖','gradient'=>'135deg,#ef4444,#f59e0b','preview'=>'[Restricted] Both parties upload evidence','time'=>'3h','unread'=>1,'type'=>'dispute','online'=>true,'active'=>false,'restricted'=>true],
            ['id'=>4,'name'=>$isClient?'Karim Omar':'DataCo Analytics','role'=>$isClient?'Freelancer':'Client','initials'=>$isClient?'KO':'DC','gradient'=>'135deg,#6c63ff,#00e5c0','preview'=>'Sounds good, I can start Monday','time'=>'Yesterday','unread'=>0,'type'=>'proposal','online'=>true,'active'=>false,'restricted'=>false],
            ['id'=>5,'name'=>$isClient?'Nour Nabil':'BookingPro','role'=>$isClient?'Freelancer':'Client','initials'=>$isClient?'NN':'BP','gradient'=>'135deg,#00e5c0,#6c63ff','preview'=>'Thank you for the opportunity!','time'=>'2d','unread'=>0,'type'=>'proposal','online'=>false,'active'=>false,'restricted'=>false],
          ];
          foreach($conversations as $c): ?>
          <div class="conv-item <?= $c['active'] ? 'active' : '' ?>" data-id="<?= $c['id'] ?>" data-name="<?= strtolower($c['name']) ?>" onclick="openConversation(<?= $c['id'] ?>)">
            <div class="avatar" style="width:42px;height:42px;font-size:13px;background:linear-gradient(<?= $c['gradient'] ?>);position:relative;flex-shrink:0;">
              <?= $c['initials'] ?>
              <?php if($c['online']): ?>
              <div style="position:absolute;bottom:0;right:0;width:11px;height:11px;background:var(--success);border-radius:50%;border:2px solid var(--bg2);"></div>
              <?php endif; ?>
            </div>
            <div class="conv-item-info">
              <div class="conv-item-name"><?= $c['name'] ?></div>
              <div class="conv-item-preview">
                <?php if($c['restricted']): ?><i class="fa-solid fa-lock" style="color:var(--danger);font-size:10px;"></i> <?php endif; ?>
                <?= $c['preview'] ?>
              </div>
            </div>
            <div class="conv-item-meta">
              <span class="conv-item-time"><?= $c['time'] ?></span>
              <?php if($c['unread']>0): ?>
              <span class="conv-unread"><?= $c['unread'] ?></span>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div><!-- /conv-list -->

      <!-- ── Active Chat Window ── -->
      <div class="chat-window" id="chatWindow">

        <!-- Chat Header -->
        <div class="chat-header" id="chatHeader">
          <div class="avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
          <div class="chat-header-info">
            <div class="chat-header-name" id="chatName">Ali Morsy</div>
            <div class="chat-header-sub" id="chatSub"><i class="fa-solid fa-circle" style="color:var(--success);font-size:8px;"></i> Online &nbsp;·&nbsp; React Job — Contract #54</div>
          </div>
          <div class="chat-header-actions">
            <div class="icon-btn" onclick="showToast('Call feature coming soon')" title="Voice Call"><i class="fa-solid fa-phone"></i></div>
            <div class="icon-btn" onclick="showToast('Video call coming soon')" title="Video Call"><i class="fa-solid fa-video"></i></div>
            <div class="icon-btn" onclick="openModal('contractInfoModal')" title="Contract Info"><i class="fa-solid fa-file-contract"></i></div>
            <div class="icon-btn" onclick="showToast('More options')" title="More"><i class="fa-solid fa-ellipsis-vertical"></i></div>
          </div>
        </div>

        <!-- Contract Bar -->
        <div class="contract-bar" id="contractBar">
          <i class="fa-solid fa-file-contract text-accent"></i>
          <span class="cb-label">Contract:</span><span class="cb-value">#54 React Job</span>
          <span style="color:var(--border)">|</span>
          <span class="cb-label">Milestone:</span><span class="cb-value">Phase 2 — Core Components</span>
          <span style="color:var(--border)">|</span>
          <span class="cb-label">Due:</span><span class="cb-value" style="color:var(--warn)">Apr 25, 2026</span>
          <button class="btn btn-sm btn-secondary" style="margin-left:auto;font-size:11px;" onclick="showToast('Viewing contract details…')">View Contract</button>
        </div>

        <!-- Messages Area -->
        <div class="chat-messages" id="messagesArea">

          <!-- Date Sep -->
          <div class="date-sep">Apr 20, 2026</div>

          <!-- Theirs -->
          <div class="msg-group theirs">
            <div class="msg-row">
              <div class="avatar msg-avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
              <div>
                <div class="msg-bubble">Hi! I've finished the sidebar component and the dashboard layout. Starting on the charts tomorrow.</div>
                <div class="msg-meta">Ali Morsy &nbsp;·&nbsp; 10:15 AM</div>
              </div>
            </div>
          </div>

          <!-- Mine -->
          <div class="msg-group mine">
            <div class="msg-row">
              <div>
                <div class="msg-bubble">Great! Make sure the charts are responsive. Also, can you share a preview screenshot?</div>
                <div class="msg-meta" style="text-align:right;">You &nbsp;·&nbsp; 10:32 AM &nbsp;<i class="fa-solid fa-check-double" style="color:var(--accent);font-size:10px;"></i></div>
              </div>
            </div>
          </div>

          <!-- Theirs with file -->
          <div class="msg-group theirs">
            <div class="msg-row">
              <div class="avatar msg-avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
              <div>
                <div class="msg-bubble">Sure! Here's the preview:</div>
                <div class="msg-file" onclick="showToast('Downloading dashboard_preview.png…')">
                  <i class="fa-solid fa-image" style="font-size:20px;color:var(--accent);"></i>
                  <div><div style="font-size:12px;font-weight:600;">dashboard_preview.png</div><div style="font-size:11px;color:var(--muted);">2.4 MB &nbsp;·&nbsp; Click to download</div></div>
                </div>
                <div class="msg-meta">Ali Morsy &nbsp;·&nbsp; 11:08 AM</div>
              </div>
            </div>
          </div>

          <!-- Mine -->
          <div class="msg-group mine">
            <div class="msg-row">
              <div>
                <div class="msg-bubble">Looks clean! The color scheme matches perfectly. Please also make sure to add the loading skeleton states for the widgets.</div>
                <div class="msg-meta" style="text-align:right;">You &nbsp;·&nbsp; 11:45 AM &nbsp;<i class="fa-solid fa-check-double" style="color:var(--accent);font-size:10px;"></i></div>
              </div>
            </div>
          </div>

          <!-- Date Sep -->
          <div class="date-sep">Apr 22, 2026</div>

          <!-- Theirs -->
          <div class="msg-group theirs">
            <div class="msg-row">
              <div class="avatar msg-avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
              <div>
                <div class="msg-bubble">Skeleton states are done. I've also added error boundaries. Phase 2 files are ready — uploading now via the Submit Work form.</div>
                <div class="msg-file" onclick="showToast('Downloading phase2_deliverables.zip…')">
                  <i class="fa-solid fa-file-zipper" style="font-size:20px;color:var(--accent);"></i>
                  <div><div style="font-size:12px;font-weight:600;">phase2_deliverables.zip</div><div style="font-size:11px;color:var(--muted);">18.7 MB &nbsp;·&nbsp; Click to download</div></div>
                </div>
                <div class="msg-meta">Ali Morsy &nbsp;·&nbsp; 9:00 AM</div>
              </div>
            </div>
          </div>

          <!-- Mine -->
          <div class="msg-group mine">
            <div class="msg-row">
              <div>
                <div class="msg-bubble">Perfect! I'll review everything today and get back to you with feedback.</div>
                <div class="msg-meta" style="text-align:right;">You &nbsp;·&nbsp; 9:14 AM &nbsp;<i class="fa-solid fa-check-double" style="color:var(--accent);font-size:10px;"></i></div>
              </div>
            </div>
          </div>

          <!-- Date Sep -->
          <div class="date-sep">Today</div>

          <!-- Theirs -->
          <div class="msg-group theirs">
            <div class="msg-row">
              <div class="avatar msg-avatar" style="background:linear-gradient(135deg,#22c55e,#00e5c0);">AM</div>
              <div>
                <div class="msg-bubble">Any feedback so far? I'm ready to start Phase 3 once you approve 🙂</div>
                <div class="msg-meta">Ali Morsy &nbsp;·&nbsp; Just now</div>
              </div>
            </div>
          </div>

        </div><!-- /chat-messages -->

        <!-- ── Input Area ── -->
        <div class="chat-input-area">
          <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;" id="quickReplies">
            <button class="btn btn-sm btn-secondary" style="font-size:11px;" onclick="insertQuickReply('Looks great! Approved ✓')">👍 Approve Work</button>
            <button class="btn btn-sm btn-secondary" style="font-size:11px;" onclick="insertQuickReply('Please revise the following: ')">✏️ Request Revision</button>
            <button class="btn btn-sm btn-secondary" style="font-size:11px;" onclick="insertQuickReply('Can we schedule a quick call to discuss?')">📞 Schedule Call</button>
            <button class="btn btn-sm btn-secondary" style="font-size:11px;color:var(--danger);border-color:rgba(239,68,68,.3);" onclick="openDisputeFlow()">⚠️ Open Dispute</button>
          </div>
          <div class="chat-input-row">
            <textarea class="chat-input" id="msgInput" rows="1" placeholder="Type a message… (Enter to send, Shift+Enter for newline)" onkeydown="handleKey(event)" oninput="autoResize(this)"></textarea>
            <div class="chat-input-actions">
              <label class="icon-btn" title="Attach file" style="cursor:pointer;">
                <i class="fa-solid fa-paperclip"></i>
                <input type="file" style="display:none;" onchange="handleFileAttach(this)">
              </label>
              <div class="icon-btn" title="Emoji" onclick="insertQuickReply('😊')"><i class="fa-regular fa-face-smile"></i></div>
              <button class="send-btn" onclick="sendMessage()" title="Send"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
          </div>
        </div>

      </div><!-- /chat-window -->

    </div><!-- /chat-layout -->
  </div><!-- /main -->
</div><!-- /wrapper -->

<!-- ════════════ CONTRACT INFO MODAL ════════════ -->
<div class="modal-backdrop hidden" id="contractInfoModal">
  <div class="modal" style="max-width:480px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-file-contract text-accent"></i> &nbsp;Contract #54 — React Job</span>
      <button class="icon-btn" onclick="closeModal('contractInfoModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">Status</div><div class="font-bold mt-1"><span class="badge badge-success">Signed</span></div></div>
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">Payment Terms</div><div class="font-bold mt-1 text-sm">PayPal</div></div>
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">Start Date</div><div class="font-bold mt-1 text-sm">Apr 13, 2026</div></div>
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">End Date</div><div class="font-bold mt-1 text-sm">Apr 28, 2026</div></div>
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">Total Value</div><div class="font-bold mt-1 text-accent">$1,250</div></div>
        <div style="background:var(--bg3);border-radius:8px;padding:12px;"><div class="text-muted text-sm">Escrow</div><div class="font-bold mt-1 text-success">$750 locked</div></div>
      </div>
      <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);margin-bottom:10px;">Milestones</div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <div style="display:flex;align-items:center;gap:10px;background:var(--bg3);border-radius:8px;padding:10px 14px;">
          <i class="fa-solid fa-check text-success"></i>
          <div style="flex:1;font-size:13px;">Phase 1 — Setup</div>
          <span class="badge badge-success">Paid $500</span>
        </div>
        <div style="display:flex;align-items:center;gap:10px;background:var(--bg3);border-radius:8px;padding:10px 14px;border:1px solid rgba(0,229,192,.2);">
          <i class="fa-solid fa-spinner fa-spin text-accent" style="font-size:11px;"></i>
          <div style="flex:1;font-size:13px;">Phase 2 — Core Components</div>
          <span class="badge badge-info">$750 pending</span>
        </div>
        <div style="display:flex;align-items:center;gap:10px;background:var(--bg3);border-radius:8px;padding:10px 14px;opacity:.5;">
          <i class="fa-solid fa-lock text-muted" style="font-size:11px;"></i>
          <div style="flex:1;font-size:13px;">Phase 3 — Testing</div>
          <span class="badge badge-muted">$0 locked</span>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('contractInfoModal')">Close</button>
      <button class="btn btn-primary btn-sm" onclick="closeModal('contractInfoModal');showToast('Viewing full contract…')">
        <i class="fa-solid fa-external-link"></i> Full Contract
      </button>
    </div>
  </div>
</div>

<!-- Dispute Modal -->
<div class="modal-backdrop hidden" id="disputeModal">
  <div class="modal" style="max-width:520px;">
    <div class="modal-header">
      <span class="modal-title"><i class="fa-solid fa-triangle-exclamation text-danger"></i> &nbsp;Open Dispute</span>
      <button class="icon-btn" onclick="closeModal('disputeModal')"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <div class="form-group"><label class="form-label">Contract</label>
        <select class="form-control"><option>Contract #54 — React Job (Ali Morsy)</option></select></div>
      <div class="form-group"><label class="form-label">Reason</label>
        <textarea class="form-control" placeholder="Describe the issue in detail…"></textarea></div>
      <div class="form-group"><label class="form-label">Upload Evidence (FR25)</label>
        <input type="file" class="form-control" multiple></div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary btn-sm" onclick="closeModal('disputeModal')">Cancel</button>
      <button class="btn btn-danger btn-sm" onclick="closeModal('disputeModal');showToast('Dispute filed. Admin assigned.','warn')">
        <i class="fa-solid fa-flag"></i> File Dispute
      </button>
    </div>
  </div>
</div>

<div id="toast-container"></div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/chat-sidebar.js"></script>
<script>
// ── Conversations data ────────────────────────────────────────────
const convData = {
  1:{name:'Ali Morsy', sub:'<i class="fa-solid fa-circle" style="color:var(--success);font-size:8px;"></i> Online &nbsp;·&nbsp; React Job — Contract #54', gradient:'135deg,#22c55e,#00e5c0', initials:'AM', restricted:false, contractBar:true},
  2:{name:'Sara Hassan', sub:'Offline &nbsp;·&nbsp; UI Design — Contract #55', gradient:'135deg,#f59e0b,#ef4444', initials:'SH', restricted:false, contractBar:false},
  3:{name:'Admin — Dispute #001', sub:'<i class="fa-solid fa-lock" style="color:var(--danger);font-size:10px;"></i> Restricted Channel (FR27)', gradient:'135deg,#ef4444,#f59e0b', initials:'⚖', restricted:true, contractBar:false},
  4:{name:'Karim Omar', sub:'Online &nbsp;·&nbsp; Node API — Proposal', gradient:'135deg,#6c63ff,#00e5c0', initials:'KO', restricted:false, contractBar:false},
  5:{name:'Nour Nabil', sub:'Offline &nbsp;·&nbsp; Data Pipeline — Proposal', gradient:'135deg,#00e5c0,#6c63ff', initials:'NN', restricted:false, contractBar:false},
};

// conversation messages per ID
const convMsgs = {
  2:[
    {from:'theirs',text:"Hey! I've completed the wireframes for the homepage. Let me share the Figma link.",time:'Yesterday 2:30 PM'},
    {from:'mine',text:'Great! Please also include the mobile responsive versions.',time:'Yesterday 3:05 PM',read:true},
    {from:'theirs',text:'Of course! I\'ll update the Figma by end of day.',time:'Yesterday 4:00 PM'},
    {from:'mine',text:'Can you send the revised wireframes?',time:'2h ago',read:true},
  ],
  3:[
    {from:'system',text:'This is a restricted dispute channel. Communication is monitored by an admin. (FR27)'},
    {from:'theirs',text:'I have uploaded the project timeline and contract as evidence.',time:'3h ago',name:'Admin (MrLio)'},
    {from:'mine',text:"I've submitted my evidence as well. The delay was due to an approved extension.",time:'2h ago',read:true},
    {from:'theirs',text:'Both parties upload all remaining evidence by Apr 25. (FR25)',time:'1h ago',name:'Admin (MrLio)'},
  ],
  4:[
    {from:'theirs',text:"Hi! I saw your Node.js API job post. I'd love to apply — I have 4 years of backend experience.",time:'Yesterday'},
    {from:'mine',text:"Sounds great! I'll review your proposal shortly.",time:'Yesterday',read:true},
    {from:'theirs',text:'Sounds good, I can start Monday.',time:'Yesterday',read:false},
  ],
  5:[
    {from:'theirs',text:"Hello! I submitted a proposal for your data pipeline project. I'm a senior data engineer with 6 years of experience.",time:'2 days ago'},
    {from:'mine',text:"Thanks! I'll take a look.",time:'2 days ago',read:true},
    {from:'theirs',text:"Thank you for the opportunity!",time:'2 days ago'},
  ],
};

function openConversation(id) {
  // Mark active
  document.querySelectorAll('.conv-item').forEach(item => {
    item.classList.toggle('active', parseInt(item.dataset.id)===id);
  });
  // Remove unread badge
  const item = document.querySelector(`.conv-item[data-id="${id}"]`);
  const badge = item?.querySelector('.conv-unread');
  if(badge) badge.remove();

  const c = convData[id]; if(!c) return;

  // Update header
  document.getElementById('chatName').textContent = c.name;
  document.getElementById('chatSub').innerHTML = c.sub;
  document.querySelector('.chat-header .avatar').style.background = `linear-gradient(${c.gradient})`;
  document.querySelector('.chat-header .avatar').textContent = c.initials;

  // Show/hide contract bar
  document.getElementById('contractBar').style.display = c.contractBar ? '' : 'none';

  // Restricted banner
  let banner = document.getElementById('restrictedBanner');
  if(c.restricted) {
    if(!banner) {
      banner = document.createElement('div');
      banner.id = 'restrictedBanner';
      banner.className = 'restricted-banner';
      banner.innerHTML = '<i class="fa-solid fa-lock"></i> This is a restricted dispute channel monitored by an admin. Keep communication professional and factual. (FR27)';
      document.getElementById('chatHeader').after(banner);
    }
    banner.style.display = '';
    document.getElementById('quickReplies').style.display = 'none';
  } else {
    if(banner) banner.style.display = 'none';
    document.getElementById('quickReplies').style.display = '';
  }

  // Render messages
  if(convMsgs[id]) renderMessages(convMsgs[id], c);
}

function renderMessages(msgs, c) {
  const area = document.getElementById('messagesArea');
  area.innerHTML = '<div class="date-sep">Previous messages</div>';
  msgs.forEach(m => {
    if(m.from === 'system') {
      const el = document.createElement('div');
      el.className = 'msg-system';
      el.textContent = m.text;
      area.appendChild(el);
      return;
    }
    const group = document.createElement('div');
    group.className = `msg-group ${m.from}`;
    const row = document.createElement('div');
    row.className = 'msg-row';
    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    bubble.textContent = m.text;
    const meta = document.createElement('div');
    meta.className = 'msg-meta';
    meta.style.textAlign = m.from==='mine' ? 'right' : 'left';
    meta.innerHTML = `${m.name||( m.from==='mine'?'You':c.name)} &nbsp;·&nbsp; ${m.time||'Now'} ${m.from==='mine'?'&nbsp;<i class="fa-solid fa-check-double" style="color:var(--accent);font-size:10px;"></i>':''}`;
    const wrap = document.createElement('div');
    wrap.appendChild(bubble);
    wrap.appendChild(meta);
    if(m.from==='theirs') {
      const av = document.createElement('div');
      av.className='avatar msg-avatar';
      av.style.background=`linear-gradient(${c.gradient})`;
      av.textContent=c.initials;
      row.appendChild(av);
    }
    row.appendChild(wrap);
    group.appendChild(row);
    area.appendChild(group);
  });
  area.scrollTop = area.scrollHeight;
}

function sendMessage() {
  const input = document.getElementById('msgInput');
  const text = input.value.trim();
  if(!text) return;
  const area = document.getElementById('messagesArea');
  const group = document.createElement('div');
  group.className = 'msg-group mine';
  group.innerHTML = `<div class="msg-row"><div><div class="msg-bubble">${text}</div><div class="msg-meta" style="text-align:right;">You &nbsp;·&nbsp; Just now &nbsp;<i class="fa-solid fa-check" style="color:var(--accent);font-size:10px;"></i></div></div></div>`;
  area.appendChild(group);
  input.value = '';
  input.style.height = '';
  area.scrollTop = area.scrollHeight;
  // Simulate reply
  setTimeout(() => {
    const replies = ['Got it, thanks!','I\'ll look into that right away.','Sure, will update you shortly.','Thanks for the feedback! Working on it now.'];
    const activeConv = document.querySelector('.conv-item.active');
    if(!activeConv) return;
    const id = parseInt(activeConv.dataset.id);
    const c = convData[id];
    if(!c || c.restricted) return;
    const rep = document.createElement('div');
    rep.className='msg-group theirs';
    rep.innerHTML=`<div class="msg-row"><div class="avatar msg-avatar" style="background:linear-gradient(${c.gradient});">${c.initials}</div><div><div class="msg-bubble">${replies[Math.floor(Math.random()*replies.length)]}</div><div class="msg-meta">${c.name} &nbsp;·&nbsp; Just now</div></div></div>`;
    area.appendChild(rep);
    area.scrollTop = area.scrollHeight;
  }, 1500 + Math.random()*1000);
}

function handleKey(e) {
  if(e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
  el.style.height=''; el.style.height = Math.min(el.scrollHeight, 120)+'px';
}

function insertQuickReply(text) {
  const input = document.getElementById('msgInput');
  input.value = text;
  input.focus();
  input.style.height=''; input.style.height = Math.min(input.scrollHeight,120)+'px';
}

function handleFileAttach(input) {
  if(!input.files.length) return;
  const file = input.files[0];
  const area = document.getElementById('messagesArea');
  const group = document.createElement('div');
  group.className='msg-group mine';
  group.innerHTML=`<div class="msg-row"><div><div class="msg-file" style="max-width:260px;"><i class="fa-solid fa-paperclip" style="font-size:18px;color:var(--accent);"></i><div><div style="font-size:12px;font-weight:600;">${file.name}</div><div style="font-size:11px;color:var(--muted);">${(file.size/1024).toFixed(1)} KB &nbsp;·&nbsp; Uploading…</div></div></div><div class="msg-meta" style="text-align:right;">You &nbsp;·&nbsp; Just now</div></div></div>`;
  area.appendChild(group);
  area.scrollTop = area.scrollHeight;
  setTimeout(()=>{ showToast(`${file.name} uploaded successfully!`); }, 1200);
}

function filterConvs(q) {
  document.querySelectorAll('.conv-item').forEach(item => {
    item.style.display = item.dataset.name.includes(q.toLowerCase()) ? '' : 'none';
  });
}

function switchTab(btn, tab) {
  document.querySelectorAll('.conv-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.conv-item').forEach(item => {
    if(tab==='all') item.style.display='';
    else if(tab==='unread') item.style.display = item.querySelector('.conv-unread') ? '' : 'none';
    else if(tab==='dispute') item.style.display = (item.dataset.id === '3') ? '' : 'none';
  });
}

function openDisputeFlow() { openModal('disputeModal'); }

// Start with conv 1 active
document.addEventListener('DOMContentLoaded', () => {
  // conv 1 is already shown in HTML, just scroll messages
  document.getElementById('messagesArea').scrollTop = document.getElementById('messagesArea').scrollHeight;
});
</script>
</body>
</html>