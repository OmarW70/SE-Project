# Admin Dashboard Restructuring - Complete Documentation

## Overview
The admin dashboard has been completely restructured into a single-page interface with:
- **Restricted Channels**: One-page view of all active dispute channels
- **Right Sidebar Messages**: Conversation list that slides in from the right (Facebook-style)
- **Bottom Chat Box**: Small chat window at the bottom for individual conversations
- **Penalty System**: Integrated penalty application with notifications

---

## Database Schema Changes

### New Tables Added

#### `disputes` Table
- Tracks all open disputes between clients and freelancers
- Fields: dispute_id, contract_id, client_id, freelancer_id, title, status, created_at, resolved_at

#### `restricted_channels` Table
- Restricted communication channels for each dispute
- Fields: channel_id, dispute_id, channel_name, is_active, created_at
- Visible only to involved parties and admin

#### `channel_members` Table
- Links users to restricted channels
- Fields: member_id, channel_id, user_id, joined_at

#### `channel_messages` Table
- Messages within restricted channels
- Fields: message_id, channel_id, user_id, message_text, created_at
- All messages are logged and visible to admin only

#### `penalties` Table
- Records of all penalties applied to users
- Fields: penalty_id, user_id, dispute_id, penalty_type, reason, applied_by, created_at
- Penalty types: warning, limited_access, permanent_ban

#### `notifications` Table
- User notifications for disputes, penalties, and messages
- Fields: notification_id, user_id, type, message, related_id, is_read, created_at
- Types: dispute_opened, penalty_warning, penalty_limited, penalty_banned, message, admin_message

### Updated Tables

#### `users` Table
- Added fields:
  - `account_status` (active, limited_access, banned)
  - `penalty_type` (none, warning, limited_access, permanent_ban)
  - `penalty_reason` (text description of penalty)
  - `penalty_applied_at` (timestamp)

---

## UI/UX Features

### 1. Single-Page Layout
- **No tabs**: Removed Overview, Penalties, and Notifications tabs
- **Restricted Channels**: Now the main content area
- **Always visible**: Shows all active dispute channels

### 2. Right Sidebar (Messages)
- Slides in from the right side when the "Messages" button is clicked
- Displays list of all conversations with:
  - Participant avatars
  - Conversation names (e.g., "Omar Khalil & Sara Medhat")
  - Last message timestamp
- Clickable items open the chat in the bottom box
- Can be closed with X button or by clicking outside

### 3. Bottom Chat Box
- Fixed position at bottom-right of screen
- Shows expanded chat conversation
- Features:
  - Header with conversation title and close button
  - Message display area with scrolling
  - Text input area with send button
  - Responsive design (adjusts on mobile)

### 4. Penalty Application
- Click on any user's name/avatar in a dispute channel
- Dropdown appears with three penalty options:
  1. **Warning** - Formal notice, no access restriction
  2. **Limited Access** - Client cannot post jobs or accept proposals; Freelancer cannot submit proposals
  3. **Permanent Ban** - Account completely deactivated, user cannot log in
- Admin must provide reason
- User gets notified immediately

---

## Penalty System Behavior

### Warning Penalty
- User receives notification in their Notifications section
- No functionality restrictions
- User can still create/accept contracts and proposals
- Shows warning message in notifications

### Limited Access Penalty
- User receives notification
- Client: Cannot create new job posts or accept proposals
- Freelancer: Cannot submit new proposals
- Account remains active but with restrictions
- Restrictions appear when checking their account status

### Permanent Ban
- User receives notification
- Account status set to "banned"
- User cannot log in
- All account functionality is blocked
- "Account disabled" message on login attempt

---

## Database Models

### UserModel.php (Updated)
New methods added:
- `applyPenalty($user_id, $penalty_type, $reason, $dispute_id, $applied_by)` - Apply a penalty to a user
- `getUserStatus($user_id)` - Get current account status and penalty info
- `isBanned($user_id)` - Check if user is permanently banned
- `hasLimitedAccess($user_id)` - Check if user has limited access
- `getLastPenalty($user_id)` - Get the most recent penalty

### DisputeModel.php (New)
Complete model for managing disputes and channels:
- `createDispute()` - Create new dispute
- `getOpenDisputes()` - Get all active disputes
- `getDisputeById()` - Get specific dispute details
- `createRestrictedChannel()` - Create channel for dispute
- `addChannelMember()` - Add user to channel
- `getChannelMessages()` - Get all messages in channel
- `addChannelMessage()` - Add message to channel
- `createNotification()` - Create user notification
- `getUserNotifications()` - Get user's notifications
- `getPenaltyDetails()` - Get penalty information
- `closeDispute()` - Resolve dispute
- `closeChannel()` - Close restricted channel

---

## Admin Dashboard File Structure

### File: `views/admin_dashboard.php`

#### Key Sections:
1. **PHP Backend** (Lines 1-85)
   - Session handling
   - User authentication
   - Form processing for user creation/deletion

2. **CSS Styling** (Lines 100-800)
   - Dark theme with teal/cyan accents
   - Sidebar styling
   - Chat box styling
   - Penalty dropdown styling
   - Responsive breakpoints

3. **HTML Content** (Lines 800-1200)
   - Top navigation bar with controls
   - Main content area with channels
   - Right sidebar for messages
   - Bottom chat box
   - Penalty dropdown
   - User management popups

4. **JavaScript** (Lines 1200-1500)
   - Sidebar toggle/close
   - Chat box open/close
   - Message sending
   - Penalty dropdown functionality
   - Channel chat toggle
   - Admin message sending
   - Popup management
   - Toast notifications

---

## How to Use the New Dashboard

### For Admin:

1. **View Disputes**
   - All active disputes show automatically on the main page
   - Each dispute is a "Restricted Channel"

2. **Send Messages to Both Parties**
   - Click the chevron to expand a channel
   - Type message in the text area at bottom
   - Message appears for both client and freelancer

3. **Apply Penalties**
   - Click on the client's or freelancer's name/avatar
   - Select penalty type (Warning, Limited Access, or Ban)
   - Add optional reason
   - Click "Apply & Notify User"
   - User immediately receives notification

4. **Check Conversations**
   - Click "Messages" button in top-right
   - Sidebar opens showing all conversation participants
   - Click a conversation to see detailed chat
   - Can send additional messages in bottom chat box

5. **Manage Users**
   - "Add User" button: Create new client/freelancer/admin accounts
   - "Remove User" button: Permanently delete user accounts (irreversible)

---

## Security Features

1. **Restricted Channels**: Only visible to involved parties + admin
2. **Admin Identity**: Admin messages clearly marked with crown icon
3. **Message Logging**: All messages are logged in database
4. **Penalty Audit Trail**: All penalties recorded with admin ID, reason, and timestamp
5. **Account Status Checking**: System can prevent restricted actions based on penalty type

---

## Implementation Notes

- The dashboard is fully functional with mock data
- Database integration ready (just connect via Database.php)
- All JavaScript is vanilla (no jQuery dependencies)
- Dark theme optimized for long admin sessions
- Mobile responsive (sidebar/chat box adapt on smaller screens)

---

## Next Steps (Optional Enhancements)

1. Connect to actual database using DisputeModel
2. Add search/filter for disputes by user or status
3. Add batch penalty application
4. Add dispute resolution workflow
5. Add admin audit logs
6. Add email notifications to users about penalties
7. Add penalty appeal workflow
8. Add dispute statistics/analytics dashboard
