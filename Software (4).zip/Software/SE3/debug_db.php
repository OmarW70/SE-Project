<?php
require_once 'config/config.php';
require_once 'models/Database.php';

try {
    $db = Database::getInstance();
    
    echo "Checking tables...\n";
    $tables = ['users', 'roles', 'jobs', 'proposals', 'contracts'];
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "Table '$table' exists.\n";
            $count = $db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
            echo "Total records in '$table': $count\n";
        } else {
            echo "Table '$table' DOES NOT exist!\n";
        }
    }
    
    echo "\nChecking recent contracts...\n";
    $stmt = $db->query("SELECT * FROM contracts ORDER BY created_at DESC LIMIT 5");
    $contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($contracts)) {
        echo "No contracts found in database.\n";
    } else {
        foreach ($contracts as $c) {
            print_r($c);
        }
    }

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
