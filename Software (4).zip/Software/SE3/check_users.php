<?php
// اتصل بقاعدة البيانات
$conn = new PDO('mysql:host=localhost;dbname=freelance_platform', 'root', '');

// استعلام لعرض جميع المستخدمين
$stmt = $conn->prepare("SELECT * FROM users");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>";
echo "عدد المستخدمين: " . count($users) . "\n\n";
print_r($users);
echo "</pre>";
?>
