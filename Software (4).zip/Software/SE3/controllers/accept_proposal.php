<?php
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/ProposalModel.php';
require_once '../models/ContractModel.php';
require_once '../models/JobModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$proposal_id = $_POST['proposal_id'] ?? null;

if (!$proposal_id) {
    echo json_encode(['success' => false, 'error' => 'Missing proposal ID']);
    exit();
}

$proposalModel = new ProposalModel();
$contractModel = new ContractModel();
$db = Database::getInstance();

try {
    $db->beginTransaction();

    $proposal = $proposalModel->getProposalById($proposal_id);
    if (!$proposal) {
        throw new Exception("Proposal not found (ID: $proposal_id)");
    }

    // 1. Accept this proposal
    if (!$proposalModel->updateStatus($proposal_id, 'accepted')) {
        throw new Exception("Failed to update proposal status");
    }

    // 2. Reject other proposals for the same job
    $stmt = $db->prepare("UPDATE proposals SET status = 'rejected' WHERE job_id = ? AND proposal_id != ?");
    $stmt->execute([$proposal['job_id'], $proposal_id]);

    // 3. Update job status to in_progress
    $stmt = $db->prepare("UPDATE jobs SET status = 'in_progress' WHERE job_id = ?");
    $stmt->execute([$proposal['job_id']]);

    // 4. Create Contract
    // Need client_id from job
    $stmt = $db->prepare("SELECT client_id FROM jobs WHERE job_id = ?");
    $stmt->execute([$proposal['job_id']]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job) {
        throw new Exception("Job not found for this proposal");
    }

    // Verify current user is the owner of the job
    if ($job['client_id'] != $_SESSION['user_id']) {
        throw new Exception("Unauthorized: You do not own this job");
    }

    $result = $contractModel->createContract(
        $proposal['job_id'],
        $job['client_id'],
        $proposal['freelancer_id'],
        $proposal_id,
        $proposal['bid_amount']
    );

    if (!$result) {
        $errorInfo = $db->errorInfo();
        throw new Exception("Failed to create contract: " . ($errorInfo[2] ?? "Unknown DB error"));
    }

    $db->commit();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    $db->rollBack();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
