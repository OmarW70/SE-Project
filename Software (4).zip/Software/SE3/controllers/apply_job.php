<?php
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/ProposalModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$freelancer_id = $_SESSION['user_id'];
$job_id        = $_POST['job_id'] ?? null;
$bid_amount    = $_POST['bid'] ?? null;
$delivery_time = $_POST['delivery_time'] ?? null;
$cover_letter  = $_POST['cover_letter'] ?? null;

// Debugging: return which field is missing if needed
if (!$job_id || !$bid_amount || !$delivery_time || !$cover_letter) {
    $missing = [];
    if (!$job_id) $missing[] = 'job_id';
    if (!$bid_amount) $missing[] = 'bid';
    if (!$delivery_time) $missing[] = 'delivery_time';
    if (!$cover_letter) $missing[] = 'cover_letter';
    
    echo json_encode([
        'success' => false, 
        'error' => 'All fields are required: ' . implode(', ', $missing)
    ]);
    exit();
}

$proposalModel = new ProposalModel();
$result = $proposalModel->createProposal($job_id, $freelancer_id, $bid_amount, $delivery_time, $cover_letter);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Database error']);
}
?>
