<?php
// post_job.php — Controller لإضافة Job جديدة

require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/JobModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../views/index.php?mode=login");
    exit();
}



$client_id   = $_SESSION['user_id'];
$title       = trim($_POST['title']       ?? '');
$description = trim($_POST['description'] ?? '');
$category    = trim($_POST['category']    ?? '');
$budget      = floatval($_POST['budget']  ?? 0);

// تحقق من البيانات
if (empty($title) || empty($description) || empty($category) || $budget <= 0) {
    header("Location: ../views/client_dashboard.php?job_error=empty_fields&tab=jobs#jobs");
    exit();
}

$jobModel = new JobModel();
$result   = $jobModel->createJob($client_id, $title, $description, $category, $budget);

if ($result['success']) {
    header("Location: ../views/client_dashboard.php?job_msg=posted&tab=jobs#jobs");
} else {
    header("Location: ../views/client_dashboard.php?job_error=failed&tab=jobs#jobs");
}
exit();
?>
