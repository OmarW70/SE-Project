<?php
// apply_penalty.php - Handle penalty application by admin

require_once '../models/Database.php';
require_once '../models/PenaltyModel.php';
require_once '../models/UserModel.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 3) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid request data']);
    exit();
}

$user_id = $data['user_id'] ?? 0;
$penalty_type = $data['penalty_type'] ?? '';
$reason = $data['reason'] ?? '';
$dispute_id = $data['dispute_id'] ?? 0;

// Validate required fields
if (empty($user_id) || empty($penalty_type) || empty($reason) || empty($dispute_id)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

// Validate penalty type
$valid_penalties = ['warning', 'limited_access', 'permanent_ban'];
if (!in_array($penalty_type, $valid_penalties)) {
    echo json_encode(['success' => false, 'message' => 'Invalid penalty type']);
    exit();
}

try {
    $penaltyModel = new PenaltyModel();
    $userModel = new UserModel();
    
    // Check if user exists
    $user = $userModel->getUserById($user_id);
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit();
    }
    
    // Check if user is admin (cannot penalize admin)
    if ($user['role_id'] == 3) {
        echo json_encode(['success' => false, 'message' => 'Cannot penalize admin users']);
        exit();
    }
    
    // Apply the penalty
    $applied_by = $_SESSION['user_id'];
    $success = $penaltyModel->applyPenalty($user_id, $penalty_type, $reason, $dispute_id, $applied_by);
    
    if ($success) {
        // Get penalty details for response
        $penalty_details = $penaltyModel->getUserPenaltyDetails($user_id);
        
        echo json_encode([
            'success' => true,
            'message' => 'Penalty applied successfully',
            'penalty' => [
                'type' => $penalty_type,
                'reason' => $reason,
                'applied_at' => $penalty_details['penalty_applied_at'],
                'user_name' => $user['first_name'] . ' ' . $user['last_name'],
                'user_role' => $user['role_id'] == 1 ? 'Client' : 'Freelancer'
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to apply penalty']);
    }
    
} catch (Exception $e) {
    error_log("Error applying penalty: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while applying the penalty']);
}
?>