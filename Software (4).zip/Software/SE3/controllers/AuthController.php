<?php
// استدعاء الملفات الضرورية
// 2. ملف الـ Database لازم يتحمل قبل أي موديول تاني عشان الكل يشوفه ✅
require_once '../models/Database.php'; 

// 1. ملف الإعدادات الأول
require_once '../config/config.php'; 

// 3. باقي الموديلات والـ Factory
require_once '../models/UserModel.php';
require_once '../factories/UserFactory.php';

class AuthController {
    // 1. وظيفة التسجيل (Register)
    public function register($data) {
        $userModel = new UserModel();
        // بنبعت الداتا للموديل عشان يحفظها
        $first_name = $data['first_name'] ?? '';
        $last_name = $data['last_name'] ?? '';
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';
        $role_id = $data['role_id'] ?? 1;
        
        // تحقق من صحة البيانات
        if (strlen($password) < 8) {
            header("Location: ../views/index.php?mode=signup&error=password_too_short");
            exit();
        }
        
        $success = $userModel->register($first_name, $last_name, $email, $password, $role_id);
        
        if ($success) {
            // لو نجح، يوديك لصفحة اللوجن
            header("Location: ../views/index.php?mode=login&msg=registered&email=" . urlencode($email));
            exit();
        } else {
            // قد تكون هناك مشكلة في البريد الإلكتروني موجود مسبقاً أو مشكلة أخرى
            header("Location: ../views/index.php?mode=signup&error=registration_failed&email=" . urlencode($email));
            exit();
        }
    }

    // 2. وظيفة الدخول (Login)
    public function login($email, $password) {
        $userModel = new UserModel();
        // جلب بيانات المستخدم بناءً على الإيميل من الداتا بيز
        $user = $userModel->getUserByEmail($email);

        // التحقق: هل اليوزر موجود؟ وهل الباسورد المدخل يطابق الـ Hash المتخزن؟
        if ($user && password_verify($password, $user['password'])) {
            
            // في حالة نجاح البيانات، نبدأ الجلسة
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            
            // تخزين بيانات اليوزر في الـ Session
            $_SESSION['user_id'] = $user['user_id']; 
            $_SESSION['role_id'] = $user['role_id'];

            // تحديد المسار الصحيح باستخدام الـ Factory
            $redirectPath = UserFactory::create($user);
            
            // التوجيه للمسار المحدد (مثلاً freelancer/dashboard.php)
            header("Location: ../views/" . $redirectPath);
            exit(); // سطر إجباري لضمان توقف السكريبت هنا
        } else {
            // في حالة البيانات غلط، يرجعه لصفحة اللوجن مع إشارة للخطأ
            header("Location: ../views/index.php?mode=login&error=invalid_credentials");
            exit(); 
        }
    }
}

// الجزء ده هو اللي بيستقبل الإشارة من الفورم (Routing)
// بدء الجلسة إذا لم تكن بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// تسجيل جميع الطلبات للـ debug
error_log("=== AuthController Request ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Action: " . ($_GET['action'] ?? 'not set'));
error_log("POST data: " . json_encode($_POST));

// التحقق من أن الطلب هو POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action'])) {
    $auth = new AuthController();
    
    if ($_GET['action'] == 'register') {
        error_log("Processing registration...");
        // التحقق من وجود جميع البيانات المطلوبة
        $required_fields = ['first_name', 'last_name', 'email', 'password', 'role_id'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        // Debug: تسجيل البيانات المستقبلة
        error_log("Register request received with data: " . json_encode($_POST));
        
        if (!empty($missing_fields)) {
            error_log("Missing fields: " . implode(', ', $missing_fields));
            header("Location: ../views/index.php?mode=signup&error=missing_fields");
            exit();
        }
        
        $auth->register($_POST); // بياخد كل بيانات الـ Register من الفورم
    } 
    elseif ($_GET['action'] == 'login') {
        error_log("Processing login...");
        if (empty($_POST['email']) || empty($_POST['password'])) {
            header("Location: ../views/index.php?mode=login&error=missing_credentials");
            exit();
        }
        $auth->login($_POST['email'], $_POST['password']);
    }
}
else {
    // Debug: إذا لم يكن POST أو لا توجد action
    error_log("Invalid request - Method: " . $_SERVER['REQUEST_METHOD'] . ", Action: " . ($_GET['action'] ?? 'not set'));
}