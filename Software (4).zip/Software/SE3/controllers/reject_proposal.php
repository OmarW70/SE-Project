<?php
require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/ProposalModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$proposal_id = $_POST['proposal_id'] ?? null;

if (!$proposal_id) {
    echo json_encode(['success' => false, 'error' => 'Missing proposal ID']);
    exit();
}

$proposalModel = new ProposalModel();
$db = Database::getInstance();

try {
    $proposal = $proposalModel->getProposalById($proposal_id);
    if (!$proposal) {
        throw new Exception("Proposal not found");
    }

    // Verify ownership through job
    $stmt = $db->prepare("SELECT client_id FROM jobs WHERE job_id = ?");
    $stmt->execute([$proposal['job_id']]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job || $job['client_id'] != $_SESSION['user_id']) {
        throw new Exception("Unauthorized: You do not own this job");
    }

    if ($proposalModel->updateStatus($proposal_id, 'rejected')) {
        echo json_encode(['success' => true]);
    } else {
        throw new Exception("Failed to update status in database");
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
