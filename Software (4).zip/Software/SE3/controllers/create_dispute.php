<?php
// create_dispute.php - Handle dispute creation and restricted channel setup

require_once '../models/Database.php';
require_once '../models/DisputeModel.php';
require_once '../models/UserModel.php';
require_once '../models/PenaltyModel.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid request data']);
    exit();
}

$contract_id = $data['contract_id'] ?? '';
$title = $data['title'] ?? '';
$description = $data['description'] ?? '';
$other_party_id = $data['other_party_id'] ?? 0;

// Validate required fields
if (empty($contract_id) || empty($title) || empty($description) || empty($other_party_id)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

try {
    $db = Database::getInstance();
    $disputeModel = new DisputeModel();
    $userModel = new UserModel();
    
    $current_user_id = $_SESSION['user_id'];
    $current_user = $userModel->getUserById($current_user_id);
    
    if (!$current_user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit();
    }
    
    // Determine client and freelancer IDs based on current user's role
    if ($current_user['role_id'] == 1) { // Client
        $client_id = $current_user_id;
        $freelancer_id = $other_party_id;
    } else { // Freelancer
        $freelancer_id = $current_user_id;
        $client_id = $other_party_id;
    }
    
    // Check if a dispute already exists for this contract
    $stmt = $db->prepare("SELECT dispute_id FROM disputes WHERE contract_id = ? AND status = 'open'");
    $stmt->execute([$contract_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'An open dispute already exists for this contract']);
        exit();
    }
    
    // Create the dispute
    $dispute_created = $disputeModel->createDispute($client_id, $freelancer_id, $contract_id, $title);
    
    if (!$dispute_created) {
        echo json_encode(['success' => false, 'message' => 'Failed to create dispute']);
        exit();
    }
    
    // Get the created dispute ID
    $dispute_id = $db->lastInsertId();
    
    // Create restricted channel for the dispute
    $channel_name = "Contract $contract_id — $title";
    $channel_id = $disputeModel->createRestrictedChannel($dispute_id, $channel_name);
    
    if (!$channel_id) {
        // Rollback dispute creation if channel creation fails
        $db->prepare("DELETE FROM disputes WHERE dispute_id = ?")->execute([$dispute_id]);
        echo json_encode(['success' => false, 'message' => 'Failed to create restricted channel']);
        exit();
    }
    
    // Add both parties to the restricted channel
    $disputeModel->addChannelMember($channel_id, $client_id);
    $disputeModel->addChannelMember($channel_id, $freelancer_id);
    
    // Add the admin to the channel
    $stmt = $db->prepare("SELECT user_id FROM users WHERE role_id = 3 LIMIT 1");
    $stmt->execute();
    $admin = $stmt->fetch();
    if ($admin) {
        $disputeModel->addChannelMember($channel_id, $admin['user_id']);
    }
    
    // Add initial message to the channel
    $initial_message = "🔒 Restricted dispute channel created.\n\n";
    $initial_message .= "Contract: $contract_id\n";
    $initial_message .= "Issue: $title\n";
    $initial_message .= "Description: $description\n\n";
    $initial_message .= "All parties can now communicate here. Admin will monitor and assist in resolution.";
    
    $disputeModel->addChannelMessage($channel_id, $current_user_id, $initial_message);
    
    // Create notifications for both parties
    $notification_message = "⚠️ New dispute opened for contract $contract_id: $title";
    $disputeModel->createNotification($client_id, 'dispute_opened', $notification_message, $dispute_id);
    $disputeModel->createNotification($freelancer_id, 'dispute_opened', $notification_message, $dispute_id);
    
    // Create notification for admin
    if ($admin) {
        $admin_message = "⚠️ New dispute opened: $title (Contract $contract_id)";
        $disputeModel->createNotification($admin['user_id'], 'dispute_opened', $admin_message, $dispute_id);
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'Dispute created successfully',
        'dispute_id' => $dispute_id,
        'channel_id' => $channel_id
    ]);
    
} catch (Exception $e) {
    error_log("Error creating dispute: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while creating the dispute']);
}
?>