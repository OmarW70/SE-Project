<?php
// update_profile.php — Controller لتحديث بيانات المستخدم

require_once '../models/Database.php';
require_once '../config/config.php';
require_once '../models/UserModel.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التأكد إن المستخدم logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../views/index.php?mode=login&error=not_logged_in");
    exit();
}

// التأكد إن الطلب POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../views/index.php");
    exit();
}

$user_id    = $_SESSION['user_id'];
$first_name = trim($_POST['first_name'] ?? '');
$last_name  = trim($_POST['last_name']  ?? '');
$email      = trim($_POST['email']      ?? '');
$redirect   = $_POST['redirect'] ?? 'freelancer_dashboard.php';

// التحقق من البيانات
if (empty($first_name) || empty($last_name) || empty($email)) {
    header("Location: ../views/{$redirect}?edit_profile_error1=empty_fields#settings");
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../views/{$redirect}?edit_profile_error1=invalid_email#settings");
    exit();
}

$userModel = new UserModel();
$result    = $userModel->updateUser($user_id, $first_name, $last_name, $email);

if ($result['success']) {
    // نحدّث الـ Session بالبيانات الجديدة عشان الصفحة تتحدث فوراً
    $_SESSION['first_name'] = $first_name;
    $_SESSION['last_name']  = $last_name;
    $_SESSION['email']      = $email;

    header("Location: ../views/{$redirect}?edit_profile_success1=updated#settings");
} else {
    $error = $result['error'] === 'email_taken' ? 'email_taken' : 'update_failed';
    header("Location: ../views/{$redirect}?edit_profile_error1={$error}#settings");
}
exit();
?>
