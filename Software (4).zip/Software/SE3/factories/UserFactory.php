<?php
class UserFactory {
    public static function create($user) {
        if ($user['role_id'] == 1) {
            return "../views/client_dashboard.php";
        } elseif ($user['role_id'] == 2) {
            return "../views/freelancer_dashboard.php"; 
        } elseif ($user['role_id'] == 3) {
            return "../views/admin_dashboard.php";
        }
        return "auth/login.php";
    }
}
?>