<?php
/**
 * ملف الإعدادات الأساسية للنظام
 * Basic Configuration File for the System
 */

// منع الوصول المباشر
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__, 2) . DIRECTORY_SEPARATOR);
}

// بيئة التطوير أو الإنتاج
define('ENVIRONMENT', 'development'); // development, production

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'freelance_platform');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATION', 'utf8mb4_unicode_ci');

// إعدادات الأمان
define('SECRET_KEY', 'your-secret-key-here-change-this-in-production');
define('JWT_SECRET', 'your-jwt-secret-key-here-change-this-in-production');
define('ENCRYPTION_KEY', 'your-encryption-key-here-32-chars');
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_NAME', 'freelance_platform_session');

// إعدادات الموقع
define('SITE_NAME', 'منصة العمل الحر');
define('SITE_URL', 'http://localhost/WebProject');
define('ADMIN_EMAIL', 'admin@freelance-platform.com');
define('TIMEZONE', 'Asia/Riyadh');
define('DEFAULT_LANGUAGE', 'ar');

// إعدادات الرفع
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10 ميجابايت
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);
define('UPLOADS_DIR', ABSPATH . 'uploads' . DIRECTORY_SEPARATOR);
define('UPLOADS_URL', SITE_URL . '/uploads/');

// إعدادات البريد الإلكتروني
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', '');
define('SMTP_PASSWORD', '');
define('SMTP_ENCRYPTION', 'tls');
define('SMTP_FROM_EMAIL', 'noreply@freelance-platform.com');
define('SMTP_FROM_NAME', SITE_NAME);

// إعدادات الدفع
define('COMMISSION_PERCENTAGE', 10); // نسبة العمولة
define('MIN_WITHDRAWAL_AMOUNT', 100); // الحد الأدنى للسحب
define('MAX_WITHDRAWAL_AMOUNT', 10000); // الحد الأقصى للسحب
define('WITHDRAWAL_FEE', 5); // رسوم السحب

// إعدادات الجلسات
define('SESSION_LIFETIME', 7200); // ساعتين بالثواني
define('REMEMBER_ME_LIFETIME', 2592000); // 30 يوم بالثواني
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_DURATION', 900); // 15 دقيقة بالثواني

// إعدادات التحقق
define('EMAIL_VERIFICATION_REQUIRED', true);
define('PHONE_VERIFICATION_REQUIRED', false);
define('MIN_PASSWORD_LENGTH', 8);
define('MAX_PASSWORD_LENGTH', 128);

// إعدادات API
define('API_RATE_LIMIT', 100); // عدد الطلبات المسموحة في الدقيقة
define('API_TIMEOUT', 30); // ثواني

// إعدادات التخزين المؤقت
define('CACHE_ENABLED', false);
define('CACHE_DURATION', 3600); // ساعة واحدة

// إعدادات السجلات
define('LOG_ERRORS', true);
define('LOG_LEVEL', 'debug'); // debug, info, warning, error
define('LOG_FILE', ABSPATH . 'logs' . DIRECTORY_SEPARATOR . 'error.log');

// إعدادات SSL
define('FORCE_SSL', false);
define('SSL_PORT', 443);

// إعدادات التواصل الاجتماعي
define('FACEBOOK_URL', '');
define('TWITTER_URL', '');
define('LINKEDIN_URL', '');
define('INSTAGRAM_URL', '');

// إعدادات التوطين
define('CURRENCY', 'SAR');
define('DATE_FORMAT', 'Y-m-d');
define('TIME_FORMAT', 'H:i:s');
define('DATETIME_FORMAT', 'Y-m-d H:i:s');

// إعدادات الأمان الإضافية
define('DISABLE_RIGHT_CLICK', false);
define('DISABLE_INSPECT_ELEMENT', false);
define('ENABLE_2FA', false);
define('PASSWORD_EXPIRY_DAYS', 90);

// إعدادات الأداء
define('ENABLE_COMPRESSION', true);
define('ENABLE_MINIFICATION', false);
define('CDN_ENABLED', false);
define('CDN_URL', '');

// إعدادات الصيانة
define('MAINTENANCE_MODE', false);
define('MAINTENANCE_MESSAGE', 'الموقع تحت الصيانة، سنعود قريباً');
define('MAINTENANCE_ALLOW_IPS', ['127.0.0.1', '::1']);

// إعدادات التطوير
define('DEBUG_MODE', ENVIRONMENT === 'development');
define('DISPLAY_ERRORS', DEBUG_MODE);
define('ERROR_REPORTING', DEBUG_MODE ? E_ALL : E_ERROR);
define('ENABLE_PROFILER', DEBUG_MODE);

// إعدادات قاعدة البيانات للتطوير
if (ENVIRONMENT === 'development') {
    define('DB_DEBUG', true);
    define('DB_LOG_QUERIES', true);
} else {
    define('DB_DEBUG', false);
    define('DB_LOG_QUERIES', false);
}

// دالة للحصول على الإعدادات من قاعدة البيانات
function getSetting($key, $default = null) {
    static $settings = null;
    
    if ($settings === null) {
        $settings = [];
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("SELECT key_name, value, type FROM settings");
            $stmt->execute();
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $value = $row['value'];
                switch ($row['type']) {
                    case 'integer':
                        $value = (int)$value;
                        break;
                    case 'boolean':
                        $value = $value === 'true' || $value === '1';
                        break;
                    case 'json':
                        $value = json_decode($value, true);
                        break;
                }
                $settings[$row['key_name']] = $value;
            }
        } catch (Exception $e) {
            // في حال عدم وجود جدول الإعدادات
        }
    }
    
    return $settings[$key] ?? $default;
}

// دالة لتحديث الإعدادات
define('SETTINGS', [
    'site_name' => getSetting('site_name', SITE_NAME),
    'site_description' => getSetting('site_description', 'أكبر منصة عربية للعمل الحر'),
    'site_logo' => getSetting('site_logo', '/assets/images/logo.png'),
    'maintenance_mode' => getSetting('maintenance_mode', MAINTENANCE_MODE),
    'registration_enabled' => getSetting('registration_enabled', true),
    'email_verification_required' => getSetting('email_verification_required', EMAIL_VERIFICATION_REQUIRED),
    'max_login_attempts' => getSetting('max_login_attempts', MAX_LOGIN_ATTEMPTS),
    'lockout_duration' => getSetting('lockout_duration', LOCKOUT_DURATION),
    'session_lifetime' => getSetting('session_lifetime', SESSION_LIFETIME),
    'password_min_length' => getSetting('password_min_length', MIN_PASSWORD_LENGTH),
    'currency' => getSetting('currency', CURRENCY),
    'commission_percentage' => getSetting('commission_percentage', COMMISSION_PERCENTAGE),
    'min_withdrawal_amount' => getSetting('min_withdrawal_amount', MIN_WITHDRAWAL_AMOUNT),
    'max_file_size' => getSetting('max_file_size', MAX_FILE_SIZE),
    'allowed_file_types' => getSetting('allowed_file_types', ALLOWED_FILE_TYPES),
    'contact_email' => getSetting('contact_email', ADMIN_EMAIL),
    'facebook_url' => getSetting('facebook_url', FACEBOOK_URL),
    'twitter_url' => getSetting('twitter_url', TWITTER_URL),
    'linkedin_url' => getSetting('linkedin_url', LINKEDIN_URL),
    'instagram_url' => getSetting('instagram_url', INSTAGRAM_URL),
]);

// تعيين المنطقة الزمنية
date_default_timezone_set(TIMEZONE);

// إعدادات PHP
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
ini_set('session.cookie_lifetime', SESSION_LIFETIME);
ini_set('session.name', SESSION_NAME);
ini_set('session.use_strict_mode', 1);
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', FORCE_SSL);
ini_set('session.cookie_samesite', 'Strict');

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
}

// إعدادات الأمان الإضافية
ini_set('expose_php', 0);
ini_set('session.cookie_httponly', 1);
ini_set('allow_url_fopen', 0);
ini_set('allow_url_include', 0);

// دالة للتحقق من صحة عنوان IP
define('VALID_IP_PATTERN', '/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/');

// دالة للتحقق من صحة البريد الإلكتروني
define('VALID_EMAIL_PATTERN', '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/');

// دالة للتحقق من صحة رقم الهاتف
define('VALID_PHONE_PATTERN', '/^[0-9]{10,15}$/');

// دالة للتحقق من صحة اسم المستخدم
define('VALID_USERNAME_PATTERN', '/^[a-zA-Z0-9_]{3,20}$/');

// دالة للتحقق من صحة كلمة المرور
define('VALID_PASSWORD_PATTERN', '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/');