<?php
// DisputeModel.php — Handle disputes, restricted channels, and penalties

class DisputeModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // Create a new dispute
    public function createDispute($client_id, $freelancer_id, $contract_id, $title) {
        try {
            $stmt = $this->db->prepare("INSERT INTO disputes (client_id, freelancer_id, contract_id, title, status) VALUES (?, ?, ?, ?, 'open')");
            return $stmt->execute([$client_id, $freelancer_id, $contract_id, $title]);
        } catch (PDOException $e) {
            error_log("Database Error in createDispute(): " . $e->getMessage());
            return false;
        }
    }

    // Get all open disputes
    public function getOpenDisputes() {
        try {
            $stmt = $this->db->prepare("SELECT d.*, u1.first_name as client_first, u1.last_name as client_last, u2.first_name as freelancer_first, u2.last_name as freelancer_last 
                                        FROM disputes d
                                        JOIN users u1 ON d.client_id = u1.user_id
                                        JOIN users u2 ON d.freelancer_id = u2.user_id
                                        WHERE d.status = 'open'
                                        ORDER BY d.created_at DESC");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getOpenDisputes(): " . $e->getMessage());
            return [];
        }
    }

    // Get dispute by ID
    public function getDisputeById($dispute_id) {
        try {
            $stmt = $this->db->prepare("SELECT d.*, u1.first_name as client_first, u1.last_name as client_last, u2.first_name as freelancer_first, u2.last_name as freelancer_last 
                                        FROM disputes d
                                        JOIN users u1 ON d.client_id = u1.user_id
                                        JOIN users u2 ON d.freelancer_id = u2.user_id
                                        WHERE d.dispute_id = ?");
            $stmt->execute([$dispute_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getDisputeById(): " . $e->getMessage());
            return null;
        }
    }

    // Create restricted channel for dispute
    public function createRestrictedChannel($dispute_id, $channel_name) {
        try {
            $stmt = $this->db->prepare("INSERT INTO restricted_channels (dispute_id, channel_name, is_active) VALUES (?, ?, TRUE)");
            $result = $stmt->execute([$dispute_id, $channel_name]);
            
            if ($result) {
                return $this->db->lastInsertId();
            }
            return false;
        } catch (PDOException $e) {
            error_log("Database Error in createRestrictedChannel(): " . $e->getMessage());
            return false;
        }
    }

    // Add members to restricted channel
    public function addChannelMember($channel_id, $user_id) {
        try {
            // Check if already a member
            $stmt = $this->db->prepare("SELECT member_id FROM channel_members WHERE channel_id = ? AND user_id = ?");
            $stmt->execute([$channel_id, $user_id]);
            if ($stmt->fetch()) {
                return true; // Already a member
            }

            $stmt = $this->db->prepare("INSERT INTO channel_members (channel_id, user_id) VALUES (?, ?)");
            return $stmt->execute([$channel_id, $user_id]);
        } catch (PDOException $e) {
            error_log("Database Error in addChannelMember(): " . $e->getMessage());
            return false;
        }
    }

    // Get channel messages
    public function getChannelMessages($channel_id) {
        try {
            $stmt = $this->db->prepare("SELECT m.*, u.first_name, u.last_name, u.role_id 
                                        FROM channel_messages m
                                        JOIN users u ON m.user_id = u.user_id
                                        WHERE m.channel_id = ?
                                        ORDER BY m.created_at ASC");
            $stmt->execute([$channel_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getChannelMessages(): " . $e->getMessage());
            return [];
        }
    }

    // Add message to channel
    public function addChannelMessage($channel_id, $user_id, $message_text) {
        try {
            $stmt = $this->db->prepare("INSERT INTO channel_messages (channel_id, user_id, message_text) VALUES (?, ?, ?)");
            return $stmt->execute([$channel_id, $user_id, $message_text]);
        } catch (PDOException $e) {
            error_log("Database Error in addChannelMessage(): " . $e->getMessage());
            return false;
        }
    }

    // Get active channels for dispute
    public function getChannelsByDispute($dispute_id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM restricted_channels WHERE dispute_id = ? AND is_active = TRUE");
            $stmt->execute([$dispute_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getChannelsByDispute(): " . $e->getMessage());
            return [];
        }
    }

    // Create a notification
    public function createNotification($user_id, $type, $message, $related_id = null) {
        try {
            $stmt = $this->db->prepare("INSERT INTO notifications (user_id, type, message, related_id, is_read) VALUES (?, ?, ?, ?, FALSE)");
            return $stmt->execute([$user_id, $type, $message, $related_id]);
        } catch (PDOException $e) {
            error_log("Database Error in createNotification(): " . $e->getMessage());
            return false;
        }
    }

    // Get user notifications
    public function getUserNotifications($user_id, $limit = 20) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
            $stmt->execute([$user_id, $limit]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getUserNotifications(): " . $e->getMessage());
            return [];
        }
    }

    // Mark notification as read
    public function markNotificationAsRead($notification_id) {
        try {
            $stmt = $this->db->prepare("UPDATE notifications SET is_read = TRUE WHERE notification_id = ?");
            return $stmt->execute([$notification_id]);
        } catch (PDOException $e) {
            error_log("Database Error in markNotificationAsRead(): " . $e->getMessage());
            return false;
        }
    }

    // Get penalty details
    public function getPenaltyDetails($user_id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM penalties WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getPenaltyDetails(): " . $e->getMessage());
            return null;
        }
    }

    // Close dispute
    public function closeDispute($dispute_id, $resolution = null) {
        try {
            $stmt = $this->db->prepare("UPDATE disputes SET status = 'resolved', resolved_at = NOW() WHERE dispute_id = ?");
            return $stmt->execute([$dispute_id]);
        } catch (PDOException $e) {
            error_log("Database Error in closeDispute(): " . $e->getMessage());
            return false;
        }
    }

    // Close restricted channel
    public function closeChannel($channel_id) {
        try {
            $stmt = $this->db->prepare("UPDATE restricted_channels SET is_active = FALSE WHERE channel_id = ?");
            return $stmt->execute([$channel_id]);
        } catch (PDOException $e) {
            error_log("Database Error in closeChannel(): " . $e->getMessage());
            return false;
        }
    }
}
?>
