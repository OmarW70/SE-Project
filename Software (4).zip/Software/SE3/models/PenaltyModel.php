<?php
// PenaltyModel.php - Handle penalty system with restrictions

class PenaltyModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // Apply penalty to user
    public function applyPenalty($user_id, $penalty_type, $reason, $dispute_id, $applied_by) {
        try {
            $this->db->beginTransaction();
            
            // Update user account status
            $account_status = $penalty_type === 'warning' ? 'active' : 
                             ($penalty_type === 'limited_access' ? 'limited_access' : 'banned');
            
            $stmt = $this->db->prepare("
                UPDATE users 
                SET account_status = ?, penalty_type = ?, penalty_reason = ?, penalty_applied_at = NOW() 
                WHERE user_id = ?
            ");
            $stmt->execute([$account_status, $penalty_type, $reason, $user_id]);
            
            // Create penalty record
            $stmt = $this->db->prepare("
                INSERT INTO penalties (user_id, dispute_id, penalty_type, reason, applied_by) 
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$user_id, $dispute_id, $penalty_type, $reason, $applied_by]);
            
            // Create notification for user
            $message = $this->getPenaltyMessage($penalty_type, $reason);
            $stmt = $this->db->prepare("
                INSERT INTO notifications (user_id, type, message, related_id) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$user_id, 'penalty_' . $penalty_type, $message, $dispute_id]);
            
            $this->db->commit();
            return true;
            
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Database Error in applyPenalty(): " . $e->getMessage());
            return false;
        }
    }

    // Get penalty message based on type
    private function getPenaltyMessage($penalty_type, $reason) {
        switch ($penalty_type) {
            case 'warning':
                return "⚠️ Warning: " . $reason . " - Please adhere to platform policies to avoid further penalties.";
            case 'limited_access':
                return "🚫 Limited Access: " . $reason . " - You cannot post jobs or submit proposals until this penalty is resolved.";
            case 'permanent_ban':
                return "🔒 Account Banned: " . $reason . " - Your account has been permanently suspended.";
            default:
                return "Penalty applied: " . $reason;
        }
    }

    // Check if user has active penalty
    public function hasActivePenalty($user_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT penalty_type, penalty_reason, penalty_applied_at 
                FROM users 
                WHERE user_id = ? AND penalty_type != 'none'
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in hasActivePenalty(): " . $e->getMessage());
            return false;
        }
    }

    // Check if user can post jobs (for clients)
    public function canPostJobs($user_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT account_status, penalty_type 
                FROM users 
                WHERE user_id = ? AND role_id = 1
            ");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) return false; // Not a client
            
            // Cannot post jobs if banned or has limited access
            return $user['account_status'] !== 'banned' && $user['penalty_type'] !== 'limited_access';
            
        } catch (PDOException $e) {
            error_log("Database Error in canPostJobs(): " . $e->getMessage());
            return false;
        }
    }

    // Check if user can submit proposals (for freelancers)
    public function canSubmitProposals($user_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT account_status, penalty_type 
                FROM users 
                WHERE user_id = ? AND role_id = 2
            ");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) return false; // Not a freelancer
            
            // Cannot submit proposals if banned or has limited access
            return $user['account_status'] !== 'banned' && $user['penalty_type'] !== 'limited_access';
            
        } catch (PDOException $e) {
            error_log("Database Error in canSubmitProposals(): " . $e->getMessage());
            return false;
        }
    }

    // Check if user can accept proposals (for clients)
    public function canAcceptProposals($user_id) {
        return $this->canPostJobs($user_id); // Same restrictions as posting jobs
    }

    // Check if user can login (for permanent bans)
    public function canLogin($user_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT account_status, penalty_type 
                FROM users 
                WHERE user_id = ?
            ");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user) return false;
            
            // Cannot login if permanently banned
            return $user['penalty_type'] !== 'permanent_ban';
            
        } catch (PDOException $e) {
            error_log("Database Error in canLogin(): " . $e->getMessage());
            return false;
        }
    }

    // Get user's penalty details
    public function getUserPenaltyDetails($user_id) {
        try {
            $stmt = $this->db->prepare("
                SELECT u.penalty_type, u.penalty_reason, u.penalty_applied_at,
                       p.penalty_id, p.created_at, p.reason,
                       admin.first_name as admin_first, admin.last_name as admin_last
                FROM users u
                LEFT JOIN penalties p ON u.user_id = p.user_id
                LEFT JOIN users admin ON p.applied_by = admin.user_id
                WHERE u.user_id = ?
                ORDER BY p.created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getUserPenaltyDetails(): " . $e->getMessage());
            return null;
        }
    }

    // Remove penalty from user (admin function)
    public function removePenalty($user_id, $removed_by) {
        try {
            $this->db->beginTransaction();
            
            // Update user account status
            $stmt = $this->db->prepare("
                UPDATE users 
                SET account_status = 'active', penalty_type = 'none', penalty_reason = NULL, penalty_applied_at = NULL 
                WHERE user_id = ?
            ");
            $stmt->execute([$user_id]);
            
            // Create notification for user
            $stmt = $this->db->prepare("
                INSERT INTO notifications (user_id, type, message) 
                VALUES (?, 'penalty_removed', ?)
            ");
            $stmt->execute([$user_id, "✅ Your penalty has been removed and full access has been restored."]);
            
            $this->db->commit();
            return true;
            
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Database Error in removePenalty(): " . $e->getMessage());
            return false;
        }
    }

    // Get all penalized users (admin function)
    public function getPenalizedUsers() {
        try {
            $stmt = $this->db->prepare("
                SELECT u.user_id, u.first_name, u.last_name, u.email, u.role_id, u.penalty_type, u.penalty_reason, u.penalty_applied_at,
                       r.role_name
                FROM users u
                JOIN roles r ON u.role_id = r.role_id
                WHERE u.penalty_type != 'none'
                ORDER BY u.penalty_applied_at DESC
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getPenalizedUsers(): " . $e->getMessage());
            return [];
        }
    }
}