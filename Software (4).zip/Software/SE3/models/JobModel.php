<?php
class JobModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // إضافة job جديدة
    public function createJob($client_id, $title, $description, $category, $budget) {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO jobs (client_id, title, description, category, budget, status) VALUES (?, ?, ?, ?, ?, 'open')"
            );
            $result = $stmt->execute([$client_id, $title, $description, $category, $budget]);
            if ($result) {
                return ['success' => true, 'job_id' => $this->db->lastInsertId()];
            }
            return ['success' => false];
        } catch(PDOException $e) {
            error_log("DB Error in createJob(): " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // جلب كل الـ jobs بتاعت client معين
    public function getJobsByClient($client_id) {
        try {
            $stmt = $this->db->prepare(
                "SELECT j.*, 
                    (SELECT COUNT(*) FROM proposals p WHERE p.job_id = j.job_id) AS proposal_count
                 FROM jobs j 
                 WHERE j.client_id = ? 
                 ORDER BY j.job_id DESC"
            );
            $stmt->execute([$client_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getJobsByClient(): " . $e->getMessage());
            return [];
        }
    }

    // جلب كل الـ jobs المفتوحة (للـ freelancer)
    public function getOpenJobs() {
        try {
            $stmt = $this->db->prepare(
                "SELECT j.*, u.first_name, u.last_name,
                    (SELECT COUNT(*) FROM proposals p WHERE p.job_id = j.job_id) AS proposal_count
                 FROM jobs j
                 JOIN users u ON j.client_id = u.user_id
                 WHERE j.status = 'open'
                 ORDER BY j.job_id DESC"
            );
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("DB Error in getOpenJobs(): " . $e->getMessage());
            return [];
        }
    }
}
?>
