<?php
class ContractModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    // إنشاء عقد جديد
    public function createContract($job_id, $client_id, $freelancer_id, $proposal_id, $amount) {
        $stmt = $this->db->prepare(
            "INSERT INTO contracts (job_id, client_id, freelancer_id, proposal_id, bid_amount, status) 
             VALUES (?, ?, ?, ?, ?, 'active')"
        );
        return $stmt->execute([$job_id, $client_id, $freelancer_id, $proposal_id, $amount]);
    }

    // جلب العقود النشطة للمستخدم (سواء كان كلاينت أو فريلانسر)
    public function getActiveContracts($user_id, $role) {
        $column = ($role === 'Client') ? 'client_id' : 'freelancer_id';
        $other_user_join = ($role === 'Client') ? 'freelancer_id' : 'client_id';
        
        try {
            $sql = "SELECT c.*, j.title as job_title, u.first_name, u.last_name 
                    FROM contracts c
                    LEFT JOIN jobs j ON c.job_id = j.job_id
                    LEFT JOIN users u ON c.$other_user_join = u.user_id
                    WHERE c.$column = ? AND c.status = 'active'
                    ORDER BY c.created_at DESC";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("DB Error in getActiveContracts: " . $e->getMessage());
            return [];
        }
    }
}
?>
