<?php
class UserModel {
    private $db;

    public function __construct() {
        // بننادي على الـ Singleton بتاع الداتا بيز اللي جربناه سوا
        $this->db = Database::getInstance();
    }

    // إضافة مستخدم جديد (التسجيل)
    public function register($first_name, $last_name, $email, $password, $role_id) {
        try {
            // تشفير الباسورد قبل ما يدخل الداتا بيز
            $hashed_password = password_hash($password, PASSWORD_DEFAULT); 
            $sql = "INSERT INTO users (first_name, last_name, email, password, role_id) VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute([$first_name, $last_name, $email, $hashed_password, $role_id]);
            return $result;
        } catch(PDOException $e) {
            // في حالة خطأ، نسجل الخطأ ونرجع false
            error_log("Database Error in register(): " . $e->getMessage());
            return false;
        }
    }

    

    // البحث عن مستخدم (عشان الـ Login)
    public function getUserByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // جلب بيانات المستخدم بالـ ID (عشان نعرضها في البروفايل)
    public function getUserById($user_id) {
        try {
            $stmt = $this->db->prepare("SELECT user_id, first_name, last_name, email, role_id, is_verified, created_at FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database Error in getUserById(): " . $e->getMessage());
            return false;
        }
    }

    // تحديث بيانات المستخدم (الاسم والإيميل)
    public function updateUser($user_id, $first_name, $last_name, $email) {
        try {
            // نتحقق إن الإيميل الجديد مش موجود عند حد تاني
            $stmt = $this->db->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
            $stmt->execute([$email, $user_id]);
            if ($stmt->fetch()) {
                return ['success' => false, 'error' => 'email_taken'];
            }

            $stmt = $this->db->prepare("UPDATE users SET first_name = ?, last_name = ?, email = ? WHERE user_id = ?");
            $result = $stmt->execute([$first_name, $last_name, $email, $user_id]);
            return ['success' => $result, 'error' => null];
        } catch(PDOException $e) {
            error_log("Database Error in updateUser(): " . $e->getMessage());
            return ['success' => false, 'error' => 'db_error'];
        }
    }

     
    public function removeUserByEmail($email) {
        try {
            // check user exists
            $stmt = $this->db->prepare("SELECT user_id FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                return false;
            }

            // delete user by ID
            $delete = $this->db->prepare("DELETE FROM users WHERE user_id = ?");
            $delete->execute([$user['user_id']]);

            return true;

        } catch (PDOException $e) {
            error_log("Error in removeUserByEmail: " . $e->getMessage());
            return false;
        }
    }

   
    // تطبيق عقوبة (Penalty) على المستخدم
    public function applyPenalty($user_id, $penalty_type, $reason, $dispute_id, $applied_by) {
        try {
            // تحديث حالة المستخدم
            if ($penalty_type === 'permanent_ban') {
                $status = 'banned';
            } elseif ($penalty_type === 'limited_access') {
                $status = 'limited_access';
            } else {
                $status = 'active';
            }

            // تحديث جدول المستخدمين
            $stmt = $this->db->prepare("UPDATE users SET account_status = ?, penalty_type = ?, penalty_reason = ?, penalty_applied_at = NOW() WHERE user_id = ?");
            $stmt->execute([$status, $penalty_type, $reason, $user_id]);

            // إضافة العقوبة إلى جدول العقوبات
            $stmt = $this->db->prepare("INSERT INTO penalties (user_id, dispute_id, penalty_type, reason, applied_by) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $dispute_id, $penalty_type, $reason, $applied_by]);

            return true;
        } catch (PDOException $e) {
            error_log("Database Error in applyPenalty(): " . $e->getMessage());
            return false;
        }
    }

    // التحقق من حالة المستخدم
    public function getUserStatus($user_id) {
        try {
            $stmt = $this->db->prepare("SELECT account_status, penalty_type, penalty_reason, penalty_applied_at FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getUserStatus(): " . $e->getMessage());
            return null;
        }
    }

    // التحقق من حظر المستخدم
    public function isBanned($user_id) {
        $status = $this->getUserStatus($user_id);
        return $status && $status['account_status'] === 'banned';
    }

    // التحقق من وجود قيود على المستخدم (Limited Access)
    public function hasLimitedAccess($user_id) {
        $status = $this->getUserStatus($user_id);
        return $status && $status['account_status'] === 'limited_access';
    }

    // الحصول على آخر عقوبة للمستخدم
    public function getLastPenalty($user_id) {
        try {
            $stmt = $this->db->prepare("SELECT * FROM penalties WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database Error in getLastPenalty(): " . $e->getMessage());
            return null;
        }
    }
}



?>